# -*- coding: utf-8 -*-
"""⑪ 가명 처리 — 밖(구글)으로 나가기 전에 사람 이름을 지운다.

  보낼 때 : "홍길동이 전출 신청, 김철수가 상담" → "인물1이 전출 신청, 인물2가 상담"
  받을 때 : "인물1의 전출 → 인물2 상담"        → "홍길동의 전출 → 김철수 상담"

매핑표는 이 PC 메모리에만 있고 저장도 전송도 하지 않는다(호출 1회 동안만 유효).

이름 사전 두 갈래:
  1) data/roster.txt — 사용자가 넣는 명부(한 줄에 한 명). 있으면 가장 정확하다.
  2) data/names.json — 대화에서 본 발신자 이름을 스스로 모은 것(보조).

한계(솔직히): 사전에 없는 이름, "내무부 서무님" 같은 직책 지칭, 맥락으로 사람이 특정되는
문장은 못 가린다. 완전 차단이 필요하면 그 방을 아예 제외해야 한다(EXCLUDE_ROOMS).
"""
from __future__ import annotations

import json
import re

import config

ROSTER = "roster.txt"
LEARNED = "names.json"
TITLES = ("부장님", "총무님", "과장님", "서무님", "강사님", "전도사님", "회장님", "님",
          "부장", "총무", "과장", "서무", "형제", "자매")
_NAME_RE = re.compile(r"^[가-힣]{2,4}$")


def _strip_title(s: str) -> str:
    s = (s or "").strip()
    for t in TITLES:
        if s.endswith(t) and len(s) - len(t) >= 2:
            s = s[: -len(t)]
            break
    return s.strip()


def learn(names) -> None:
    """검색·대화에서 본 발신자 이름을 사전에 쌓는다(로컬 파일)."""
    try:
        cur = set(config.read_json(LEARNED, []))
        for n in names:
            n = _strip_title(n)
            if _NAME_RE.match(n):
                cur.add(n)
        config.write_json(LEARNED, sorted(cur))
    except Exception:                                        # noqa: BLE001
        pass


def load_names() -> list[str]:
    """긴 이름부터 — '박윤정'을 먼저 바꿔야 '윤정'만 바뀌는 사고가 안 난다."""
    names: set[str] = set()
    try:
        p = config.data_file(ROSTER)
        if p.exists():
            for line in p.read_text(encoding="utf-8-sig").splitlines():
                n = _strip_title(line.split(",")[0])
                if _NAME_RE.match(n):
                    names.add(n)
    except Exception:                                        # noqa: BLE001
        pass
    try:
        names.update(n for n in config.read_json(LEARNED, []) if _NAME_RE.match(n))
    except Exception:                                        # noqa: BLE001
        pass
    return sorted(names, key=len, reverse=True)


def mask(text: str) -> tuple[str, dict]:
    """이름 → 인물N. (바뀐 글, 되돌릴 표)"""
    if not text:
        return text, {}
    out, mapping, n = text, {}, 0
    for name in load_names():
        if name in out:
            n += 1
            fake = f"인물{n}"
            mapping[fake] = name
            out = out.replace(name, fake)
    return out, mapping


def unmask(text: str, mapping: dict) -> str:
    """인물N → 원래 이름. 뒤에 조사가 붙어도(인물1이/인물1은) 정확히 되돌린다."""
    if not text or not mapping:
        return text
    out = text
    for fake, real in sorted(mapping.items(), key=lambda kv: len(kv[0]), reverse=True):
        out = re.sub(rf"(?<![0-9]){re.escape(fake)}(?![0-9])", real, out)
    return out


def count(text: str) -> int:
    """이 글에서 가려질 이름이 몇 개인지(사용자에게 보여줄 안내용)."""
    return len(mask(text)[1])
