# -*- coding: utf-8 -*-
"""설정·경로·로깅 — LiteBot 전역 기반.

exe(--onefile)로 얼렸을 때는 exe 가 있는 폴더가 기준,
스크립트로 실행하면 이 파일 폴더가 기준. config.json·data·logs 는 그 옆에 생긴다.
"""
from __future__ import annotations

import json
import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path


def app_dir() -> Path:
    """설정·데이터·로그의 기준점. 쓰기 가능한 곳이어야 한다(맥 .app 내부는 못 씀)."""
    if getattr(sys, "frozen", False):
        if sys.platform == "darwin":            # 맥: .app 내부는 서명/읽기전용 → 사용자 데이터 폴더로
            return Path.home() / "Library" / "Application Support" / "LiteBot"
        return Path(sys.executable).resolve().parent   # 윈도우: exe 옆(설치폴더=쓰기가능)
    return Path(__file__).resolve().parent.parent   # 스크립트: app/config.py → LiteBot/


def app_version() -> str:
    """현재 app 번들 버전(app/VERSION). 자동 업데이트로 바뀌는 값."""
    try:
        return (Path(__file__).resolve().parent / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:                          # noqa: BLE001
        return "?"


APP_DIR = app_dir()
CONFIG_PATH = APP_DIR / "config.json"
DATA_DIR = APP_DIR / "data"
LOG_DIR = APP_DIR / "logs"
LOG_PATH = LOG_DIR / "litebot.log"

DEFAULTS = {
    "bot_token": "",
    "chat_id": "",
    "town": "하남",
    "lat": 37.539,
    "lon": 127.214,
    "briefing_time": "07:30",
    "autostart": False,
    # 선택 기능(있을 때만 활성)
    "tg_api_id": "",
    "tg_api_hash": "",
    "icloud_id": "",
    "icloud_pw": "",
    "brain": "auto",                        # 머리 선택: auto | gemini | claude | off
    "watch_on": False,                      # 능동 감시(먼저 알림) 켜기
    "watch_keywords": "",                   # 감시할 말(쉼표): 예) 내무부,PT,취합
    "watch_rooms": "",                      # 감시할 방(쉼표, 부분일치): 예) 취합 및 보고창
    "my_name": "",                          # 내 이름(언급 감시에 자동 포함)
    "gemini_key": "",                       # 있으면 요약·사진읽기·표해석(무료 한도 내), 없으면 규칙 기반
    "ai_send_photos": False,                # 사진은 이름을 가릴 수 없어 기본 차단
    "xlsx_passwords": "",                   # 암호 걸린 엑셀용(쉼표로 여러 개). 이 PC 에만 저장
}


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict | None:
    """config.json 을 읽어 dict 반환. 없으면 None(→ 설정 마법사)."""
    if not CONFIG_PATH.exists():
        return None
    try:
        cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8-sig"))  # BOM 있어도 견딤
    except (json.JSONDecodeError, OSError) as e:
        logging.getLogger("litebot").error("설정 읽기 실패 — %s", e)
        return None
    merged = dict(DEFAULTS)
    merged.update(cfg or {})
    return merged


def save_config(cfg: dict) -> None:
    ensure_dirs()
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def data_file(name: str) -> Path:
    ensure_dirs()
    return DATA_DIR / name


def read_json(name: str, default):
    p = DATA_DIR / name
    if not p.exists():
        return default
    try:
        return json.loads(p.read_text(encoding="utf-8-sig"))
    except (json.JSONDecodeError, OSError):
        return default


def write_json(name: str, obj) -> None:
    ensure_dirs()
    (DATA_DIR / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


_LOGGER = None


def get_logger() -> logging.Logger:
    """로그: 한국어 요약 한 줄 + 상세. 파일(회전) + 콘솔(있으면)."""
    global _LOGGER
    if _LOGGER is not None:
        return _LOGGER
    ensure_dirs()
    lg = logging.getLogger("litebot")
    lg.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")
    fh = RotatingFileHandler(LOG_PATH, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    lg.addHandler(fh)
    if sys.stderr:                              # --noconsole 이면 stderr 없음
        try:
            sh = logging.StreamHandler()
            sh.setFormatter(fmt)
            lg.addHandler(sh)
        except Exception:                       # noqa: BLE001
            pass
    _LOGGER = lg
    return lg
