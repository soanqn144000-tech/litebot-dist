# -*- coding: utf-8 -*-
"""설정 마법사 — 창 대신 '터미널 질문식'. GUI 가 안 되는 컴퓨터용.

왜 필요한가: 맥에 기본으로 깔린 파이썬(3.9)의 Tk 8.5 는 요즘 macOS 에서
라벨·입력칸을 아예 안 그린다(2026-08-09 확인: 빨간 배경 라벨조차 안 보임).
그러면 설정 창이 '떴는데 아무것도 없는' 상태가 되어 봇 토큰조차 못 넣는다.
= 맥 쓰는 사람은 LiteBot 을 아예 못 쓴다.

창이 못 뜨면 이걸로 넘어온다. 물어보는 항목은 창과 같고, 저장 결과도 같다.
설치 프로그램이 어차피 터미널에서 도니까 사용자는 추가로 할 게 없다.
"""
from __future__ import annotations

import json
import re
import sys
import urllib.parse
import urllib.request

import config

GEOCODE = "https://geocoding-api.open-meteo.com/v1/search"
TG = "https://api.telegram.org/bot{t}/{m}"


def _ask(question: str, default: str = "", required: bool = False) -> str:
    """한 줄 질문. 엔터만 치면 기본값. required 면 빈 값으로 못 넘어간다."""
    hint = f" [{default}]" if default else ""
    while True:
        try:
            v = input(f"{question}{hint}: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n취소했습니다.")
            raise SystemExit(1)
        v = v or default
        if v or not required:
            return v
        print("  ↑ 이건 꼭 있어야 합니다.")


def _api(token: str, method: str, **params):
    url = TG.format(t=token, m=method)
    if params:
        url += "?" + urllib.parse.urlencode(params)
    with urllib.request.urlopen(url, timeout=20) as r:
        return json.loads(r.read().decode())


def _check_token(token: str) -> str:
    """토큰이 살아있나. 봇 이름 반환, 아니면 ''."""
    try:
        d = _api(token, "getMe")
        return (d.get("result") or {}).get("username", "") if d.get("ok") else ""
    except Exception:                                      # noqa: BLE001
        return ""


def _find_chat_id(token: str) -> str:
    """봇에게 온 최근 메시지에서 chat_id 를 찾는다. 사람이 숫자를 외울 필요가 없게."""
    try:
        d = _api(token, "getUpdates")
    except Exception:                                      # noqa: BLE001
        return ""
    for u in reversed(d.get("result", []) or []):
        m = u.get("message") or u.get("edited_message") or {}
        cid = (m.get("chat") or {}).get("id")
        if cid:
            return str(cid)
    return ""


def _geocode(name: str):
    try:
        url = GEOCODE + "?" + urllib.parse.urlencode({"name": name, "count": 1, "language": "ko"})
        with urllib.request.urlopen(url, timeout=15) as r:
            res = (json.loads(r.read().decode()).get("results") or [])
        if res:
            return round(res[0]["latitude"], 3), round(res[0]["longitude"], 3)
    except Exception:                                      # noqa: BLE001
        pass
    return None, None


def run_setup() -> bool:
    """터미널로 설정을 받아 저장. 저장했으면 True."""
    cfg = dict(config.DEFAULTS)
    old = config.load_config() or {}
    cfg.update({k: v for k, v in old.items() if k in cfg})

    print("\n" + "─" * 52)
    print(" LiteBot 설정 — 몇 가지만 물어볼게요.")
    print(" (그냥 엔터를 치면 [] 안의 값이 쓰입니다)")
    print("─" * 52)

    # ① 봇 토큰 — 살아있는지 바로 확인해준다(오타로 몇 시간 헤매는 일 방지)
    print("\n① 봇 토큰")
    print("   텔레그램에서 @BotFather → /newbot → 받은 토큰을 붙여넣으세요.")
    while True:
        token = _ask("   토큰", cfg.get("bot_token", ""), required=True)
        name = _check_token(token)
        if name:
            print(f"   ✅ 확인됨 — @{name}")
            break
        print("   ❌ 이 토큰으로는 접속이 안 됩니다. 다시 붙여넣어 주세요.")
    cfg["bot_token"] = token

    # ② chat_id — 자동으로 찾아준다. 못 찾으면 '봇에게 말 한마디' 안내 후 재시도.
    print("\n② 내 chat_id")
    cid = cfg.get("chat_id", "") or _find_chat_id(token)
    if not cid:
        print(f"   텔레그램에서 @{name} 를 찾아 아무 말이나 한 번 보내주세요.")
        input("   보내셨으면 엔터: ")
        cid = _find_chat_id(token)
    if cid:
        print(f"   ✅ 찾았습니다 — {cid}")
    else:
        print("   못 찾았습니다. @userinfobot 이 알려주는 숫자를 직접 넣어주세요.")
        cid = _ask("   chat_id", required=True)
    cfg["chat_id"] = str(cid)

    # ③ 동네 — 이름만 받고 좌표는 알아서 찾는다
    print("\n③ 동네 (날씨용)")
    town = _ask("   동네 이름", cfg.get("town", "하남"))
    lat, lon = _geocode(town)
    if lat is not None:
        cfg["town"], cfg["lat"], cfg["lon"] = town, lat, lon
        print(f"   ✅ {town} ({lat}, {lon})")
    else:
        print(f"   좌표를 못 찾아 기존 값을 씁니다 ({cfg['lat']}, {cfg['lon']}).")

    # ④ 아침 브리핑
    print("\n④ 아침 브리핑 시각")
    while True:
        t = _ask("   HH:MM (안 받으려면 none)", cfg.get("briefing_time", "07:30"))
        if t.lower() == "none" or re.fullmatch(r"([01]?\d|2[0-3]):[0-5]\d", t):
            cfg["briefing_time"] = "" if t.lower() == "none" else t
            break
        print("   ↑ 07:30 처럼 넣어주세요.")

    # ⑤ 머리(AI) — 없어도 검색·차트·발송은 다 된다. 겁주지 않게 설명한다.
    print("\n⑤ 머리(AI) — 요약·사진 속 표 읽기에만 씁니다. 없어도 나머지는 다 됩니다.")
    print("   1) 안 씀        2) 클로드 코드(구독 있는 분)   3) 제미나이(무료 키)")
    pick = _ask("   번호", "1")
    if pick == "2":
        cfg["brain"] = "claude"
    elif pick == "3":
        cfg["brain"] = "gemini"
        cfg["gemini_key"] = _ask("   Gemini 키", cfg.get("gemini_key", ""))
    else:
        cfg["brain"] = "off"

    config.save_config(cfg)
    print("\n✅ 저장했습니다. 이제 텔레그램에서 봇에게 말을 걸어보세요.")
    print("   설정을 바꾸려면 이 프로그램을 --settings 로 다시 실행하면 됩니다.\n")
    return True


if __name__ == "__main__":
    sys.exit(0 if run_setup() else 1)
