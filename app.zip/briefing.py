# -*- coding: utf-8 -*-
"""⑦ 아침 브리핑 — 날씨 + 오늘 일정 + 오늘 반복업무, 한 메시지.

맨 끝에 '생존 한 줄' 이 붙는다. 브리핑이 오면 살아있는 것, 안 오면 죽은 것 —
그런데 '안 온 것'을 사람이 알아채기는 어렵다. 그래서 **빠진 날을 다음 브리핑이 일러바친다.**
(2026-08-14 맥 절전으로 봇이 죽어 사흘간 먹통이었는데 아무도 몰랐다)
"""
from __future__ import annotations

from datetime import date, datetime, timedelta

import cal
import config
import tasks
import weather

HEALTH = "health.json"                                       # {"started": ISO, "last_briefing": "YYYY-MM-DD"}


def mark_start() -> None:
    """봇이 뜰 때 한 번. 언제부터 켜져 있는지 남긴다."""
    h = config.read_json(HEALTH, {})
    h["started"] = datetime.now().isoformat(timespec="seconds")
    config.write_json(HEALTH, h)


def _alive_line() -> str:
    """켜져 있는 기간 + 지난번 브리핑 이후 빠진 날. 지어내지 않는다 — 기록이 없으면 그렇다고 쓴다."""
    h = config.read_json(HEALTH, {})
    bits = [f"🟢 라이트봇 v{config.app_version()}"]

    started = h.get("started")
    if started:
        try:
            up = datetime.now() - datetime.fromisoformat(started)
            d, hh = up.days, up.seconds // 3600
            bits.append(f"{d}일 {hh}시간째 켜져 있음" if d else f"{hh}시간째 켜져 있음")
        except ValueError:
            pass

    line = " · ".join(bits)

    last = h.get("last_briefing")
    if last:
        try:
            gap = (date.today() - date.fromisoformat(last)).days
            if gap > 1:
                line += (f"\n⚠️ 브리핑이 {gap - 1}일 빠졌습니다 (마지막 {last}) — "
                         "그동안 봇이 꺼져 있었습니다.")
        except ValueError:
            pass
    return line


def _stamp_briefing() -> None:
    h = config.read_json(HEALTH, {})
    h["last_briefing"] = date.today().isoformat()
    config.write_json(HEALTH, h)


def build(cfg: dict) -> str:
    today = date.today()
    parts = [f"☀️ {today:%m월 %d일} 아침 브리핑", ""]
    parts.append(weather.brief(cfg))

    ev = cal.today_lines()
    parts.append("")
    parts.append("📅 오늘 일정")
    parts.append("\n".join(f"· {e}" for e in ev) if ev else "· (없음)")

    # 오늘 매일 반복업무 목록(참고용)
    daily = [t for t in config.read_json("tasks.json", []) if t.get("kind") == "daily"]
    if daily:
        parts.append("")
        parts.append("⏰ 오늘 예약업무")
        for t in sorted(daily, key=lambda x: x["time"]):
            parts.append(f"· {t['time']} {t['message']}")

    parts.append("")
    parts.append(_alive_line())
    _stamp_briefing()                                        # 만든 뒤에 찍는다 — 실패하면 안 찍혀야 한다
    return "\n".join(parts)
