# -*- coding: utf-8 -*-
"""⑦ 아침 브리핑 — 날씨 + 오늘 일정 + 오늘 반복업무, 한 메시지."""
from __future__ import annotations

from datetime import date

import cal
import config
import tasks
import weather


def build(cfg: dict) -> str:
    today = date.today()
    parts = [f"☀️ {today:%m월 %d일} 아침 브리핑", ""]
    parts.append(weather.brief(cfg))

    ev = cal.today_lines()
    parts.append("")
    parts.append("📅 오늘 일정")
    parts.append("\n".join(f"· {e}" for e in ev) if ev else "· (없음)")

    # 오늘 매일 반복업무 목록(참고용)
    daily = [t for t in config.read_json("tasks.json", []) if t.get("kind") == "daily"]
    if daily:
        parts.append("")
        parts.append("⏰ 오늘 예약업무")
        for t in sorted(daily, key=lambda x: x["time"]):
            parts.append(f"· {t['time']} {t['message']}")
    return "\n".join(parts)
