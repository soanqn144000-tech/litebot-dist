# -*- coding: utf-8 -*-
"""⑭ 능동 감시 — 물어보기 전에 봇이 먼저 알려준다. 수시로 텔레그램을 훑어 새 것만 통보.

세 가지(사용자 선택):
  ② 내 이름·내무부·PT 등 지정어가 어느 방에든 새로 올라오면      → "언급 알림"
  ③ 지정한 방(취합창 등)에 새 글·파일이 올라오면                 → "방 알림"
  ④ 마감·일정 임박('~까지 보고', '모레 회의', 날짜+회의/마감)     → "마감 알림"

스케줄러가 몇 분마다 scan(cfg) 을 부른다. 이미 알린 글은 다시 안 알린다(중복 방지).
상태: data/watch_state.json {last_id: {chat_id: 최근 본 msg_id}, seen: [...]}.
telethon 세션은 search.TG_LOCK 으로 사용자 검색과 직렬화(동시접속 잠금 방지).
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone

import config
import search

KST = timezone(timedelta(hours=9))
STATE = "watch_state.json"
SCAN_DAYS = 2                                                # 새로 뜬 것만 보므로 최근 며칠이면 충분
MAX_PER_KIND = 6                                             # 한 번에 알릴 최대 건수(스팸 방지)

# 마감·일정 신호 — 날짜/기한 + 행동어가 같이 있으면 임박으로 본다.
DEADLINE_RE = re.compile(
    r"(까지|마감|기한|데드라인|오늘\s*중|내일까지|모레|이번\s*주\s*내|금일)\s*[^\n]{0,20}?"
    r"(보고|제출|완료|회신|답)|"
    r"(\d{1,2}\s*[/월]\s*\d{1,2}[일]?|오늘|내일|모레|이번\s*주|금요일|월요일|화요일|수요일|목요일)"
    r"[^\n]{0,15}?(회의|모임|미팅|간담회|보고|제출|마감|일정)")


def _state() -> dict:
    try:
        d = config.read_json(STATE, {})
        return d if isinstance(d, dict) else {}
    except Exception:                                        # noqa: BLE001
        return {}


def _save(st: dict) -> None:
    try:
        config.write_json(STATE, st)
    except Exception:                                        # noqa: BLE001
        pass


def enabled(cfg: dict) -> bool:
    return bool(cfg.get("watch_on") and cfg.get("tg_api_id") and cfg.get("tg_api_hash"))


def keywords(cfg: dict) -> list[str]:
    """감시할 말. 설정값 + 내 이름(있으면). 소문자 비교."""
    ks = [k.strip() for k in str(cfg.get("watch_keywords") or "").split(",") if k.strip()]
    me = (cfg.get("my_name") or "").strip()
    if me and me not in ks:
        ks.append(me)
    return ks


def rooms(cfg: dict) -> list[str]:
    return [r.strip() for r in str(cfg.get("watch_rooms") or "").split(",") if r.strip()]


def status(cfg: dict) -> str:
    if not (cfg.get("tg_api_id") and cfg.get("tg_api_hash")):
        return "능동 감시: 텔레그램 미연결(설정 필요)"
    on = "켜짐" if cfg.get("watch_on") else "꺼짐"
    ks = keywords(cfg); rs = rooms(cfg)
    return (f"능동 감시: {on} · 지정어 {len(ks)}개{'('+', '.join(ks[:4])+')' if ks else ''} · "
            f"감시 방 {len(rs)}개")


async def scan(cfg: dict) -> list[str]:
    """새로 올라온 것 중 알릴 것들을 텍스트 메시지 리스트로. 없으면 빈 리스트."""
    if not enabled(cfg):
        return []
    ks = keywords(cfg)
    rs = rooms(cfg)
    if not ks and not rs:
        return []
    try:
        import telethon                                       # noqa: F401
    except Exception:                                        # noqa: BLE001
        return []

    st = _state()
    last_id: dict = st.get("last_id") or {}                  # chat_id(str) → 마지막으로 본 msg_id
    first_run = not st.get("inited")                         # 첫 실행이면 기준선만 잡고 알림은 안 낸다
    since = datetime.now(KST) - timedelta(days=SCAN_DAYS)
    alerts: list[str] = []
    fresh_last: dict = dict(last_id)

    async with search.TG_LOCK:
        client = search.open_client(cfg)
        try:
            await client.connect()
            if not await client.is_user_authorized():
                return []

            # ── ②④ 지정어 언급 + 마감 신호 (전 대화 검색) ──
            # 기준선(fresh_last)은 '본 것 전부' 기록해야 다음에 옛 글이 안 터진다.
            # 알림 개수만 MAX 로 제한(스팸 방지) — 스캔·기록은 계속.
            seen_keys = set()
            appended = 0
            for kw in ks:
                async for m in client.iter_messages(None, search=kw, limit=200):
                    if m.date and m.date.astimezone(KST) < since:
                        break
                    text = (m.message or "").replace("\n", " ").strip()
                    if not text or text.startswith(("/", "🔎 '", "📊 '", "🔔", "🗣", "⏰", "📥", "📎")):
                        continue
                    cid = str(m.chat_id)
                    if m.id <= last_id.get(cid, 0):          # 이미 본 것(그 방에서 이 번호 이하)
                        continue
                    key = (m.chat_id, m.id)
                    if key in seen_keys:
                        continue
                    seen_keys.add(key)
                    fresh_last[cid] = max(fresh_last.get(cid, 0), m.id)   # 항상 기록
                    if first_run or appended >= MAX_PER_KIND * 2:
                        continue                             # 첫 실행=기준선만 · 알림은 상한까지만
                    room = search._name_of(m.chat)
                    who = search._name_of(m.sender)
                    when = m.date.astimezone(KST).strftime("%m/%d %H:%M")
                    tag = "⏰ 마감·일정" if DEADLINE_RE.search(text) else f"🗣 '{kw}' 언급"
                    alerts.append(f"{tag}\n  {when} · {room} · {who}\n  {text[:120]}")
                    appended += 1

            # ── ③ 지정한 방의 새 글·파일 ──
            if rs:
                async for dialog in client.iter_dialogs():
                    dname = (dialog.name or "")
                    if not any(r.replace(" ", "") in dname.replace(" ", "") for r in rs):
                        continue
                    cid = str(dialog.id)
                    newest = last_id.get(cid, 0)
                    cnt = 0
                    async for m in client.iter_messages(dialog.entity, limit=30):
                        if m.date and m.date.astimezone(KST) < since:
                            break
                        if m.id <= last_id.get(cid, 0):
                            break                            # 최신순 — 이미 본 지점 도달
                        text = (m.message or "").replace("\n", " ").strip()
                        has_file = getattr(m, "document", None) is not None
                        if not text and not has_file:
                            continue
                        if text.startswith(("🔎 '", "📊 '", "🔔", "🗣", "⏰")):
                            continue
                        newest = max(newest, m.id)
                        when = m.date.astimezone(KST).strftime("%m/%d %H:%M")
                        who = search._name_of(m.sender)
                        what = ("📎 파일: " + _fname(m)) if has_file else text[:120]
                        alerts.append(f"📥 {dname}\n  {when} · {who}\n  {what}")
                        cnt += 1
                        if cnt >= MAX_PER_KIND:
                            break
                    fresh_last[cid] = max(fresh_last.get(cid, 0), newest)

            st["last_id"] = fresh_last
            st["inited"] = True
            _save(st)
            if first_run:                                    # 첫 실행 = 기준선만, 옛 글로 도배 안 함
                return []
            return alerts[: MAX_PER_KIND * 3]
        finally:
            await client.disconnect()


def _fname(m) -> str:
    for attr in getattr(getattr(m, "document", None), "attributes", []):
        n = getattr(attr, "file_name", "")
        if n:
            return n
    return "(파일)"
