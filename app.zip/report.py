# -*- coding: utf-8 -*-
"""⑮ 정기 자동 보고 — 정해진 시간에 산출물(차트·요약)을 자동 생성·전송.

  · 예배 추이  : 매주/매일 그 시각에 주일예배 출결 추이 차트를 자동 발송(아델식).
  · 검색 요약  : "<키워드> 관련 최근 글 요약"을 자동 발송(머리 있으면 요약, 없으면 목록).

원장: data/reports.json  [{id, when, day, time, kind, arg}]
  when=weekly → day(월=0..일=6) + time,   when=daily → time
scheduler 가 매 분 due() 로 검사(하루/주 1회, 같은 발생 중복 안 함).
실제 실행은 run(app, chat_id, cfg, rep) — 창구(app.bot)로 발송.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import config

KST = timezone(timedelta(hours=9))
REPORTS = "reports.json"
_FIRED = "reports_fired.json"                                # 같은 발생 중복 방지(날짜·id)
DOW = ["월", "화", "수", "목", "금", "토", "일"]
KINDS = {"예배추이", "검색요약"}


def _load() -> list[dict]:
    v = config.read_json(REPORTS, [])
    return v if isinstance(v, list) else []


def _save(items: list[dict]) -> None:
    config.write_json(REPORTS, items)


def _next_id(items) -> int:
    return max([i.get("id", 0) for i in items], default=0) + 1


def _fmt(it: dict, idx: int) -> str:
    if it.get("when") == "weekly":
        w = f"매주 {DOW[int(it.get('day', 0))]} {it.get('time')}"
    else:
        w = f"매일 {it.get('time')}"
    what = it["kind"] + (f" '{it['arg']}'" if it.get("arg") else "")
    return f"{idx}. [{w}] {what}"


def handle(args: list[str]) -> str:
    """/report 관리 — 추가/목록/삭제."""
    if not args:
        items = _load()
        if not items:
            return ("등록된 자동 보고가 없어요.\n"
                    "예) /report 추가 매주 월 09:00 예배추이\n"
                    "     /report 추가 매일 21:00 검색요약 내무부")
        return "📅 정기 자동 보고\n" + "\n".join(_fmt(it, i + 1) for i, it in enumerate(items)) \
            + "\n\n삭제: /report 삭제 <번호>"
    sub = args[0]
    if sub == "추가":
        return _add(args[1:])
    if sub in ("삭제", "지우기"):
        return _remove(args[1:])
    return "사용법: /report 추가 매주 월 09:00 예배추이 · /report 추가 매일 21:00 검색요약 내무부 · /report 삭제 <번호>"


def _parse_time(s: str) -> str | None:
    import re
    if not re.fullmatch(r"\d{1,2}:\d{2}", s):
        return None
    h, m = map(int, s.split(":"))
    return f"{h:02d}:{m:02d}" if (0 <= h < 24 and 0 <= m < 60) else None


def _add(rest: list[str]) -> str:
    if not rest:
        return "형식: /report 추가 매주 월 09:00 예배추이  또는  /report 추가 매일 21:00 검색요약 내무부"
    items = _load()
    if rest[0] in ("매주", "weekly"):
        if len(rest) < 4:
            return "형식: /report 추가 매주 월 09:00 예배추이"
        day_s, time_s, kind = rest[1], rest[2], rest[3]
        try:
            day = DOW.index(day_s[0])
        except ValueError:
            return "요일은 월~일 로 적어주세요. 예) 매주 월 09:00 예배추이"
        t = _parse_time(time_s)
        if not t:
            return "시각은 HH:MM (예: 09:00)."
        if kind not in KINDS:
            return f"보고 종류: {', '.join(KINDS)} 중 하나. 예) 예배추이 · 검색요약 내무부"
        arg = " ".join(rest[4:]).strip()
        if kind == "검색요약" and not arg:
            return "검색요약은 키워드가 필요해요. 예) /report 추가 매주 월 09:00 검색요약 내무부"
        items.append({"id": _next_id(items), "when": "weekly", "day": day,
                      "time": t, "kind": kind, "arg": arg})
        _save(items)
        return f"✅ 등록: 매주 {DOW[day]} {t} · {kind}{(' '+arg) if arg else ''}"
    if rest[0] in ("매일", "daily"):
        if len(rest) < 3:
            return "형식: /report 추가 매일 21:00 검색요약 내무부"
        t = _parse_time(rest[1])
        if not t:
            return "시각은 HH:MM (예: 21:00)."
        kind = rest[2]
        if kind not in KINDS:
            return f"보고 종류: {', '.join(KINDS)} 중 하나."
        arg = " ".join(rest[3:]).strip()
        if kind == "검색요약" and not arg:
            return "검색요약은 키워드가 필요해요."
        items.append({"id": _next_id(items), "when": "daily",
                      "time": t, "kind": kind, "arg": arg})
        _save(items)
        return f"✅ 등록: 매일 {t} · {kind}{(' '+arg) if arg else ''}"
    return "형식: /report 추가 매주 월 09:00 예배추이  또는  /report 추가 매일 21:00 검색요약 내무부"


def _remove(rest: list[str]) -> str:
    items = _load()
    if not rest or not rest[0].isdigit():
        return "형식: /report 삭제 <번호>"
    n = int(rest[0])
    if not (1 <= n <= len(items)):
        return "그 번호는 없어요. /report 로 목록 확인."
    gone = items.pop(n - 1)
    _save(items)
    return f"🗑 삭제: {_fmt(gone, n)}"


def due(now: datetime) -> list[dict]:
    """이번 분에 실행할 보고들. 같은 날 같은 보고는 한 번만."""
    hm = now.strftime("%H:%M")
    today = now.strftime("%Y-%m-%d")
    fired = config.read_json(_FIRED, {})
    out = []
    for it in _load():
        if it.get("time") != hm:
            continue
        if it.get("when") == "weekly" and int(it.get("day", -1)) != now.weekday():
            continue
        key = f"{today}#{it.get('id')}"
        if fired.get(key):
            continue
        fired[key] = True
        out.append(it)
    if out:
        fired = {k: v for k, v in fired.items() if k.startswith(today)}   # 지난 날짜 정리
        config.write_json(_FIRED, fired)
    return out


async def run(app, chat_id, cfg: dict, rep: dict, log=None) -> None:
    """보고 하나 실행 → 창구(app.bot)로 발송."""
    import bot                                               # 순환참조 피해 지연 임포트
    kind = rep.get("kind")
    try:
        if kind == "예배추이":
            await app.bot.send_message(chat_id=int(chat_id), text="📅 [자동보고] 주일예배 출결 추이를 만드는 중…")
            intro, photos = await bot.build_attendance_trend(cfg)
            if not photos:
                await app.bot.send_message(chat_id=int(chat_id),
                                           text="📅 [자동보고] 예배 추이 — 쓸 파일을 못 찾았어요(주 2회분 이상 필요).")
                return
            await app.bot.send_message(chat_id=int(chat_id), text="📅 [자동보고] " + intro)
            for caption, path in photos:
                await app.bot.send_photo(chat_id=int(chat_id), photo=open(path, "rb"), caption=caption)
        elif kind == "검색요약":
            import search
            kw = (rep.get("arg") or "").split()
            days = 7 if rep.get("when") == "weekly" else 1
            text = await search.find(cfg, kw + [str(days)])
            await app.bot.send_message(chat_id=int(chat_id),
                                       text=f"📅 [자동보고] '{rep.get('arg')}' 최근 {days}일\n\n{text}")
    except Exception as e:                                   # noqa: BLE001
        if log:
            log.error("자동보고 실행 오류(%s) — %s", kind, e)
