# -*- coding: utf-8 -*-
"""⑥ 텔레그램 검색·취합 — Telethon (config에 api_id/api_hash 있을 때만).

  /find <키워드…> [일수]     → 최근 N일 대화에서 검색. 낱말 여러 개면 전부 든 것만(AND).
                               결과는 방별로 묶고 최신순. 예) /find 내무부 피티 14
  /collect <키워드…> [일수]  → 기계적 취합표(방별·사람별 건수 + 최근순). LLM 없음.

Telethon 세션은 data/litebot_user.session. 최초엔 폰 인증이 필요할 수 있어
설정 마법사/로그 안내로 처리(비대화형 exe에서는 미리 만들어진 세션 권장).
"""
from __future__ import annotations

import asyncio
import re
from datetime import datetime, timedelta, timezone

import config
import llm
import privacy

KST = timezone(timedelta(hours=9))
# 텔레톤 세션(litebot_user.session)은 sqlite 라 동시 접속하면 'database is locked'.
# 사용자 검색(gather/find_files)과 능동 감시(watch)가 이 하나로 직렬화된다.
TG_LOCK = asyncio.Lock()


def _enabled(cfg: dict) -> bool:
    return bool(cfg.get("tg_api_id") and cfg.get("tg_api_hash"))


def _need_msg() -> str:
    return ("이 기능은 텔레그램 API 설정이 필요합니다.\n"
            "설정에서 api_id·api_hash를 입력하세요 (https://my.telegram.org).")


MAX_ROOMS = 6                                                # 결과에 펼쳐 보여줄 방 수
MAX_PER_ROOM = 4                                             # 방마다 보여줄 메시지 수
SNIPPET = 70                                                 # 본문 미리보기 길이
SCAN_LIMIT = 500                                             # 서버에서 훑을 최대 메시지 수(기간 밖이면 먼저 끊김)


def _name_of(ent) -> str:
    """대화방·발신자 이름. 글로벌 검색은 방·사람 정보를 응답에 같이 주므로 추가 호출이 없다."""
    if ent is None:
        return "?"
    title = getattr(ent, "title", None)
    if title:
        return title
    first = getattr(ent, "first_name", "") or ""
    last = getattr(ent, "last_name", "") or ""
    return (first + " " + last).strip() or getattr(ent, "username", None) or "?"


STOP = {                                                     # 검색에 쓸모없는 말(명령조·지시어)
    "최근", "요즘", "오늘", "어제", "이번", "지난", "그", "저", "이", "좀", "다", "전부", "모두",
    "해야", "하는", "한", "할", "했던", "해", "줘", "해줘", "알려줘", "알려", "보여줘", "보여",
    "찾아줘", "찾아", "정리해줘", "정리", "요약해줘", "요약", "뽑아줘", "말해줘",
    "내용", "관련", "대해", "대한", "것", "거", "뭐", "뭔지", "무슨", "어떤", "어떻게", "언제", "누가",
}
PARTICLES = ("에서의", "으로서", "이라고", "까지", "부터", "에서", "에게", "으로", "한테", "이나",
             "에는", "보다", "마다", "처럼", "이랑", "와의", "과의", "의", "을", "를", "이", "가",
             "은", "는", "도", "만", "로", "와", "과", "랑", "께")
MAX_KEYWORDS = 3                                             # 서버 검색을 이 개수만큼만 돈다(속도)


def _stem(w: str) -> str:
    """'내무부가' → '내무부'. 떼고도 두 글자 이상 남을 때만 조사로 본다."""
    for p in PARTICLES:
        if w.endswith(p) and len(w) - len(p) >= 2:
            return w[: -len(p)]
    return w


def _split_script(w: str) -> list[str]:
    """'PT내용' → ['PT','내용']. 영문·숫자와 한글이 붙어 있으면 검색이 안 걸려서 쪼갠다."""
    parts, buf = [], ""
    for ch in w:
        kind = "H" if "가" <= ch <= "힣" else "A"
        if buf and kind != ("H" if "가" <= buf[-1] <= "힣" else "A"):
            parts.append(buf); buf = ch
        else:
            buf += ch
    if buf:
        parts.append(buf)
    return [p for p in parts if len(p) >= 2] or [w]


def _keywords(words: list[str]) -> tuple[list[str], list[str]]:
    """문장을 넣어도 되게 — 핵심 낱말만 남기고 나머지는 버린 목록으로 돌려준다."""
    kw, dropped = [], []
    flat = []
    for raw in words:
        flat.extend(_split_script(raw) if len(raw) > 2 else [raw])
    for raw in flat:
        w = raw.strip(" ,.!?…\"'“”‘’()[]")
        if not w:
            continue
        if w in STOP or w.lower() in STOP:
            dropped.append(raw); continue
        s = _stem(w)
        if len(s) < 2 and not s.isdigit():
            dropped.append(raw); continue
        if s not in kw:
            kw.append(s)
    if not kw:                                               # 전부 걸러졌으면 제일 긴 낱말이라도 쓴다
        kw = [max(words, key=len)]
        dropped = [w for w in words if w not in kw]
    if len(kw) > MAX_KEYWORDS:
        keep = sorted(kw, key=len, reverse=True)[:MAX_KEYWORDS]
        dropped += [w for w in kw if w not in keep]
        kw = [w for w in kw if w in keep]
    return kw, dropped


def _parse(args: list[str]) -> tuple[list[str], int]:
    """['내무부','피티','내용','14'] → (['내무부','피티','내용'], 14). 맨 뒤 숫자만 일수로 본다."""
    days, words = 7, list(args)
    if len(words) >= 2 and words[-1].isdigit():
        days = min(int(words.pop()), 60)
    return words, days


parse_args = _parse                                          # 밖(차트 등)에서도 같은 규칙으로 쪼개 쓰라고


def _fmt_dt(d: datetime) -> str:
    return f"{d:%m/%d %H:%M}"


SUMMARY_RULE = """아래는 텔레그램 대화에서 찾은 글들이다. 사용자 질문에 맞게 한국어로 정리해라.

사용자 질문: {question}

규칙:
- 글에 실제로 있는 내용만. 추측·창작 금지. 없으면 "찾은 글에는 없습니다"라고 해라.
- 5줄 이내, 각 줄 앞에 "· ". 날짜(M/D)와 누가 말했는지를 붙여라.
- 인사말·서론 금지. 정리한 줄만."""


class SearchError(Exception):
    """telethon 없음·인증 안 됨 등 — 사용자에게 그대로 보여줄 말을 담는다."""


# ── 말 속의 단서 뽑기 ───────────────────────────────────────────────────────
# "내무부) 취합 및 보고창에서 세리서무님이 어제 올려준 파일" 처럼
# 방·사람·때가 섞여 들어온다. 이걸 검색어로 쓰면 안 되고 '걸러내는 조건'으로 써야 한다.
ROOM_RE = re.compile(r"([가-힣A-Za-z0-9()]{1,12}(?:\s[가-힣A-Za-z0-9()]{1,12}){0,2}(?:창|방))")
# 앞의 군더더기만 뗀다. '내무부'의 '내'를 떼지 않도록 한 글자짜리는 뒤에 공백을 요구한다.
ROOM_LEAD = re.compile(r"^(텔레그램에서|텔레그램|(?:내|제|우리|그|저|톡|여기|거기)\s+)")
PERSON_RE = re.compile(r"([가-힣]{2,4}(?:서무|과장|부장|총무|강사|전도사)?님)\s*(?:이|가|께서)?")
WHEN = [(r"어제", 2), (r"그제|그저께", 3), (r"오늘", 1), (r"이번\s*주|금주", 7),
        (r"지난\s*주|저번\s*주", 14), (r"이번\s*달|이달", 31), (r"지난\s*달", 62)]
FILE_WORDS = re.compile(r"(파일|엑셀|자료|첨부|시트|양식|보고서)")
DATE_RE = re.compile(r"(\d{1,2})\s*월\s*(\d{1,2})\s*일|(\d{1,2})\s*/\s*(\d{1,2})|"
                     r"(\d{1,2})\s*\.\s*(\d{1,2})\s*\.")


def _explicit_date(text: str) -> str | None:
    """'7월 19일' · '7/19' · '7.19.' → '7.19' (파일명 매칭용). 없으면 None."""
    m = DATE_RE.search(text)
    if not m:
        return None
    g = [x for x in m.groups() if x]
    if len(g) >= 2:
        return f"{int(g[0])}.{int(g[1])}"
    return None


_JOSA_END = re.compile(r"(에서|에게|한테|에|은|는|이|가|을|를|의|로|으로)$")
_TIME_WORD = re.compile(r"^(어제|오늘|그제|그저께|내일|이번주|금주|지난주|저번주|이번달|이달|지난달|최근)$")


def _room_of(text: str) -> str | None:
    """말에서 '방 이름'만 떼어낸다. 첫 번째 창/방 에서 끊는 게 핵심.

    예전엔 정규식 하나로 잡았는데, 조사(에)까지 한글이라 뒤쪽 창까지 욕심내서 삼켰다.
    '신앙관리소통창에 오늘 업무소통창에 …' → 방 이름이 '신앙관리소통창에 오늘 업무소통창'
    이 되어 그런 방이 없으니 방 지정이 통째로 무효가 됐다(2026-08-12 확인).
    → 첫 창/방 까지만 자르고, 뒤에서부터 낱말을 모으되 조사로 끝나거나 시간어면 거기서 멈춘다.
    """
    m = re.search(r"[가-힣A-Za-z0-9()+]*(?:창|방)", text)
    if not m:
        return None
    out: list[str] = []
    for tok in reversed(text[:m.end()].split()[-4:]):        # 방 이름은 길어야 네 낱말
        if out and (_JOSA_END.search(tok) or _TIME_WORD.match(tok)):
            break                                            # '…에 오늘 업무소통창' 의 '오늘'·'…에' 에서 끊는다
        if _TIME_WORD.match(tok):                            # 맨 뒤가 시간어면 방 이름이 아니다
            continue
        out.insert(0, tok)
    return " ".join(out) or None


def hints(text: str) -> dict:
    """말에서 방·사람·기간을 뽑아낸다. 없으면 그 항목은 None."""
    room = person = None
    days = None
    room = _room_of(text)
    if room:
        while ROOM_LEAD.match(room):                         # '내 텔레그램에서 취합창' → '취합창'
            room = ROOM_LEAD.sub("", room, count=1).strip()
    m = PERSON_RE.search(text)
    if m:
        person = m.group(1).strip().rstrip("님")
    for pat, d in WHEN:
        if re.search(pat, text):
            days = d
            break
    return {"room": room, "person": person, "days": days, "date": _explicit_date(text),
            "wants_file": bool(FILE_WORDS.search(text))}


HINT_JUNK = re.compile(r"^(및|로|을|를|은|는|이|가|의|에|에서|에게|한테|어제|오늘|그제|이번주|"
                       r"지난주|이번달|지난달|금주|저번주|올라온|올린|올려준|보내준|받은|첨부|파일|"
                       r"확인|확인해서|확인해|봐서|보고|데이터|자료|만들어줘|만들어|차트|"
                       r"내용|얘기|이야기|말|글|것|거|무슨|뭐|뭔|정리|정리해줘|정리해|찾아|찾아줘|"
                       r"\d{1,2}월|\d{1,2}일|\d{1,2}/\d{1,2})$")


def strip_hints(words: list[str], h: dict, allow_empty: bool = False) -> list[str]:
    """방·사람·때는 '조건'이지 '검색어'가 아니다 — 검색어 목록에서 걷어낸다.

    이걸 안 하면 '취합 보고창에서 세리서무님이 어제' 가 통째로 검색어가 되어 아무것도 못 찾는다.
    """
    room = (h.get("room") or "").replace(" ", "")
    person = h.get("person") or ""
    out = []
    for w in words:
        bare = w.strip("()[],.")
        if not bare or HINT_JUNK.match(bare):
            continue
        stem = re.sub(r"(에서|에게|에|의|을|를|은|는|이|가|로)$", "", bare)  # 조사 뗀 형태
        if stem.endswith(("창", "방")):                       # '취합창에' → 방 지칭 → 검색어 아님
            continue
        if room and bare.replace(" ", "") in room:
            continue
        if person and (bare.startswith(person) or person.startswith(bare.rstrip("님이가"))):
            continue
        out.append(bare)
    # 전부 조건이었으면(방·때만 말한 경우) 빈 목록이 맞다 — 예전엔 원문을 도로 돌려줘서
    # '신앙관리소통창에 오늘 올라온 내용' 이 통째로 검색어가 됐다(2026-08-12).
    # 다만 옛 호출부(차트 등)는 빈 목록을 못 받으므로 기본은 그대로 둔다.
    return out if (out or allow_empty) else words


def _match_hint(value: str, hint: str | None) -> bool:
    """방·사람 이름은 부분만 맞아도 통과(사람들이 정확히 안 쓴다)."""
    if not hint:
        return True
    v, h = (value or "").replace(" ", ""), hint.replace(" ", "")
    return h in v or v in h


def open_client(cfg: dict):
    """텔레톤 클라이언트 하나. 세션은 공용(litebot_user). 반드시 TG_LOCK 안에서 쓴다."""
    from telethon import TelegramClient
    session = str(config.data_file("litebot_user"))
    return TelegramClient(session, int(cfg["tg_api_id"]), cfg["tg_api_hash"])


async def gather(cfg: dict, words: list[str], days: int,
                 room: str | None = None, person: str | None = None,
                 ) -> tuple[list[dict], list[str], list[str]]:
    """검색해서 (찾은 글, 쓴 낱말, 버린 낱말). 요약·목록·차트가 모두 이걸 쓴다.

    room/person 은 '좁히는 힌트'다. 그 조건으로 0건이 되면 무시하고 전체 결과를 준다
    (사람이 방 이름을 정확히 안 쓴다 — find_files 와 같은 원칙)."""
    try:
        from telethon import TelegramClient                  # noqa: F401 — 설치 확인용
    except Exception:                                        # noqa: BLE001
        raise SearchError("telethon 이 없어 검색을 못 해요.")
    kw, dropped = _keywords(words)
    low_kw = [w.lower() for w in kw]
    async with TG_LOCK:                                      # 감시·검색이 세션을 동시에 안 열게
        client = open_client(cfg)
        try:
            await client.connect()
            if not await client.is_user_authorized():
                raise SearchError("텔레그램 개인계정 인증이 안 돼 있어요.\n"
                                  "최초 1회 인증이 필요합니다(설정/로그 안내 참고).")
            since = datetime.now(KST) - timedelta(days=days)
            found = {}                                       # (방,글번호) → 건. 낱말별 검색결과를 합친다
            if not kw and room:                              # '그 방에 오늘 올라온 것' = 검색어 없이 통째로 보기
                async for d in client.iter_dialogs():
                    if not _match_hint(_name_of(d.entity), room):
                        continue
                    async for m in client.iter_messages(d.entity, limit=SCAN_LIMIT):
                        if m.date and m.date.astimezone(KST) < since:
                            break
                        text = (m.message or "").replace("\n", " ").strip()
                        if not text or text.startswith("/"):
                            continue
                        found[(m.chat_id, m.id)] = {
                            "date": m.date.astimezone(KST), "room": _name_of(d.entity),
                            "sender": _name_of(m.sender), "text": text, "score": 1}
                hits = list(found.values())
                privacy.learn(h["sender"] for h in hits)
                return hits, [], []
            for word in kw:
                # 방을 하나씩 돌지 않는다 — entity=None 이면 텔레그램이 전 대화를 한 번에 검색(최신순).
                async for m in client.iter_messages(None, search=word, limit=SCAN_LIMIT):
                    if m.date and m.date.astimezone(KST) < since:
                        break                                # 최신순이라 기간 밖이면 그 뒤는 볼 것 없음
                    text = (m.message or "").replace("\n", " ").strip()
                    if not text or text.startswith("/") or text.startswith(("🔎 '", "📊 '")):
                        continue                             # 내 명령·전에 받은 검색결과가 다시 걸리는 것 제외
                    if getattr(m.chat, "bot", False):
                        continue                             # 봇과의 1:1 대화(내가 방금 시킨 말)는 검색 대상이 아니다
                    key = (m.chat_id, m.id)
                    if key in found:
                        continue
                    low = text.lower()
                    found[key] = {"date": m.date.astimezone(KST), "room": _name_of(m.chat),
                                  "sender": _name_of(m.sender), "text": text,
                                  "score": sum(1 for w in low_kw if w in low)}
            hits = list(found.values())
            # 방·사람 좁히기. 걸러서 0건이 되면 조건을 버리고 전체를 준다(아무것도 안 나오는 것보단 낫다).
            if room or person:
                narrowed = [h for h in hits
                            if _match_hint(h["room"], room) and _match_hint(h["sender"], person)]
                if narrowed:
                    hits = narrowed
            privacy.learn(h["sender"] for h in hits)         # 본 이름을 사전에 쌓아 둔다(가명 처리용)
            return hits, kw, dropped
        finally:
            await client.disconnect()


FILE_EXTS = (".xlsx", ".xlsm", ".csv", ".tsv", ".txt")


def _search_terms(kw: list[str]) -> list[str]:
    """텔레그램 한글 검색은 '토큰(낱말) 단위'라 부분어가 안 걸린다.
    파일명은 '예배출석현황' 처럼 붙어 있으므로, 낱말을 붙인 형태도 검색어에 넣는다.
    예) ['예배','출석현황'] → ['예배','출석현황','예배출석현황'] + 이웃쌍.
    """
    terms = list(kw)
    if len(kw) >= 2:
        terms.append("".join(kw))                            # 전부 붙이기
        for a, b in zip(kw, kw[1:]):                         # 이웃 두 개씩 붙이기
            terms.append(a + b)
    seen, out = set(), []
    for t in terms:
        if t and t not in seen:
            seen.add(t); out.append(t)
    return out


async def find_files(cfg: dict, words: list[str], days: int = 30,
                     room: str | None = None, person: str | None = None,
                     want_date: str | None = None, exts: tuple = FILE_EXTS) -> list[dict]:
    """텔레그램에 **올라온 첨부파일**을 찾는다(글자 검색이 아니라 파일 검색).

    방·사람·날짜는 '좁히는 힌트'로만 쓴다 — 그 조건 때문에 결과가 0 이 되면 무시하고 전체를 준다.
    (사람들이 방 이름을 정확히 안 쓴다: "취합창" 은 사실 '신앙관리 소통창'의 한 주제다.)
    돌려주는 것: [{name,size,date,room,sender,chat_id,msg_id,score}] — 잘 맞는 것부터.
    """
    try:
        from telethon.tl.types import InputMessagesFilterDocument
    except Exception:                                        # noqa: BLE001
        raise SearchError("telethon 이 없어 파일을 못 찾아요.")
    kw, _dropped = _keywords(words) if words else ([], [])
    low_kw = [w.lower() for w in kw]
    dnorm = (want_date or "").replace(" ", "")               # '7.19'
    async with TG_LOCK:
        client = open_client(cfg)
        try:
            return await _find_files_inner(client, cfg, kw, low_kw, dnorm, days,
                                           room, person, exts, InputMessagesFilterDocument)
        finally:
            await client.disconnect()


async def _find_files_inner(client, cfg, kw, low_kw, dnorm, days, room, person, exts,
                            InputMessagesFilterDocument):
    if True:
        await client.connect()
        if not await client.is_user_authorized():
            raise SearchError("텔레그램 개인계정 인증이 안 돼 있어요.")
        since = datetime.now(KST) - timedelta(days=days)
        found: dict = {}
        for word in (_search_terms(kw) or [""]):             # 낱말 + 붙인 형태(한글 토큰 대응)
            async for m in client.iter_messages(None, search=word, limit=SCAN_LIMIT,
                                                filter=InputMessagesFilterDocument):
                if m.date and m.date.astimezone(KST) < since:
                    break
                doc = getattr(m, "document", None)
                if doc is None:
                    continue
                name = ""
                for attr in getattr(doc, "attributes", []):
                    name = getattr(attr, "file_name", "") or name
                if not name.lower().endswith(exts):
                    continue
                if (m.chat_id, m.id) in found:
                    continue
                rm, sd = _name_of(m.chat), _name_of(m.sender)
                hay = (name + " " + (m.message or "")).lower()
                score = sum(1 for w in low_kw if w in hay)
                # 파일명이 낱말을 통째로 담으면(예배출석현황) 강한 신호
                if kw and "".join(low_kw) in name.replace(" ", "").lower():
                    score += 2
                nname = name.replace(" ", "")
                if dnorm and (dnorm in nname or dnorm.replace(".", "") in nname):
                    score += 5                                # 요청 날짜가 파일명에 있으면 확 올린다
                found[(m.chat_id, m.id)] = {
                    "name": name, "size": getattr(doc, "size", 0),
                    "date": m.date.astimezone(KST), "room": rm, "sender": sd,
                    "chat_id": m.chat_id, "msg_id": m.id, "score": score}
        allf = list(found.values())
        # 날짜를 콕 집었으면 그 날짜 파일만. 없으면 전체(힌트가 틀렸을 수 있으니).
        if dnorm:
            dated = [f for f in allf if dnorm in f["name"].replace(" ", "")
                     or dnorm.replace(".", "") in f["name"].replace(" ", "")]
            allf = dated or allf
        # 방·사람으로 좁혀 본다. 좁혀서 아무것도 안 남으면 그 힌트는 틀린 것 — 전체를 쓴다.
        narrowed = [f for f in allf if _match_hint(f["room"], room) and _match_hint(f["sender"], person)]
        picked = narrowed if narrowed else allf
        out = sorted(picked, key=lambda x: (x["score"], x["date"]), reverse=True)
        privacy.learn(f["sender"] for f in out)
        return out


async def download(cfg: dict, chat_id: int, msg_id: int) -> tuple[str, bytes] | None:
    """찾은 파일을 실제로 받아온다. (파일이름, 내용)"""
    try:
        import telethon                                       # noqa: F401 — 설치 확인
    except Exception:                                        # noqa: BLE001
        return None
    async with TG_LOCK:
        client = open_client(cfg)
        try:
            await client.connect()
            msgs = await client.get_messages(chat_id, ids=[msg_id])
            if not msgs or msgs[0] is None:
                return None
            m = msgs[0]
            name = "file"
            for attr in getattr(getattr(m, "document", None), "attributes", []):
                name = getattr(attr, "file_name", "") or name
            data = await client.download_media(m, file=bytes)
            return (name, data) if data else None
        except Exception as e:                               # noqa: BLE001
            config.get_logger().info("파일 내려받기 실패: %s", type(e).__name__)
            return None
        finally:
            await client.disconnect()


def rank(hits: list[dict]) -> tuple[list[dict], int]:
    """많이 맞은 것부터. 다 맞은 게 너무 적으면 한 칸씩 느슨하게 푼다."""
    best = max(h["score"] for h in hits)
    need = best
    while need > 1 and sum(1 for h in hits if h["score"] >= need) < 3:
        need -= 1
    out = [h for h in hits if h["score"] >= need]
    out.sort(key=lambda x: (x["score"], x["date"]), reverse=True)
    return out, need


async def _search(cfg: dict, words: list[str], days: int, collect: bool,
                  raw: str = "") -> str:
    # 말 속의 방·사람·기간을 조건으로 쓴다. raw 를 받아만 놓고 안 쓰던 것 —
    # 그래서 "신앙관리소통창에 오늘 올라온 내용" 이 방 이름째로 검색어가 되고 전 방을 뒤졌다
    # (2026-08-12 확인). cmd_chart 는 이미 이렇게 하고 있었는데 검색만 빠져 있었다.
    h = hints(raw) if raw else {"room": None, "person": None, "days": None}
    _orig = list(words)
    if h.get("days"):
        days = h["days"]
    words = strip_hints(words, h, allow_empty=True)
    if not words and not h.get("room"):
        words = _orig                                        # 방도 검색어도 없으면 예전대로
    try:
        hits, kw, dropped = await gather(cfg, words, days, room=h.get("room"),
                                         person=h.get("person"))
    except SearchError as e:
        return str(e)
    query = " ".join(kw) or (h.get("room") or "")
    browsing = not kw                                        # 검색어 없이 방을 통째로 본 경우
    if not hits:
        return ((f"'{query}' 방에 최근 {days}일 올라온 글이 없어요." if browsing
                 else f"최근 {days}일 '{query}' 검색 결과가 없어요.")
                + (f"\n(무시한 말: {' '.join(dropped)})" if dropped else ""))

    hits, need = rank(hits)
    from collections import Counter
    by_room = Counter(h["room"] for h in hits)
    note = f" · '{query}' 중 {need}개 이상" if len(kw) > 1 else ""
    # 어떤 조건으로 좁혔는지 보여준다 — 안 보이면 '왜 이게 나왔지' 를 알 수 없다.
    for label, val in (("방", h.get("room")), ("올린이", h.get("person"))):
        if val:
            note += f" · {label}:{val}"
    if dropped:
        note += f" · 무시: {' '.join(dropped[:5])}"

    if collect:
        by_sender = Counter(h["sender"] for h in hits)
        lines = [f"📊 '{query}' 취합 — 최근 {days}일 · {len(hits)}건 · {len(by_room)}개 방{note}", "",
                 "▸ 방별"]
        for r, c in by_room.most_common(10):
            lines.append(f"  {r} — {c}건")
        lines.append("")
        lines.append("▸ 사람별")
        for s, c in by_sender.most_common(10):
            lines.append(f"  {s} — {c}건")
        lines.append("")
        lines.append("▸ 최근 순")
        for h in sorted(hits, key=lambda x: x["date"], reverse=True)[:25]:
            lines.append(f"  {_fmt_dt(h['date'])} [{h['sender']}] {h['text'][:SNIPPET]}")
        if len(hits) > 25:
            lines.append(f"  … 외 {len(hits) - 25}건")
        return "\n".join(lines)

    lines = []
    if raw and llm.available(cfg):                           # 머리가 있으면 먼저 요약, 아래에 근거 목록
        body = "\n".join(f"[{_fmt_dt(h['date'])}] {h['room']} / {h['sender']}: {h['text'][:400]}"
                         for h in hits[:40])
        got = llm.ask(cfg, SUMMARY_RULE.format(question=raw) + "\n--- 찾은 글 ---\n" + body)
        if got:
            lines += ["🧠 " + got.strip(), ""]
    lines.append(f"🔎 '{query}' — 최근 {days}일 · {len(hits)}건 · {len(by_room)}개 방{note}")
    shown = 0
    rooms = sorted(by_room.items(),                          # 잘 맞은 방부터, 그 다음 건수 순
                   key=lambda rc: (max(h["score"] for h in hits if h["room"] == rc[0]), rc[1]),
                   reverse=True)
    for room, cnt in rooms[:MAX_ROOMS]:
        lines.append("")
        lines.append(f"▸ {room} ({cnt}건)")
        for h in [x for x in hits if x["room"] == room][:MAX_PER_ROOM]:
            lines.append(f"  {_fmt_dt(h['date'])} [{h['sender']}] {h['text'][:SNIPPET]}")
            shown += 1
        if cnt > MAX_PER_ROOM:
            lines.append(f"  … 이 방 {cnt - MAX_PER_ROOM}건 더")
    if len(by_room) > MAX_ROOMS:
        more = sum(c for _, c in rooms[MAX_ROOMS:])
        lines.append("")
        lines.append(f"… 그 밖에 {len(by_room) - MAX_ROOMS}개 방 {more}건")
    if len(hits) > shown:
        lines.append(f"전체 건수·사람별 집계는  /collect {query} {days}")
    return "\n".join(lines)


async def find(cfg: dict, args: list[str]) -> str:
    if not _enabled(cfg):
        return _need_msg()
    words, days = _parse(args)
    if not words:
        return "형식: /find <키워드…> [일수]   예) /find 내무부 피티 14"
    return await _search(cfg, words, days, collect=False, raw=" ".join(args))


async def collect(cfg: dict, args: list[str]) -> str:
    if not _enabled(cfg):
        return _need_msg()
    words, days = _parse(args)
    if not words:
        return "형식: /collect <키워드…> [일수]   예) /collect 전입 30"
    return await _search(cfg, words, days, collect=True, raw=" ".join(args))
