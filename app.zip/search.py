# -*- coding: utf-8 -*-
"""⑥ 텔레그램 검색·취합 — Telethon (config에 api_id/api_hash 있을 때만).

  /find <키워드…> [일수]     → 최근 N일 대화에서 검색. 낱말 여러 개면 전부 든 것만(AND).
                               결과는 방별로 묶고 최신순. 예) /find 내무부 피티 14
  /collect <키워드…> [일수]  → 기계적 취합표(방별·사람별 건수 + 최근순). LLM 없음.

Telethon 세션은 data/litebot_user.session. 최초엔 폰 인증이 필요할 수 있어
설정 마법사/로그 안내로 처리(비대화형 exe에서는 미리 만들어진 세션 권장).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import config
import llm
import privacy

KST = timezone(timedelta(hours=9))


def _enabled(cfg: dict) -> bool:
    return bool(cfg.get("tg_api_id") and cfg.get("tg_api_hash"))


def _need_msg() -> str:
    return ("이 기능은 텔레그램 API 설정이 필요합니다.\n"
            "설정에서 api_id·api_hash를 입력하세요 (https://my.telegram.org).")


MAX_ROOMS = 6                                                # 결과에 펼쳐 보여줄 방 수
MAX_PER_ROOM = 4                                             # 방마다 보여줄 메시지 수
SNIPPET = 70                                                 # 본문 미리보기 길이
SCAN_LIMIT = 500                                             # 서버에서 훑을 최대 메시지 수(기간 밖이면 먼저 끊김)


def _name_of(ent) -> str:
    """대화방·발신자 이름. 글로벌 검색은 방·사람 정보를 응답에 같이 주므로 추가 호출이 없다."""
    if ent is None:
        return "?"
    title = getattr(ent, "title", None)
    if title:
        return title
    first = getattr(ent, "first_name", "") or ""
    last = getattr(ent, "last_name", "") or ""
    return (first + " " + last).strip() or getattr(ent, "username", None) or "?"


STOP = {                                                     # 검색에 쓸모없는 말(명령조·지시어)
    "최근", "요즘", "오늘", "어제", "이번", "지난", "그", "저", "이", "좀", "다", "전부", "모두",
    "해야", "하는", "한", "할", "했던", "해", "줘", "해줘", "알려줘", "알려", "보여줘", "보여",
    "찾아줘", "찾아", "정리해줘", "정리", "요약해줘", "요약", "뽑아줘", "말해줘",
    "내용", "관련", "대해", "대한", "것", "거", "뭐", "뭔지", "무슨", "어떤", "어떻게", "언제", "누가",
}
PARTICLES = ("에서의", "으로서", "이라고", "까지", "부터", "에서", "에게", "으로", "한테", "이나",
             "에는", "보다", "마다", "처럼", "이랑", "와의", "과의", "의", "을", "를", "이", "가",
             "은", "는", "도", "만", "로", "와", "과", "랑", "께")
MAX_KEYWORDS = 3                                             # 서버 검색을 이 개수만큼만 돈다(속도)


def _stem(w: str) -> str:
    """'내무부가' → '내무부'. 떼고도 두 글자 이상 남을 때만 조사로 본다."""
    for p in PARTICLES:
        if w.endswith(p) and len(w) - len(p) >= 2:
            return w[: -len(p)]
    return w


def _split_script(w: str) -> list[str]:
    """'PT내용' → ['PT','내용']. 영문·숫자와 한글이 붙어 있으면 검색이 안 걸려서 쪼갠다."""
    parts, buf = [], ""
    for ch in w:
        kind = "H" if "가" <= ch <= "힣" else "A"
        if buf and kind != ("H" if "가" <= buf[-1] <= "힣" else "A"):
            parts.append(buf); buf = ch
        else:
            buf += ch
    if buf:
        parts.append(buf)
    return [p for p in parts if len(p) >= 2] or [w]


def _keywords(words: list[str]) -> tuple[list[str], list[str]]:
    """문장을 넣어도 되게 — 핵심 낱말만 남기고 나머지는 버린 목록으로 돌려준다."""
    kw, dropped = [], []
    flat = []
    for raw in words:
        flat.extend(_split_script(raw) if len(raw) > 2 else [raw])
    for raw in flat:
        w = raw.strip(" ,.!?…\"'“”‘’()[]")
        if not w:
            continue
        if w in STOP or w.lower() in STOP:
            dropped.append(raw); continue
        s = _stem(w)
        if len(s) < 2 and not s.isdigit():
            dropped.append(raw); continue
        if s not in kw:
            kw.append(s)
    if not kw:                                               # 전부 걸러졌으면 제일 긴 낱말이라도 쓴다
        kw = [max(words, key=len)]
        dropped = [w for w in words if w not in kw]
    if len(kw) > MAX_KEYWORDS:
        keep = sorted(kw, key=len, reverse=True)[:MAX_KEYWORDS]
        dropped += [w for w in kw if w not in keep]
        kw = [w for w in kw if w in keep]
    return kw, dropped


def _parse(args: list[str]) -> tuple[list[str], int]:
    """['내무부','피티','내용','14'] → (['내무부','피티','내용'], 14). 맨 뒤 숫자만 일수로 본다."""
    days, words = 7, list(args)
    if len(words) >= 2 and words[-1].isdigit():
        days = min(int(words.pop()), 60)
    return words, days


parse_args = _parse                                          # 밖(차트 등)에서도 같은 규칙으로 쪼개 쓰라고


def _fmt_dt(d: datetime) -> str:
    return f"{d:%m/%d %H:%M}"


SUMMARY_RULE = """아래는 텔레그램 대화에서 찾은 글들이다. 사용자 질문에 맞게 한국어로 정리해라.

사용자 질문: {question}

규칙:
- 글에 실제로 있는 내용만. 추측·창작 금지. 없으면 "찾은 글에는 없습니다"라고 해라.
- 5줄 이내, 각 줄 앞에 "· ". 날짜(M/D)와 누가 말했는지를 붙여라.
- 인사말·서론 금지. 정리한 줄만."""


class SearchError(Exception):
    """telethon 없음·인증 안 됨 등 — 사용자에게 그대로 보여줄 말을 담는다."""


async def gather(cfg: dict, words: list[str], days: int) -> tuple[list[dict], list[str], list[str]]:
    """검색해서 (찾은 글, 쓴 낱말, 버린 낱말). 요약·목록·차트가 모두 이걸 쓴다."""
    try:
        from telethon import TelegramClient
    except Exception:                                        # noqa: BLE001
        raise SearchError("telethon 이 없어 검색을 못 해요.")
    session = str(config.data_file("litebot_user"))
    api_id = int(cfg["tg_api_id"]); api_hash = cfg["tg_api_hash"]
    client = TelegramClient(session, api_id, api_hash)
    kw, dropped = _keywords(words)
    low_kw = [w.lower() for w in kw]
    try:
        await client.connect()
        if not await client.is_user_authorized():
            raise SearchError("텔레그램 개인계정 인증이 안 돼 있어요.\n"
                              "최초 1회 인증이 필요합니다(설정/로그 안내 참고).")
        since = datetime.now(KST) - timedelta(days=days)
        found = {}                                           # (방,글번호) → 건. 낱말별 검색결과를 합친다
        for word in kw:
            # 방을 하나씩 돌지 않는다 — entity=None 이면 텔레그램이 전 대화를 한 번에 검색(최신순).
            async for m in client.iter_messages(None, search=word, limit=SCAN_LIMIT):
                if m.date and m.date.astimezone(KST) < since:
                    break                                    # 최신순이라 기간 밖이면 그 뒤는 볼 것 없음
                text = (m.message or "").replace("\n", " ").strip()
                if not text or text.startswith("/") or text.startswith(("🔎 '", "📊 '")):
                    continue                                 # 내 명령·전에 받은 검색결과가 다시 걸리는 것 제외
                key = (m.chat_id, m.id)
                if key in found:
                    continue
                low = text.lower()
                found[key] = {"date": m.date.astimezone(KST), "room": _name_of(m.chat),
                              "sender": _name_of(m.sender), "text": text,
                              "score": sum(1 for w in low_kw if w in low)}
        hits = list(found.values())
        privacy.learn(h["sender"] for h in hits)             # 본 이름을 사전에 쌓아 둔다(가명 처리용)
        return hits, kw, dropped
    finally:
        await client.disconnect()


def rank(hits: list[dict]) -> tuple[list[dict], int]:
    """많이 맞은 것부터. 다 맞은 게 너무 적으면 한 칸씩 느슨하게 푼다."""
    best = max(h["score"] for h in hits)
    need = best
    while need > 1 and sum(1 for h in hits if h["score"] >= need) < 3:
        need -= 1
    out = [h for h in hits if h["score"] >= need]
    out.sort(key=lambda x: (x["score"], x["date"]), reverse=True)
    return out, need


async def _search(cfg: dict, words: list[str], days: int, collect: bool,
                  raw: str = "") -> str:
    try:
        hits, kw, dropped = await gather(cfg, words, days)
    except SearchError as e:
        return str(e)
    query = " ".join(kw)
    if not hits:
        return (f"최근 {days}일 '{query}' 검색 결과가 없어요."
                + (f"\n(무시한 말: {' '.join(dropped)})" if dropped else ""))

    hits, need = rank(hits)
    from collections import Counter
    by_room = Counter(h["room"] for h in hits)
    note = f" · '{query}' 중 {need}개 이상" if len(kw) > 1 else ""
    if dropped:
        note += f" · 무시: {' '.join(dropped[:5])}"

    if collect:
        by_sender = Counter(h["sender"] for h in hits)
        lines = [f"📊 '{query}' 취합 — 최근 {days}일 · {len(hits)}건 · {len(by_room)}개 방{note}", "",
                 "▸ 방별"]
        for r, c in by_room.most_common(10):
            lines.append(f"  {r} — {c}건")
        lines.append("")
        lines.append("▸ 사람별")
        for s, c in by_sender.most_common(10):
            lines.append(f"  {s} — {c}건")
        lines.append("")
        lines.append("▸ 최근 순")
        for h in sorted(hits, key=lambda x: x["date"], reverse=True)[:25]:
            lines.append(f"  {_fmt_dt(h['date'])} [{h['sender']}] {h['text'][:SNIPPET]}")
        if len(hits) > 25:
            lines.append(f"  … 외 {len(hits) - 25}건")
        return "\n".join(lines)

    lines = []
    if raw and llm.available(cfg):                           # 머리가 있으면 먼저 요약, 아래에 근거 목록
        body = "\n".join(f"[{_fmt_dt(h['date'])}] {h['room']} / {h['sender']}: {h['text'][:400]}"
                         for h in hits[:40])
        got = llm.ask(cfg, SUMMARY_RULE.format(question=raw) + "\n--- 찾은 글 ---\n" + body)
        if got:
            lines += ["🧠 " + got.strip(), ""]
    lines.append(f"🔎 '{query}' — 최근 {days}일 · {len(hits)}건 · {len(by_room)}개 방{note}")
    shown = 0
    rooms = sorted(by_room.items(),                          # 잘 맞은 방부터, 그 다음 건수 순
                   key=lambda rc: (max(h["score"] for h in hits if h["room"] == rc[0]), rc[1]),
                   reverse=True)
    for room, cnt in rooms[:MAX_ROOMS]:
        lines.append("")
        lines.append(f"▸ {room} ({cnt}건)")
        for h in [x for x in hits if x["room"] == room][:MAX_PER_ROOM]:
            lines.append(f"  {_fmt_dt(h['date'])} [{h['sender']}] {h['text'][:SNIPPET]}")
            shown += 1
        if cnt > MAX_PER_ROOM:
            lines.append(f"  … 이 방 {cnt - MAX_PER_ROOM}건 더")
    if len(by_room) > MAX_ROOMS:
        more = sum(c for _, c in rooms[MAX_ROOMS:])
        lines.append("")
        lines.append(f"… 그 밖에 {len(by_room) - MAX_ROOMS}개 방 {more}건")
    if len(hits) > shown:
        lines.append(f"전체 건수·사람별 집계는  /collect {query} {days}")
    return "\n".join(lines)


async def find(cfg: dict, args: list[str]) -> str:
    if not _enabled(cfg):
        return _need_msg()
    words, days = _parse(args)
    if not words:
        return "형식: /find <키워드…> [일수]   예) /find 내무부 피티 14"
    return await _search(cfg, words, days, collect=False, raw=" ".join(args))


async def collect(cfg: dict, args: list[str]) -> str:
    if not _enabled(cfg):
        return _need_msg()
    words, days = _parse(args)
    if not words:
        return "형식: /collect <키워드…> [일수]   예) /collect 전입 30"
    return await _search(cfg, words, days, collect=True)
