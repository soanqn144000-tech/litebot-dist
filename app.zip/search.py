# -*- coding: utf-8 -*-
"""⑥ 텔레그램 검색·취합 — Telethon (config에 api_id/api_hash 있을 때만).

  /find <키워드…> [일수]     → 최근 N일 대화에서 검색. 낱말 여러 개면 전부 든 것만(AND).
                               결과는 방별로 묶고 최신순. 예) /find 내무부 피티 14
  /collect <키워드…> [일수]  → 기계적 취합표(방별·사람별 건수 + 최근순). LLM 없음.

Telethon 세션은 data/litebot_user.session. 최초엔 폰 인증이 필요할 수 있어
설정 마법사/로그 안내로 처리(비대화형 exe에서는 미리 만들어진 세션 권장).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import config

KST = timezone(timedelta(hours=9))


def _enabled(cfg: dict) -> bool:
    return bool(cfg.get("tg_api_id") and cfg.get("tg_api_hash"))


def _need_msg() -> str:
    return ("이 기능은 텔레그램 API 설정이 필요합니다.\n"
            "설정에서 api_id·api_hash를 입력하세요 (https://my.telegram.org).")


MAX_ROOMS = 6                                                # 결과에 펼쳐 보여줄 방 수
MAX_PER_ROOM = 4                                             # 방마다 보여줄 메시지 수
SNIPPET = 70                                                 # 본문 미리보기 길이
SCAN_LIMIT = 500                                             # 서버에서 훑을 최대 메시지 수(기간 밖이면 먼저 끊김)


def _name_of(ent) -> str:
    """대화방·발신자 이름. 글로벌 검색은 방·사람 정보를 응답에 같이 주므로 추가 호출이 없다."""
    if ent is None:
        return "?"
    title = getattr(ent, "title", None)
    if title:
        return title
    first = getattr(ent, "first_name", "") or ""
    last = getattr(ent, "last_name", "") or ""
    return (first + " " + last).strip() or getattr(ent, "username", None) or "?"


def _parse(args: list[str]) -> tuple[list[str], int]:
    """['내무부','피티','내용','14'] → (['내무부','피티','내용'], 14). 맨 뒤 숫자만 일수로 본다."""
    days, words = 7, list(args)
    if len(words) >= 2 and words[-1].isdigit():
        days = min(int(words.pop()), 60)
    return words, days


def _fmt_dt(d: datetime) -> str:
    return f"{d:%m/%d %H:%M}"


async def _search(cfg: dict, words: list[str], days: int, collect: bool) -> str:
    try:
        from telethon import TelegramClient
    except Exception:                                        # noqa: BLE001
        return "telethon 이 없어 검색을 못 해요."
    session = str(config.data_file("litebot_user"))
    api_id = int(cfg["tg_api_id"]); api_hash = cfg["tg_api_hash"]
    client = TelegramClient(session, api_id, api_hash)
    query = " ".join(words)
    server_kw = max(words, key=len)                          # 서버 검색은 가장 긴 낱말로(가장 잘 걸러짐)
    rest = [w.lower() for w in words if w is not server_kw]  # 나머지는 받아온 뒤 AND 로 거른다
    try:
        await client.connect()
        if not await client.is_user_authorized():
            return ("텔레그램 개인계정 인증이 안 돼 있어요.\n"
                    "최초 1회 인증이 필요합니다(설정/로그 안내 참고).")
        since = datetime.now(KST) - timedelta(days=days)
        hits, wide = [], 0
        # 방을 하나씩 돌지 않는다 — entity=None 이면 텔레그램이 전 대화를 한 번에 검색(최신순).
        async for m in client.iter_messages(None, search=server_kw, limit=SCAN_LIMIT):
            if m.date and m.date.astimezone(KST) < since:
                break                                        # 최신순이라 기간 밖이면 그 뒤는 볼 것 없음
            text = (m.message or "").replace("\n", " ").strip()
            if not text or text.startswith(("🔎 '", "📊 '")):
                continue                                     # 내가 전에 보낸 검색결과가 다시 걸리는 것 제외
            wide += 1
            low = text.lower()
            if rest and not all(w in low for w in rest):
                continue                                     # 낱말 전부 든 메시지만 남긴다
            hits.append({"date": m.date.astimezone(KST), "room": _name_of(m.chat),
                         "sender": _name_of(m.sender), "text": text})
        if not hits:
            tail = (f"\n('{server_kw}' 만으로는 {wide}건 있어요 — 낱말을 줄여보세요.)"
                    if rest and wide else "")
            return f"최근 {days}일 '{query}' 검색 결과가 없어요.{tail}"
        hits.sort(key=lambda x: x["date"], reverse=True)     # 최신순 — 잘려도 최근 것이 남게

        from collections import Counter
        by_room = Counter(h["room"] for h in hits)

        if collect:
            by_sender = Counter(h["sender"] for h in hits)
            lines = [f"📊 '{query}' 취합 — 최근 {days}일 · {len(hits)}건 · {len(by_room)}개 방", "",
                     "▸ 방별"]
            for r, c in by_room.most_common(10):
                lines.append(f"  {r} — {c}건")
            lines.append("")
            lines.append("▸ 사람별")
            for s, c in by_sender.most_common(10):
                lines.append(f"  {s} — {c}건")
            lines.append("")
            lines.append("▸ 최근 순")
            for h in hits[:25]:
                lines.append(f"  {_fmt_dt(h['date'])} [{h['sender']}] {h['text'][:SNIPPET]}")
            if len(hits) > 25:
                lines.append(f"  … 외 {len(hits) - 25}건")
            return "\n".join(lines)

        lines = [f"🔎 '{query}' — 최근 {days}일 · {len(hits)}건 · {len(by_room)}개 방"]
        shown = 0
        for room, cnt in by_room.most_common(MAX_ROOMS):
            lines.append("")
            lines.append(f"▸ {room} ({cnt}건)")
            for h in [x for x in hits if x["room"] == room][:MAX_PER_ROOM]:
                lines.append(f"  {_fmt_dt(h['date'])} [{h['sender']}] {h['text'][:SNIPPET]}")
                shown += 1
            if cnt > MAX_PER_ROOM:
                lines.append(f"  … 이 방 {cnt - MAX_PER_ROOM}건 더")
        if len(by_room) > MAX_ROOMS:
            more = sum(c for _, c in by_room.most_common()[MAX_ROOMS:])
            lines.append("")
            lines.append(f"… 그 밖에 {len(by_room) - MAX_ROOMS}개 방 {more}건")
        if len(hits) > shown:
            lines.append(f"전체 건수·사람별 집계는  /collect {query} {days}")
        return "\n".join(lines)
    finally:
        await client.disconnect()


async def find(cfg: dict, args: list[str]) -> str:
    if not _enabled(cfg):
        return _need_msg()
    words, days = _parse(args)
    if not words:
        return "형식: /find <키워드…> [일수]   예) /find 내무부 피티 14"
    return await _search(cfg, words, days, collect=False)


async def collect(cfg: dict, args: list[str]) -> str:
    if not _enabled(cfg):
        return _need_msg()
    words, days = _parse(args)
    if not words:
        return "형식: /collect <키워드…> [일수]   예) /collect 전입 30"
    return await _search(cfg, words, days, collect=True)
