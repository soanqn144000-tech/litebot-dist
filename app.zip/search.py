# -*- coding: utf-8 -*-
"""⑥ 텔레그램 검색·취합 — Telethon (config에 api_id/api_hash 있을 때만).

  /find <키워드> [일수]     → 최근 N일 대화에서 키워드 검색(날짜·발신자·요약)
  /collect <키워드> [일수]  → 기계적 취합표(발신자별 건수 + 시간순). LLM 없음.

Telethon 세션은 data/litebot_user.session. 최초엔 폰 인증이 필요할 수 있어
설정 마법사/로그 안내로 처리(비대화형 exe에서는 미리 만들어진 세션 권장).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import config

KST = timezone(timedelta(hours=9))


def _enabled(cfg: dict) -> bool:
    return bool(cfg.get("tg_api_id") and cfg.get("tg_api_hash"))


def _need_msg() -> str:
    return ("이 기능은 텔레그램 API 설정이 필요합니다.\n"
            "설정에서 api_id·api_hash를 입력하세요 (https://my.telegram.org).")


async def _search(cfg: dict, keyword: str, days: int, collect: bool) -> str:
    try:
        from telethon import TelegramClient
    except Exception:                                        # noqa: BLE001
        return "telethon 이 없어 검색을 못 해요."
    session = str(config.data_file("litebot_user"))
    api_id = int(cfg["tg_api_id"]); api_hash = cfg["tg_api_hash"]
    client = TelegramClient(session, api_id, api_hash)
    try:
        await client.connect()
        if not await client.is_user_authorized():
            return ("텔레그램 개인계정 인증이 안 돼 있어요.\n"
                    "최초 1회 인증이 필요합니다(설정/로그 안내 참고).")
        since = datetime.now(KST) - timedelta(days=days)
        hits = []
        async for dialog in client.iter_dialogs():
            if not (dialog.is_group or dialog.is_channel or dialog.is_user):
                continue
            try:
                async for m in client.iter_messages(dialog.entity, search=keyword, limit=50):
                    if m.date and m.date.astimezone(KST) < since:
                        break
                    if not (m.message or ""):
                        continue
                    sender = "?"
                    try:
                        s = await m.get_sender()
                        sender = getattr(s, "first_name", None) or getattr(s, "title", None) or "?"
                    except Exception:                        # noqa: BLE001
                        pass
                    hits.append({"date": m.date.astimezone(KST), "room": dialog.name,
                                 "sender": sender, "text": (m.message or "").replace("\n", " ")})
            except Exception:                                # noqa: BLE001
                continue
        if not hits:
            return f"최근 {days}일 '{keyword}' 검색 결과가 없어요."
        hits.sort(key=lambda x: x["date"])

        if collect:
            from collections import Counter
            by_sender = Counter(h["sender"] for h in hits)
            lines = [f"📊 '{keyword}' 취합 (최근 {days}일 · 총 {len(hits)}건)", "", "· 발신자별 건수"]
            for s, c in by_sender.most_common():
                lines.append(f"  - {s}: {c}건")
            lines.append("")
            lines.append("· 시간순")
            for h in hits[:40]:
                lines.append(f"  {h['date']:%m/%d %H:%M} [{h['sender']}] {h['text'][:40]}")
            return "\n".join(lines)

        lines = [f"🔎 '{keyword}' 검색 (최근 {days}일 · {len(hits)}건)"]
        for h in hits[:30]:
            lines.append(f"· {h['date']:%m/%d %H:%M} [{h['room']}/{h['sender']}] {h['text'][:50]}")
        if len(hits) > 30:
            lines.append(f"… 외 {len(hits) - 30}건")
        return "\n".join(lines)
    finally:
        await client.disconnect()


async def find(cfg: dict, args: list[str]) -> str:
    if not _enabled(cfg):
        return _need_msg()
    if not args:
        return "형식: /find <키워드> [일수]"
    keyword, days = args[0], 7
    if len(args) >= 2 and args[1].isdigit():
        days = min(int(args[1]), 60)
    return await _search(cfg, keyword, days, collect=False)


async def collect(cfg: dict, args: list[str]) -> str:
    if not _enabled(cfg):
        return _need_msg()
    if not args:
        return "형식: /collect <키워드> [일수]"
    keyword, days = args[0], 7
    if len(args) >= 2 and args[1].isdigit():
        days = min(int(args[1]), 60)
    return await _search(cfg, keyword, days, collect=True)
