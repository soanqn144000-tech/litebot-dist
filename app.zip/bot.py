# -*- coding: utf-8 -*-
"""LiteBot 텔레그램 배선 — python-telegram-bot v20+.

주인(chat_id) 외 차단. 명령: /start /help /weather /cal /chart /task /send /alias /find /collect /remind
차트는 파일(TSV/CSV) 또는 숫자목록 메시지로.
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from functools import wraps

from telegram import Update
from telegram.ext import (Application, CommandHandler, ContextTypes,
                          MessageHandler, filters)

import cal
import chart
import config
import scheduler
import search
import sender
import tasks
import weather

log = config.get_logger()

HELP = """🤖 LiteBot 사용법

/weather — 오늘 날씨 브리핑
/cal — 오늘 일정 · /cal 주간 · /cal 추가 7/25 14:00 제목 · /cal 삭제 <번호>
/chart — 차트. 파일(TSV/CSV)이나 숫자목록을 보내면 꺾은선.
   /chart 추이 (전주대비 증감) · /chart 추세 (추세선) · /chart 12 15 9 20
/task — 반복업무. /task 추가 매일 09:00 <메시지> · /task 추가 매시간 정각 <메시지> · /task 삭제 <번호>
/send — 발송. /send 지금 <대상> <메시지> · /send 예약 7/25 09:00 <대상> <메시지>
/alias — 별칭. /alias 추가 부과장 123456789
/find <키워드> [일수] — 텔레그램 검색(API설정 필요)
/collect <키워드> [일수] — 검색결과 취합표
/remind <분> <메시지>  또는  /remind 14:00 <메시지> — 한 번 알림
"""


def owner_only(handler):
    @wraps(handler)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        cfg = config.load_config() or {}
        owner = str(cfg.get("chat_id") or "")
        uid = str(update.effective_chat.id) if update.effective_chat else ""
        if not owner or uid != owner:
            try:
                await update.message.reply_text("등록되지 않은 사용자입니다.")
            except Exception:                                # noqa: BLE001
                pass
            log.info("차단된 접근 chat=%s", uid)
            return
        context.chat_data["cfg"] = cfg
        return await handler(update, context)
    return wrapper


def _args(update: Update) -> list[str]:
    txt = update.message.text or ""
    parts = txt.split()
    return parts[1:] if parts else []


@owner_only
async def cmd_start(update, context):
    await update.message.reply_text("안녕하세요, LiteBot 입니다. /help 로 사용법을 보세요.")


@owner_only
async def cmd_help(update, context):
    await update.message.reply_text(HELP)


@owner_only
async def cmd_weather(update, context):
    await update.message.reply_text(weather.brief(context.chat_data["cfg"]))


@owner_only
async def cmd_cal(update, context):
    await update.message.reply_text(cal.handle(_args(update)))


@owner_only
async def cmd_task(update, context):
    await update.message.reply_text(tasks.handle(_args(update)))


@owner_only
async def cmd_alias(update, context):
    await update.message.reply_text(sender.alias_handle(_args(update)))


@owner_only
async def cmd_send(update, context):
    res = sender.send_handle(_args(update))
    if res["now"]:
        cid, msg = res["now"]
        try:
            await context.bot.send_message(chat_id=int(cid), text=msg)
            await update.message.reply_text(f"📤 발송 성공 → {cid}")
        except Exception as e:                               # noqa: BLE001
            await update.message.reply_text(f"❌ 발송 실패 → {cid} ({type(e).__name__})")
    else:
        await update.message.reply_text(res["reply"])


@owner_only
async def cmd_find(update, context):
    await update.message.reply_text("검색 중…")
    await update.message.reply_text(await search.find(context.chat_data["cfg"], _args(update)))


@owner_only
async def cmd_collect(update, context):
    await update.message.reply_text("취합 중…")
    await update.message.reply_text(await search.collect(context.chat_data["cfg"], _args(update)))


@owner_only
async def cmd_remind(update, context):
    args = _args(update)
    if len(args) < 2:
        await update.message.reply_text("형식: /remind 30 <메시지>  또는  /remind 14:00 <메시지>")
        return
    cfg = context.chat_data["cfg"]
    when = None
    if args[0].isdigit():                                    # N분 후
        when = datetime.now() + timedelta(minutes=int(args[0]))
    elif re.fullmatch(r"\d{1,2}:\d{2}", args[0]):            # 오늘 HH:MM
        h, m = map(int, args[0].split(":"))
        t = datetime.now().replace(hour=h, minute=m, second=0, microsecond=0)
        if t < datetime.now():
            t += timedelta(days=1)
        when = t
    if not when:
        await update.message.reply_text("시간을 못 읽었어요 (예: 30 또는 14:00).")
        return
    msg = " ".join(args[1:]).strip()
    items = config.read_json("scheduled.json", [])
    items.append({"id": max([i.get("id", 0) for i in items], default=0) + 1,
                  "when": when.strftime("%Y-%m-%d %H:%M"),
                  "chat_id": cfg["chat_id"], "message": f"🔔 {msg}"})
    config.write_json("scheduled.json", items)
    await update.message.reply_text(f"🔔 알림 예약: {when:%m/%d %H:%M}\n{msg}")


@owner_only
async def cmd_chart(update, context):
    args = _args(update)
    kinds = {"꺾은선", "추이", "추세"}
    kind = "꺾은선"
    rest = []
    for a in args:
        if a in kinds:
            kind = a
        else:
            rest.append(a)
    context.chat_data["chart_kind"] = kind
    if rest:                                                 # 숫자목록 인라인
        path = chart.make(" ".join(rest), kind=kind, title=f"{kind} 차트")
        if path:
            await update.message.reply_photo(photo=open(path, "rb"))
        else:
            await update.message.reply_text("숫자를 못 읽었어요. 예: /chart 추세 12 15 9 20")
    else:
        await update.message.reply_text(
            f"'{kind}' 준비됨. TSV/CSV 파일이나 숫자목록을 보내주세요.")


@owner_only
async def on_document(update, context):
    doc = update.message.document
    name = (doc.file_name or "").lower()
    if not name.endswith((".tsv", ".csv", ".txt")):
        await update.message.reply_text("TSV/CSV/TXT 파일만 차트로 만들 수 있어요.")
        return
    try:
        f = await context.bot.get_file(doc.file_id)
        raw = await f.download_as_bytearray()
        text = bytes(raw).decode("utf-8-sig", errors="replace")
    except Exception as e:                                   # noqa: BLE001
        await update.message.reply_text(f"파일을 못 읽었어요 ({type(e).__name__}).")
        return
    kind = context.chat_data.get("chart_kind", "꺾은선")
    path = chart.make(text, kind=kind, title=f"{kind} 차트")
    if path:
        await update.message.reply_photo(photo=open(path, "rb"))
    else:
        await update.message.reply_text("데이터에서 숫자를 못 찾았어요.")


@owner_only
async def on_text(update, context):
    """/chart 이후 숫자목록을 그냥 보냈을 때 차트로."""
    txt = (update.message.text or "").strip()
    if context.chat_data.get("chart_kind") and re.search(r"\d", txt):
        kind = context.chat_data["chart_kind"]
        path = chart.make(txt, kind=kind, title=f"{kind} 차트")
        if path:
            await update.message.reply_photo(photo=open(path, "rb"))
            return
    await update.message.reply_text("명령을 모르겠어요. /help 를 보세요.")


async def _post_init(app):
    app.create_task(scheduler.run(app))
    log.info("LiteBot 시작됨 (봇 폴링 + 스케줄러)")


def build_app(token: str) -> Application:
    app = Application.builder().token(token).post_init(_post_init).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("weather", cmd_weather))
    app.add_handler(CommandHandler("cal", cmd_cal))
    app.add_handler(CommandHandler("chart", cmd_chart))
    app.add_handler(CommandHandler("task", cmd_task))
    app.add_handler(CommandHandler("send", cmd_send))
    app.add_handler(CommandHandler("alias", cmd_alias))
    app.add_handler(CommandHandler("find", cmd_find))
    app.add_handler(CommandHandler("collect", cmd_collect))
    app.add_handler(CommandHandler("remind", cmd_remind))
    app.add_handler(MessageHandler(filters.Document.ALL, on_document))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    return app


def run_bot(token: str):
    """블로킹 — 별도 스레드에서 호출. 시그널 핸들러 설치 안 함(메인스레드 아님)."""
    import asyncio
    asyncio.set_event_loop(asyncio.new_event_loop())
    app = build_app(token)
    app.run_polling(stop_signals=None, close_loop=False)
