# -*- coding: utf-8 -*-
"""LiteBot 텔레그램 배선 — python-telegram-bot v20+.

주인(chat_id) 외 차단. 명령: /start /help /weather /cal /chart /task /send /alias /find /collect /remind /watch /report
차트는 파일(엑셀·CSV·TSV)·사진·숫자목록 아무거나 던지면 된다(사진은 머리(Gemini 키) 필요).
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from functools import wraps

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler, ContextTypes,
                          MessageHandler, filters)

import cal
import chart
import compose
import config
import extract
import forms
import guard
import learn
import llm
import ocr
import ppt
import route
import scheduler
import search
import sender
import tasks
import watch
import worklog
import weather

log = config.get_logger()

HELP = """🤖 LiteBot 사용법

💬 슬래시 없이 그냥 말해도 됩니다
   "오늘 뭐 하지" · "오늘 날씨" · "이번주 일정" · "내무부 피티 찾아줘"
   · 못 알아들으면 되물어보고, 알려주시면 다음부터 기억합니다.
   · 발송만은 항상 "이렇게 보낼까요?" 하고 확인받고 보냅니다.
   · 밖(AI)으로 나갈 때 사람 이름은 '인물1' 로 가려서 보내고, 화면엔 실명으로 되돌립니다.
   · 머리(요약·표읽기): 제미나이 무료 키 또는 클로드 프로/맥스(클로드 코드) 중 가진 것으로. 설정에서 선택.

/today — 오늘 종합(일정+날씨+알림+예약업무). AI 안 씀

/weather — 오늘 날씨 브리핑
/cal — 오늘 일정 · /cal 주간 · /cal 추가 7/25 14:00 제목 · /cal 삭제 <번호>
📊 차트 — 그냥 던지세요
   · 엑셀(.xlsx)·CSV·TSV 파일을 보내면 알아서 읽고 차트
   · 표 사진을 보내면 숫자를 읽어 차트 (머리 필요)
   · /chart 검색 <키워드> [일수] — 텔레그램을 뒤져 숫자를 모아 차트 (머리 필요)
   · /chart 12 15 9 20 · /chart 추이 · /chart 추세
/task — 반복업무. /task 추가 매일 09:00 <메시지> · /task 추가 매시간 정각 <메시지> · /task 삭제 <번호>
/send — 발송. /send 지금 <대상> <메시지> · /send 예약 7/25 09:00 <대상> <메시지>
/alias — 별칭. /alias 추가 부과장 123456789
/find <키워드…> [일수] — 텔레그램 검색. 문장으로 물어도 됨(핵심 낱말만 골라 씀).
   머리가 켜져 있으면 맨 위에 요약을 붙여 줍니다. 예) /find 내무부 피티 14
/collect <키워드…> [일수] — 같은 검색을 방별·사람별 건수로 취합
/remind <분> <메시지>  또는  /remind 14:00 <메시지> — 한 번 알림
/watch — 능동 감시(먼저 알림). 내 이름·지정어 언급, 지정한 방 새 글·파일, 마감·일정을 3분마다 확인해 알려줌
/work — 업무현황. 텔레그램을 훑어 기한 지난 것·내 답 기다리는 것·마감 임박을 정리
   · /work 14 (일수) · /work 방 서무 점검창,업무 소통창 · /work 방 (전체로 되돌림)
/memory — 배운 것 보기. /memory 지우기 <번호>
🧠 쓸수록 나아집니다
   · 「앞으로 차트에 숫자도 넣어줘 기억해」 → 바로 규칙이 됩니다
   · 「네생물은 자문·장년·부녀·청년회야」 → 우리 말로 외웁니다
   · 같은 지적을 두 번 하시면 「계속 지킬까요?」 하고 물어봅니다
/report — 정기 자동 보고. 정해둔 시각에 차트·요약을 자동 발송
   · /report 추가 매주 월 09:00 예배추이     (매주 그 시각에 주일예배 추이 차트)
   · /report 추가 매일 21:00 검색요약 내무부   (매일 그 키워드 최근 글 요약)
   · /report 삭제 <번호> · /report 지금 <번호>(테스트 실행)
/status — 머리(AI)·연결 상태
"""


def owner_only(handler):
    @wraps(handler)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        cfg = config.load_config() or {}
        owner = str(cfg.get("chat_id") or "")
        uid = str(update.effective_chat.id) if update.effective_chat else ""
        if not owner or uid != owner:
            try:
                await update.message.reply_text("등록되지 않은 사용자입니다.")
            except Exception:                                # noqa: BLE001
                pass
            log.info("차단된 접근 chat=%s", uid)
            return
        context.chat_data["cfg"] = cfg
        return await handler(update, context)
    return wrapper


def _args(update: Update, context: ContextTypes.DEFAULT_TYPE | None = None) -> list[str]:
    """명령 뒤의 인자들. 자연어로 들어온 경우엔 라우터가 넣어둔 argv 를 쓴다."""
    if context is not None:
        argv = context.chat_data.pop("argv", None)
        if argv is not None:
            return list(argv)
    txt = update.message.text or ""
    parts = txt.split()
    return parts[1:] if parts else []

async def build_dept_trend(cfg: dict, service: str = "주일"):
    """부서별(네생물 4개) 출결 추이. (intro_text, [(caption, path)]).

    교회 전체 추이와 같은 원장(예배출석현황 엑셀)을 쓰되, '총계' 대신 부서 행을 읽는다.
    교역자·장로회는 뺀다 — 117명·5명이라 한두 명 움직여도 %가 널뛰어 추세로 못 읽는다.
    """
    try:
        files = await search.find_files(cfg, ["예배출석현황"], days=200)
    except search.SearchError:
        return None, []
    svc = SERVICES.get(service) or SERVICES["주일"]
    weeks: dict = {}
    for f in files:
        if not forms.is_church_total(f["name"]):
            continue
        fd = forms.file_date(f["name"])
        if not fd or _dow(*fd) != svc["dow"]:
            continue
        weeks.setdefault("%04d-%02d-%02d" % fd, f)
    if len(weeks) < 2:
        return None, []
    keys = sorted(weeks)
    anchors = [k for k in svc["anchors"] if k in weeks]
    tail = [k for k in keys if k not in anchors][-CHART_RECENT:]
    picked = sorted(set(anchors) | set(tail))

    points = []                                               # [(예배일, {부서: {지표: 값}})]
    for key in picked:
        got = await search.download(cfg, weeks[key]["chat_id"], weeks[key]["msg_id"])
        if not got:
            continue
        text, _why = extract.read_document(got[0], got[1], cfg)
        if not text:
            continue
        dd = forms.parse_departments(text)
        if dd:                                                # 검증 실패한 주는 통째로 뺀다
            points.append((key, dd))
    if len(points) < 2:
        return None, []

    order = ["전체출석", "대면", "줌", "대체", "결석", "영상", "심방", "인시센"]
    DISP = {"대면": "현장예배 (대면)", "줌": "온라인예배 (줌)", "영상": "영상예배",
            "인시센": "인시센 — 영상예배 중", "심방": "심방예배", "대체": "대체예배",
            "전체출석": "전체출석", "결석": "결석"}

    def series(metric):
        """그 지표를 4개 부서 모두 집계한 주만 쓴다. (labels, {부서: (pcts, counts)})"""
        lb, per = [], {d: ([], []) for d in forms.NET4}
        for key, dd in points:
            vals = {}
            for dept in forms.NET4:
                d = dd.get(dept) or {}
                v, cap = d.get(metric), d.get("출결재적")
                if v is None or not cap:
                    vals = {}
                    break                                     # 한 부서라도 없으면 그 주는 통째로 건너뛴다
                vals[dept] = (round(v / cap * 100, 1), v)
            if not vals:
                continue
            lb.append(f"{int(key[5:7]):02d}/{int(key[8:10]):02d}")
            for dept, (pc, cn) in vals.items():
                per[dept][0].append(pc)
                per[dept][1].append(cn)
        return lb, per

    metrics = [m for m in order if any(series(m)[1][d][1] for d in forms.NET4)]
    foot = ("※ 텔레그램 보고방의 예배출석현황 엑셀에서 부서별로 자동 집계(총회등록+교회등록+입교 합산) · "
            "부서 합계 = 총계 행과 대조해 맞는 주만 씀 · 교역자·장로회는 인원이 적어 제외")
    intro = (f"📊 부서별 {svc['label']} 출결 추이 · 지표별 {len(metrics)}장\n"
             f"자문회·장년회·부녀회·청년회 (네생물) · 각 선 끝에 % 와 명수")
    photos = []
    for i, metric in enumerate(metrics, 1):
        lb, per = series(metric)
        if len(lb) < 2:
            continue
        rng = f"{lb[0].replace('/', '.')}~{lb[-1].replace('/', '.')}".replace(".0", ".")
        # 지표명은 바로 아래 큰 글씨로 또 찍힌다 — 제목엔 넣지 않는다(두 줄로 겹쳐 보임)
        sup = f"부서별 {svc['label']} 출결 — 자문·장년·부녀·청년 ({rng})  [{i}/{len(metrics)}]"
        path = chart.make_dept_trend(lb, metric, per, out_name=f"dept_{svc['dow']}_{i}.png",
                                     suptitle=sup, footer=foot,
                                     disp=DISP.get(metric, metric))
        if path:
            photos.append((f"{DISP.get(metric, metric)}  ({i}/{len(metrics)})", path))
    return intro, photos


@owner_only
async def cmd_start(update, context):
    await update.message.reply_text("안녕하세요, LiteBot 입니다. /help 로 사용법을 보세요.")


@owner_only
async def cmd_help(update, context):
    await update.message.reply_text(HELP)


@owner_only
async def cmd_watch(update, context):
    """능동 감시 켜고 끄기·설정. /watch · /watch 켜기 · /watch 끄기 ·
    /watch 말 내무부,PT · /watch 방 취합창 · /watch 이름 안성훈"""
    args = _args(update, context)
    cfg = context.chat_data["cfg"]
    if not args:
        await update.message.reply_text(
            watch.status(cfg) + "\n\n"
            "· /watch 켜기 · /watch 끄기\n"
            "· /watch 말 내무부,PT,취합   (언급되면 알림)\n"
            "· /watch 방 취합 및 보고창    (그 방 새 글·파일 알림)\n"
            "· /watch 이름 안성훈          (내 이름 언급 알림)\n"
            "감시는 3분마다 자동으로 새 것만 알려줍니다.")
        return
    sub = args[0]
    rest = " ".join(args[1:]).strip()
    if sub in ("켜기", "on", "켜"):
        cfg["watch_on"] = True; config.save_config(cfg)
        config.write_json(watch.STATE, {})                   # 기준선 새로(옛 글 도배 방지)
        await update.message.reply_text("🔔 능동 감시 켰어요. 지금부터 새로 올라오는 것만 알려드려요.\n" + watch.status(cfg))
    elif sub in ("끄기", "off", "꺼"):
        cfg["watch_on"] = False; config.save_config(cfg)
        await update.message.reply_text("🔕 능동 감시 껐어요.")
    elif sub in ("말", "키워드", "단어") and rest:
        cfg["watch_keywords"] = rest; config.save_config(cfg)
        await update.message.reply_text(f"🗣 감시할 말: {rest}\n" + watch.status(cfg))
    elif sub in ("방", "채팅", "룸") and rest:
        cfg["watch_rooms"] = rest; config.save_config(cfg)
        await update.message.reply_text(f"📥 감시할 방: {rest}\n" + watch.status(cfg))
    elif sub in ("이름", "내이름") and rest:
        cfg["my_name"] = rest; config.save_config(cfg)
        await update.message.reply_text(f"🙋 내 이름: {rest} (언급되면 알림)\n" + watch.status(cfg))
    else:
        await update.message.reply_text("사용법: /watch 켜기 · /watch 말 내무부,PT · /watch 방 취합창 · /watch 이름 안성훈")


@owner_only
async def cmd_report(update, context):
    """정기 자동 보고 — 정해둔 시각에 차트·요약을 자동 발송.
    /report · /report 추가 매주 월 09:00 예배추이 · /report 추가 매일 21:00 검색요약 내무부 · /report 삭제 1
    · /report 지금 1  → 그 보고를 지금 한 번 실행(테스트)."""
    import report
    args = _args(update, context)
    if args and args[0] in ("지금", "실행", "테스트"):
        items = report._load()
        if len(args) < 2 or not args[1].isdigit() or not (1 <= int(args[1]) <= len(items)):
            await update.message.reply_text("형식: /report 지금 <번호>  (번호는 /report 로 확인)")
            return
        await report.run(context.application, update.effective_chat.id,
                         context.chat_data["cfg"], items[int(args[1]) - 1], log)
        return
    await update.message.reply_text(report.handle(args))


@owner_only
async def cmd_status(update, context):
    cfg = context.chat_data["cfg"]
    ver = "?"
    try:
        ver = (config.APP_DIR / "app" / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:                                        # noqa: BLE001
        pass
    tg = "연결됨" if (cfg.get("tg_api_id") and cfg.get("tg_api_hash")) else "미설정(/find 불가)"
    await update.message.reply_text(
        f"🤖 LiteBot v{ver}\n"
        f"· 머리(AI): {llm.status(cfg)}\n"
        f"· 텔레그램 검색: {tg}\n"
        f"· 캘린더: {'연결됨' if cfg.get('icloud_id') else '미설정'}\n"
        f"· 브리핑: 매일 {cfg.get('briefing_time', '07:30')}")


@owner_only
async def cmd_today(update, context):
    """'오늘 뭐 하지' — 일정·날씨·알림·예약업무를 한 번에 엮어서. AI 안 씀."""
    await update.message.reply_text(compose.day_plan(context.chat_data["cfg"]))


@owner_only
async def cmd_weather(update, context):
    await update.message.reply_text(weather.brief(context.chat_data["cfg"]))


@owner_only
async def cmd_cal(update, context):
    await update.message.reply_text(cal.handle(_args(update, context)))


@owner_only
async def cmd_task(update, context):
    await update.message.reply_text(tasks.handle(_args(update, context)))


@owner_only
async def cmd_alias(update, context):
    await update.message.reply_text(sender.alias_handle(_args(update, context)))


AI_MARK = "(AI 통해 발송한 메시지)"


def with_ai_mark(text: str) -> str:
    """남에게 나가는 글에는 AI 가 대신 보낸 것임을 밝힌다.

    받는 쪽은 동료다. 사람이 직접 쓴 말인지 AI 가 대신 보낸 말인지 구분이 안 되면
    상대가 오해한다(2026-08-13 부장님 지시). 예약발송·즉시발송 모두 붙인다.
    """
    t = (text or "").rstrip()
    if AI_MARK in t:                                          # 이미 붙어 있으면 두 번 안 붙인다
        return t
    return f"{t}\n\n{AI_MARK}"


@owner_only
async def cmd_send(update, context):
    res = sender.send_handle(_args(update, context))
    if res["now"]:
        cid, msg = res["now"]
        try:
            await context.bot.send_message(chat_id=int(cid), text=with_ai_mark(msg))
            await update.message.reply_text(f"📤 발송 성공 → {cid}")
        except Exception as e:                               # noqa: BLE001
            await update.message.reply_text(f"❌ 발송 실패 → {cid} ({type(e).__name__})")
    else:
        await update.message.reply_text(res["reply"])


@owner_only
async def cmd_find(update, context):
    await update.message.reply_text("검색 중…")
    await update.message.reply_text(await search.find(context.chat_data["cfg"], _args(update, context)))


@owner_only
async def cmd_collect(update, context):
    await update.message.reply_text("취합 중…")
    await update.message.reply_text(await search.collect(context.chat_data["cfg"], _args(update, context)))


@owner_only
async def cmd_remind(update, context):
    args = _args(update, context)
    if len(args) < 2:
        await update.message.reply_text("형식: /remind 30 <메시지>  또는  /remind 14:00 <메시지>")
        return
    cfg = context.chat_data["cfg"]
    when = None
    if args[0].isdigit():                                    # N분 후
        when = datetime.now() + timedelta(minutes=int(args[0]))
    elif re.fullmatch(r"\d{1,2}:\d{2}", args[0]):            # 오늘 HH:MM
        h, m = map(int, args[0].split(":"))
        t = datetime.now().replace(hour=h, minute=m, second=0, microsecond=0)
        if t < datetime.now():
            t += timedelta(days=1)
        when = t
    if not when:
        await update.message.reply_text("시간을 못 읽었어요 (예: 30 또는 14:00).")
        return
    msg = " ".join(args[1:]).strip()
    items = config.read_json("scheduled.json", [])
    items.append({"id": max([i.get("id", 0) for i in items], default=0) + 1,
                  "when": when.strftime("%Y-%m-%d %H:%M"),
                  "chat_id": cfg["chat_id"], "message": f"🔔 {msg}"})
    config.write_json("scheduled.json", items)
    await update.message.reply_text(f"🔔 알림 예약: {when:%m/%d %H:%M}\n{msg}")


@owner_only
async def cmd_chart(update, context):
    args = _args(update, context)
    if args and args[0] in ("검색", "텔레", "텔레그램"):        # /chart 검색 <키워드…> [일수]
        await _chart_from_telegram(update, context, args[1:])
        return
    kinds = {"꺾은선", "추이", "추세"}
    kind = "꺾은선"
    rest = []
    for a in args:
        if a in kinds:
            kind = a
        else:
            rest.append(a)
    context.chat_data["chart_kind"] = kind
    if rest:                                                 # 숫자목록 인라인
        path = chart.make(" ".join(rest), kind=kind, title=f"{kind} 차트")
        if path:
            await update.message.reply_photo(photo=open(path, "rb"))
        else:
            await update.message.reply_text("숫자를 못 읽었어요. 예: /chart 추세 12 15 9 20")
    else:
        await update.message.reply_text(
            f"'{kind}' 준비됨. TSV/CSV 파일이나 숫자목록을 보내주세요.")


def _dow(y, m, d) -> int:
    from datetime import date as _date
    return _date(y, m, d).weekday()


# 차트에 항상 붙이는 기준 주(사고처리 직전·직후 비교) + 최신 N주. 아델 weekly_auto 와 같은 값.
CHART_ANCHORS = ["2026-03-22", "2026-03-29"]                  # 주일 기준 주(원장에 있으면 항상 포함)
CHART_RECENT = 9

# 예배 종류. 요일로 가른다 — 파일 이름엔 주일/수요 구분이 없다.
# 강동에서는 수요예배를 '삼일예배' 라고도 부른다.
SERVICES = {"주일": {"dow": 6, "label": "주일예배", "anchors": CHART_ANCHORS},
            "수요": {"dow": 2, "label": "삼일(수요)예배", "anchors": []}}
WED_WORDS = ("삼일", "수요", "수욜", "수예")


async def build_attendance_trend(cfg: dict, service: str = "주일"):
    """예배출석현황 여러 주 → 추이 산출물. (intro_text, [(caption, path)]) 반환.
    파일·데이터가 모자라면 (None, [])。 대화·스케줄 양쪽이 이걸 쓴다(창구 무관)."""
    try:
        files = await search.find_files(cfg, ["예배출석현황"], days=200)   # 기준 주(3/22)까지 닿게
    except search.SearchError:
        return None, []
    svc = SERVICES.get(service) or SERVICES["주일"]
    weeks: dict = {}                                         # (예배일) → 교회전체 파일 1개(최신 올린 것)
    for f in files:
        if not forms.is_church_total(f["name"]):
            continue
        fd = forms.file_date(f["name"])
        if not fd or _dow(*fd) != svc["dow"]:                # 그 예배 요일만
            continue
        key = "%04d-%02d-%02d" % fd
        weeks.setdefault(key, f)
    if len(weeks) < 2:
        return None, []
    # 아델과 같은 방식: '기준 주 고정 + 최신 N주'.
    # 매주 전부를 그리면 점이 늘어나 라벨이 서로 밟혀 숫자를 못 읽는다. 점 개수를 일정하게 두면
    # 한 주가 지나도 앞의 한 주가 자동으로 빠져 라벨을 다 찍어도 안 겹친다(사용자 규칙 2026-08-06).
    keys = sorted(weeks)
    anchors = [k for k in svc["anchors"] if k in weeks]       # 원장에 실제로 있는 기준 주만
    tail = [k for k in keys if k not in anchors][-CHART_RECENT:]
    picked = sorted(set(anchors) | set(tail))
    points = []
    for key in picked:
        got = await search.download(cfg, weeks[key]["chat_id"], weeks[key]["msg_id"])
        if not got:
            continue
        text, _why = extract.read_document(got[0], got[1], cfg)
        if not text:
            continue
        d = forms.parse_total(text)
        if d:
            points.append((key, d))
    if len(points) < 2:
        return None, []

    labels = [f"{int(k[5:7]):02d}/{int(k[8:10]):02d}" for k, _ in points]
    재적 = [d["출결재적"] for _, d in points]
    order = ["전체출석", "대면", "줌", "대체", "결석", "영상", "심방", "인시센"]
    # 엑셀 머리글 그대로 쓴 정식 이름. 속이름(줌·영상…)은 그대로 두고 보이는 이름만 바꾼다
    # — 판정색·정렬이 속이름을 보기 때문이다. (2026-08-13 부장님 지적: 분류가 헷갈린다)
    DISP = {"대면": "현장예배 (대면)", "줌": "온라인예배 (줌)", "영상": "영상예배",
            "인시센": "인시센 — 영상예배 중", "심방": "심방예배", "대체": "대체예배",
            "전체출석": "전체출석", "결석": "결석"}
    def series(name):
        """그 지표를 실제로 집계한 주만 골라 (라벨, %, 명) 로 준다.

        집계 안 하던 주를 0 으로 채우면 안 된다. '영상예배 0명' 과 '영상예배 칸이 없음' 은
        다른 말인데 선이 바닥에 붙어 0명인 것처럼 보인다(2026-08-13 확인) — 그 주는 아예 뺀다.
        """
        lb, pc, cn = [], [], []
        for (key, d), cap in zip(points, 재적):
            v = d.get(name)
            if v is None or not cap:                          # 미집계 주는 점을 찍지 않는다
                continue
            lb.append(f"{int(key[5:7]):02d}/{int(key[8:10]):02d}")
            pc.append(round(v / cap * 100, 1))
            cn.append(v)
        return lb, pc, cn

    # ── 집계 가드 — 없는 값을 있는 것처럼 그리지 않는다(guard.py, 4,445 사건 대응)
    ref = series("전체출석")[2]
    reports = {}
    for n in order:
        vals = []                                            # 미집계 주는 None 으로 둔다(0 아님)
        for _key, d in points:
            vals.append(d.get(n))
        reports[DISP.get(n, n)] = guard.audit(DISP.get(n, n), vals,
                                              ref=ref if n != "전체출석" else None)
    guard_note = guard.summarize(reports)
    if guard_note:
        log.info("집계 가드:\n%s", guard_note)

    metrics = [n for n in order if any(series(n)[2])]
    span = f"{int(points[0][0][5:7])}.{int(points[0][0][8:10])}~{int(points[-1][0][5:7])}.{int(points[-1][0][8:10])}"
    cmp_label = f"{labels[-2]} → {labels[-1]}" if len(labels) >= 2 else labels[-1]
    foot = ("※ 텔레그램 보고방의 예배출석현황 엑셀에서 자동 집계 · "
            "영상예배 = 인시센 + 그외 (인시센은 영상예배에 포함된 세부 항목) · "
            "영상예배·심방예배는 7/5 신양식부터 생긴 칸 — 그 전엔 칸 자체가 없어 선이 없음")
    sub1 = ("진한 선=해당 분류(출결재적 대비 %) · y축=% · 라벨=명수+% · 점선=추세선 · "
            "엑셀이 없는 주는 칸 자체가 없음")
    sub2 = (f"제목 증감 = 직전 전주 대비 ({cmp_label}) · 제목색은 지표 성격 기준 — "
            "긍정(전체·대면): 명↑ 초록 / 명↓%↑ 노랑 / 명↓%↓ 빨강   |   "
            "부정(줌·대체·인시센·심방·영상·결석): 명↓%↓ 초록 / 명↓%↑ 노랑 / 명↑ 빨강")
    intro = (f"📊 {svc['label']} 출결 추이 ({labels[0]}~{labels[-1]}, {len(points)}주) · 지표별 {len(metrics)}장\n"
             f"각 점: 위=출결재적 대비 % · 아래=명수")
    if guard_note:                                           # 왜 어떤 선이 짧은지·없는지 밝힌다
        intro += "\n\n" + guard_note
    photos = []
    for i, name in enumerate(metrics, 1):
        page = f"{i}/{len(metrics)}"
        lb_n, pc_n, cn_n = series(name)
        if len(pc_n) < 2:
            continue
        rng = f"{lb_n[0].replace('/', '.')}~{lb_n[-1].replace('/', '.')}".replace(".0", ".")
        sup = f"강동교회 전체 {svc['label']} 출결 — 출석분류별 변동추이 ({rng})  [{page}]"
        path = chart.make_trend_one(lb_n, name, pc_n, cn_n,
                                    page=page, footer=foot, out_name=f"trend_{svc['dow']}_{i}.png",
                                    suptitle=sup, sub1=sub1, sub2=sub2,
                                    disp=DISP.get(name, name))
        if path:
            photos.append((f"{DISP.get(name, name)}  ({page})", path))
    return intro, photos


# '부서별' 을 말하는 여러 방식. 아델에서 이걸 못 알아들어 매번 교회 전체를 주던 문제가 있었다.
DEPT_WORDS = ("부서별", "부서 별", "각 부서", "부서마다", "부서 비교", "네생물", "자장부청",
              "자문회", "장년회", "부녀회", "청년회")


# 'PPT 로 만들어줘' 를 말하는 방식들
PPT_WORDS = ("ppt", "PPT", "피피티", "파워포인트", "발표자료", "발표 자료", "보고서로", "슬라이드")


async def _send_deck(update, context, photos: list, title: str, subtitle: str, foot: str,
                     fname: str) -> bool:
    """차트 PNG 들을 PPT 한 파일로 묶어 보낸다. 못 만들면 False."""
    if not photos:
        return False
    path = ppt.make_deck([p for _c, p in photos], title, subtitle, foot, out_name=fname)
    if not path:
        await update.message.reply_text("PPT 를 못 만들었어요. 차트는 위에 그대로 있습니다.")
        return False
    with open(path, "rb") as f:
        await update.message.reply_document(
            document=f, filename=fname,
            caption=f"📑 {title} — 표지 1 + 차트 {len(photos)}장")
    return True


async def _attendance_trend(update, context, kw: list[str], as_rate: bool,
                            by_dept: bool = False, want_ppt: bool = False,
                            service: str = "주일") -> bool:
    """대화 경로 — 추이를 만들어 이 방에 보낸다. 못 하면 False."""
    cfg = context.chat_data["cfg"]
    svc = SERVICES.get(service) or SERVICES["주일"]
    what = "부서별(자문·장년·부녀·청년)" if by_dept else "교회 전체"
    await update.message.reply_text(
        f"{svc['label']} 출결현황을 모아 {what} 추이를 그립니다… (여러 주치라 30초쯤 걸려요)")
    intro, photos = await (build_dept_trend(cfg, service) if by_dept
                           else build_attendance_trend(cfg, service))
    if not photos:
        return False
    await update.message.reply_text(intro)
    for caption, path in photos:
        await update.message.reply_photo(photo=open(path, "rb"), caption=caption)
    if want_ppt:                                              # 차트를 보여준 뒤 파일로도 한 번 더
        span = intro.split("(")[-1].split(",")[0] if "(" in intro else ""
        # 파일명은 ASCII 만. 한글 파일명은 받는 쪽에서 다운로드가 깨진다(집안 규칙).
        tag = "wed" if service == "수요" else "sun"
        await _send_deck(
            update, context, photos,
            f"{'부서별 ' if by_dept else ''}{svc['label']} 출결 추이",
            ("자문회 · 장년회 · 부녀회 · 청년회" if by_dept else "강동교회 전체")
            + (f" ({span})" if span else ""),
            "강동교회 내무부 · 텔레그램 보고방의 예배출석현황 엑셀에서 자동 집계",
            f"{'dept' if by_dept else 'church'}_{tag}_attendance_trend.pptx")
    return True


async def _chart_from_telegram(update, context, words: list[str]) -> None:
    """텔레그램을 직접 뒤져서 차트.
    ⓪ 예배출석현황이면 여러 주 추이 꺾은선(아델식) ① 단일 파일 ② 글 속 숫자.
    """
    cfg = context.chat_data["cfg"]
    raw = (update.message.text or "")
    if not words:
        await update.message.reply_text(
            "무엇으로 차트를 만들까요?\n"
            "예) 예배 출석 추이 그려줘 · 취합창에 어제 올라온 출석 파일로 차트")
        return
    h = search.hints(raw)
    kw, days = search.parse_args(words)
    kw = search.strip_hints(kw, h)                           # 방·사람·때·날짜는 검색어에서 뺀다(조건으로만 씀)

    # ⓪ 예배 출석 요청 & 특정 날짜를 콕 집지 않았으면 → 아델식 여러 주 추이(꺾은선)
    joined = "".join(kw)
    wants_att = ("예배" in joined or "출석" in joined or "출결" in joined or "주차별" in raw)
    forced_trend = any(w in raw for w in ("추이", "변동", "추세", "주차별", "주별", "매주"))
    single = (h["date"] or any(w in raw for w in ("이 파일", "그 파일", "한 주", "그날", "단일"))) \
        and not forced_trend
    if wants_att and not single:
        # 아델과 같게 기본은 '비율(%)'. '인원/명/수'를 콕 집으면 인원.
        as_rate = not any(k in raw for k in ("인원", "명수", "몇 명", "인원수")) \
            or any(k in raw for k in ("률", "율", "%", "비율", "퍼센트"))
        by_dept = any(w in raw for w in DEPT_WORDS)
        want_ppt = any(w in raw for w in PPT_WORDS)
        service = "수요" if any(w in raw for w in WED_WORDS) else "주일"
        if await _attendance_trend(update, context, kw, as_rate, by_dept, want_ppt, service):
            return
        if by_dept and await _attendance_trend(update, context, kw, as_rate,
                                               False, want_ppt, service):
            return                                            # 부서별이 안 되면 교회 전체라도

    days = h["days"] or (days if days != 7 else 45)           # 파일은 좀 더 넓게 본다
    where = " · ".join(x for x in [h["room"] and f"방:{h['room']}",
                                   h["person"] and f"올린이:{h['person']}",
                                   h["date"] and f"날짜:{h['date']}"] if x)
    await update.message.reply_text(
        f"텔레그램에서 파일 찾는 중… ('{' '.join(kw)}' 최근 {days}일{' · ' + where if where else ''})")

    try:                                                     # ① 첨부파일 먼저
        files = await search.find_files(cfg, kw, days, room=h["room"], person=h["person"],
                                        want_date=h["date"])
    except search.SearchError as e:
        await update.message.reply_text(str(e))
        return

    for f in files[:3]:                                      # 잘 맞는 것부터 실제로 열어본다
        got = await search.download(cfg, f["chat_id"], f["msg_id"])
        if not got:
            continue
        name, data = got
        text, why = extract.read_document(name, data, cfg)
        if text is None:
            continue
        await update.message.reply_text(
            f"📄 {name}\n   {f['date']:%m/%d %H:%M} · {f['room']} · {f['sender']}\n   읽는 중…")
        spec, how = extract.spec_from_text(cfg, text, " ".join(kw))
        if spec:
            spec.setdefault("footer", f"{name} · {f['date']:%Y-%m-%d} · {f['room']}")
            if await _send_spec(update, spec, how):
                return
        await update.message.reply_text("   이 파일에선 숫자를 못 뽑았어요. 다음 파일을 봅니다…")

    if not llm.available(cfg):                               # ② 글 속 숫자 — 여기서부턴 머리가 필요
        await update.message.reply_text(
            "쓸 만한 파일을 못 찾았어요. 글에서 숫자를 뽑으려면 머리(AI)가 필요합니다.\n"
            f"· 현재: {llm.status(cfg)}")
        return
    try:
        hits, used, _dropped = await search.gather(cfg, kw, days)
    except search.SearchError as e:
        await update.message.reply_text(str(e))
        return
    if not hits:
        await update.message.reply_text("그 낱말로는 파일도 글도 못 찾았어요.")
        return
    hits, _need = search.rank(hits)
    if h["room"] or h["person"]:                             # 단서가 있으면 그걸로 좁힌다
        narrowed = [x for x in hits if search._match_hint(x["room"], h["room"])
                    and search._match_hint(x["sender"], h["person"])]
        hits = narrowed or hits
    spec, how = extract.spec_from_messages(cfg, hits, raw)
    if spec:
        spec.setdefault("footer", f"텔레그램 '{' '.join(used)}' 최근 {days}일 · {len(hits)}건")
        if await _send_spec(update, spec, how):
            return
    await update.message.reply_text(
        f"파일은 {len(files)}개, 글은 {len(hits)}건 찾았는데 차트로 만들 숫자를 못 뽑았어요.\n"
        f"/find {' '.join(kw)} 로 내용부터 보시겠어요?")


async def _send_spec(update, spec: dict, how: str) -> bool:
    """차트 규격 → PNG 발송. 어떻게 읽었는지(AI/규칙)도 알려준다."""
    path = chart.make_spec(spec)
    if not path:
        return False
    cap = f"{spec.get('title') or '데이터 차트'}  ({'AI 해석' if how == 'AI' else '규칙 해석'})"
    await update.message.reply_photo(photo=open(path, "rb"), caption=cap[:1000])
    return True


@owner_only
async def on_document(update, context):
    """파일을 던지면 알아서 차트. 엑셀·CSV·TSV·TXT."""
    doc = update.message.document
    name = doc.file_name or ""
    hint = (update.message.caption or "").strip()
    try:
        f = await context.bot.get_file(doc.file_id)
        raw = bytes(await f.download_as_bytearray())
    except Exception as e:                                   # noqa: BLE001
        await update.message.reply_text(f"파일을 못 받았어요 ({type(e).__name__}).")
        return
    text, why = extract.read_document(name, raw, context.chat_data["cfg"])
    if text is None:
        await update.message.reply_text(why or "파일을 못 읽었어요.")
        return
    await update.message.reply_text("읽는 중…")
    spec, how = extract.spec_from_text(context.chat_data["cfg"], text, hint)
    if spec and await _send_spec(update, spec, how):
        return
    kind = context.chat_data.get("chart_kind", "꺾은선")      # 마지막 보루: 예전 방식
    path = chart.make(text, kind=kind, title=hint or f"{kind} 차트")
    if path:
        await update.message.reply_photo(photo=open(path, "rb"))
    else:
        await update.message.reply_text("데이터에서 숫자를 못 찾았어요.")


@owner_only


@owner_only
async def on_photo(update, context):
    """사진(표·보고 캡처)을 던지면 글자를 읽는다.

    머리(AI)가 있으면 머리가 읽고, 없으면 맥에 원래 들어있는 판독기가 읽는다(공짜·오프라인).
    둘 다 없는 기기에서만 못 한다고 답한다.
    """
    cfg = context.chat_data["cfg"]
    if not (llm.available(cfg) or ocr.available()):
        await update.message.reply_text(
            "이 기기에서는 사진 속 글자를 못 읽어요.\n"
            "· 맥이면 그냥 됩니다(기본 판독기).\n"
            "· 윈도우면 설정 → '선택 기능' 에서 Gemini 무료 키를 넣어주세요.")
        return
    try:
        f = await context.bot.get_file(update.message.photo[-1].file_id)
        jpg = bytes(await f.download_as_bytearray())
    except Exception as e:                                   # noqa: BLE001
        await update.message.reply_text(f"사진을 못 받았어요 ({type(e).__name__}).")
        return
    hint = (update.message.caption or "").strip()
    await update.message.reply_text(
        "사진 읽는 중…" + ("" if llm.available(cfg) else " (맥 기본 판독기)"))
    spec, how = extract.spec_from_image(cfg, jpg, hint)
    if spec and await _send_spec(update, spec, how):
        if how == "판독":
            # 판독기는 촘촘한 표에서 칸을 섞는다(실제로 확인함). 숫자를 그대로 믿게 두면 안 된다.
            await update.message.reply_text(
                "⚠️ 위 숫자는 사진을 글자로 읽어 만든 것입니다. 표가 촘촘하면 칸이 섞일 수 있으니 "
                "원본과 한 번 맞춰보세요. 원문이 필요하면 `/판독` 이라고 답해주세요.")
        return
    # 차트가 안 나와도 읽은 글자는 돌려준다 — 사용자가 직접 보고 판단할 수 있게.
    txt, why = ocr.read_image(jpg)
    if txt:
        await update.message.reply_text(f"표·숫자로는 못 묶었지만 글자는 읽었어요:\n\n{txt[:3000]}")
    else:
        await update.message.reply_text(
            f"사진에서 표·숫자를 못 찾았어요{(' — ' + why) if why else ''}. 또렷하게 다시 찍어주세요.")


YES = re.compile(r"^(응|어|네|예|ㅇㅇ|그래|맞아|보내|보내줘|ok|okay|yes)\b", re.I)
NO = re.compile(r"^(아니|아냐|취소|하지마|no)\b", re.I)

EXTRACT_SEND = """사용자가 텔레그램 메시지를 보내달라고 했다. 받는 사람과 보낼 내용을 뽑아 JSON 하나만 뱉어라.
설명 금지. 형식: {"target":"받는사람(별칭·이름·숫자id)","message":"보낼 내용"}
받는 사람을 모르겠으면 target 을 "" 로 둬라."""


async def _prepare_send(update, context, text: str) -> None:
    """발송은 절대 바로 쏘지 않는다 — 무엇을 누구에게 보낼지 보여주고 확인받는다."""
    cfg = context.chat_data["cfg"]
    target = msg = ""
    if llm.available(cfg):
        import json as _json
        got = llm.ask(cfg, f"{EXTRACT_SEND}\n\n사용자: {text}") or ""
        m = re.search(r"\{.*\}", got, re.S)
        if m:
            try:
                obj = _json.loads(m.group(0))
                target, msg = str(obj.get("target") or ""), str(obj.get("message") or "")
            except Exception:                                # noqa: BLE001
                pass
    if not (target and msg):
        await update.message.reply_text(
            "누구에게 무엇을 보낼지 못 알아들었어요.\n"
            "· /send 지금 <대상> <메시지>\n· 대상은 /alias 추가 <이름> <chat_id> 로 등록해두면 편해요.")
        return
    cid = sender.resolve(target)
    if not cid:
        await update.message.reply_text(
            f"대상 '{target}'를 못 찾았어요. /alias 추가 {target} <chat_id> 로 등록해주세요.")
        return
    context.chat_data["pending_send"] = {"cid": cid, "target": target, "text": msg}
    await update.message.reply_text(
        f"이렇게 보낼까요?\n\n받는 곳: {target}\n내용: {with_ai_mark(msg)}\n\n맞으면 '응', 아니면 '아니'.")


@owner_only
async def on_text(update, context):
    """슬래시 없이 그냥 말해도 알아듣게. 처리가 어느 길로 끝나든 승격 제안은 마지막에 한 번."""
    try:
        await _on_text(update, context)
    finally:
        await _offer_promote(update, context)


async def _on_text(update, context):
    """실제 처리 — 규칙 라우터, 안 되면 머리(AI) 라우터."""
    txt = (update.message.text or "").strip()
    cfg = context.chat_data["cfg"]

    if await _handle_learn(update, context, txt):            # ⓪ 방금 가르쳐 주는 중이면
        return

    if await _learn_from(update, txt):                       # ⓪-b 규칙·용어를 대놓고 알려준 것
        return
    _note_correction(txt, context)                           # ⓪-c 지적이면 조용히 적어둔다

    pend = context.chat_data.get("pending_send")             # ① 발송 확인 대기 중
    if pend:
        if YES.match(txt):
            context.chat_data.pop("pending_send", None)
            try:
                await context.bot.send_message(chat_id=int(pend["cid"]),
                                               text=with_ai_mark(pend["text"]))
                await update.message.reply_text(f"📤 발송 성공 → {pend['target']}")
            except Exception as e:                           # noqa: BLE001
                await update.message.reply_text(f"❌ 발송 실패 → {pend['target']} ({type(e).__name__})")
            return
        if NO.match(txt):
            context.chat_data.pop("pending_send", None)
            await update.message.reply_text("취소했어요.")
            return
        context.chat_data.pop("pending_send", None)          # 딴 말이면 발송은 없던 일로

    if context.chat_data.get("chart_kind") and re.search(r"\d", txt):   # ② /chart 뒤 숫자목록
        kind = context.chat_data["chart_kind"]
        path = chart.make(txt, kind=kind, title=f"{kind} 차트")
        if path:
            await update.message.reply_photo(photo=open(path, "rb"))
            return

    cmd, args, how = route.route(cfg, txt)                   # ③ 자연어 → 명령
    if cmd == "send_confirm":
        await _prepare_send(update, context, txt)
        return
    if cmd:
        log.info("자연어 라우팅(%s): %s → /%s %s", how, txt[:40], cmd, " ".join(args)[:40])
        context.chat_data["argv"] = args
        if await _dispatch(update, context, cmd):
            return
        context.chat_data.pop("argv", None)

    if llm.available(cfg):                                   # ④ 명령이 아니면 그냥 대답
        got = llm.ask(cfg, "너는 교회 행정 비서다. 짧고 정확하게 한국어로 답해라. "
                           "모르면 모른다고 해라. 5줄 이내.\n\n" + txt)
        if got:
            await update.message.reply_text(got.strip())
            return

    context.chat_data["pending_learn"] = txt                 # ⑤ 못 알아들었으면 배운다
    await update.message.reply_text(
        "이 말은 아직 모릅니다. 무엇을 하라는 거였나요?\n"
        "  오늘 · 날씨 · 일정 · 검색 · 취합 · 차트 · 알림 · 상태\n"
        "중 하나로 답해주시면 다음부터는 바로 알아듣습니다. (건너뛰려면 '됐어')")


LEARN_WORDS = {"오늘": "today", "날씨": "weather", "일정": "cal", "검색": "find",
               "취합": "collect", "차트": "chart", "알림": "remind", "상태": "status"}


async def _dispatch(update, context, cmd: str) -> bool:
    handler = {"today": cmd_today, "weather": cmd_weather, "cal": cmd_cal, "find": cmd_find,
               "collect": cmd_collect, "chart": cmd_chart, "task": cmd_task,
               "remind": cmd_remind, "status": cmd_status}.get(cmd)
    if not handler:
        return False
    await handler(update, context)
    return True


async def _learn_from(update, txt: str) -> bool:
    """'기억해 / 규칙 추가' 로 대놓고 알려준 것만 규칙으로 만든다. 추측해서 만들지 않는다."""
    content = learn.register_intent(txt)
    if content:
        r = learn.add_rule(content, src="직접")
        if r["dup"]:
            await update.message.reply_text(f"이미 기억하고 있어요 — {r['text']}")
        else:
            msg = f"📌 기억했어요 — {r['text']}"
            if r["over"]:
                msg += f"\n\n⚠️ 규칙이 {r['total']}개예요. 너무 많으면 서로 부딪힐 수 있어요. /memory 로 정리해주세요."
            await update.message.reply_text(msg)
        return True
    term = learn.term_intent(txt)
    if term:
        g = learn.add_term(*term)
        await update.message.reply_text(
            f"📖 {'고쳐서 ' if g['updated'] else ''}기억했어요 — {g['term']} = {g['mean']}")
        return True
    return False


def _note_correction(txt: str, context) -> None:
    """지적이면 조용히 적어둔다. 여기서는 아무 말도 안 한다 — 매번 '기록했어요' 하면 성가시다.

    같은 지적이 두 번 나오면 그때만 규칙으로 올릴지 물어보는데, 그것도 하려던 일이
    끝난 뒤에 붙인다(_offer_promote).
    """
    hit = learn.detect(txt)
    if not hit:
        return
    try:
        r = learn.record(txt, hit)
    except Exception as e:                                   # noqa: BLE001 — 기억 때문에 본 기능이 죽으면 안 된다
        log.info("지적 기록 실패(무시): %s", type(e).__name__)
        return
    if r.get("propose"):
        context.chat_data["promote"] = {"id": r["id"], "quote": r["quote"]}


async def _offer_promote(update, context) -> None:
    """같은 지적이 두 번 — 규칙으로 만들지 버튼으로 물어본다."""
    pend = context.chat_data.pop("promote", None)
    if not pend:
        return
    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton("규칙으로 기억", callback_data=f"lp:{pend['id']}"),
        InlineKeyboardButton("괜찮아요", callback_data=f"ld:{pend['id']}"),
    ]])
    await update.message.reply_text(
        f"같은 말씀을 두 번 하셨어요 — 「{pend['quote']}」\n앞으로 계속 지킬까요?",
        reply_markup=kb)


async def on_learn_button(update, context):
    """규칙으로 기억 / 괜찮아요 버튼. callback_data 는 위조할 수 있으므로 여기서도 주인 확인."""
    q = update.callback_query
    await q.answer()
    cfg = config.load_config() or {}
    owner = str(cfg.get("chat_id") or "")
    chat = getattr(update, "effective_chat", None)
    uid = str(chat.id) if chat else ""
    if not owner or uid != owner:
        return
    kind, _, cid = (q.data or "").partition(":")
    if kind == "lp":
        r = learn.promote(cid)
        await q.edit_message_text(f"📌 기억했어요 — {r['text']}" if r else "이미 처리된 항목이에요.")
    elif kind == "ld":
        learn.dismiss(cid)
        await q.edit_message_text("네, 규칙으로는 안 만들게요.")


@owner_only
async def cmd_work(update, context):
    """/work — 업무현황. /work 14 (일수) · /work 방 서무 점검창,업무 소통창 · /work 방 (전체)"""
    args = _args(update, context)
    cfg = context.chat_data["cfg"]

    if args and args[0] in ("방", "창", "room"):
        rest = " ".join(args[1:]).strip()
        cfg["work_rooms"] = rest
        config.save_config(cfg)
        where = rest if rest else "전체 방"
        await update.message.reply_text(f"업무현황에서 볼 방 → {where}")
        return

    days = None
    if args and args[0].isdigit():
        days = max(1, min(30, int(args[0])))

    where = ", ".join(worklog.rooms(cfg)) or "전체 방"
    await update.message.reply_text(
        f"📋 업무현황 정리 중… ({days or worklog.days_of(cfg)}일 · {where})\n"
        "방이 많으면 몇 분 걸려요.")
    try:
        text = await worklog.brief(cfg, days)
    except Exception as e:                                   # noqa: BLE001
        log.info("업무현황 실패: %s", type(e).__name__)
        await update.message.reply_text(f"업무현황을 못 만들었어요 ({type(e).__name__}).")
        return
    for chunk in _split_lines(text):
        await update.message.reply_text(chunk)


def _split_lines(text: str, limit: int = 3800) -> list[str]:
    """줄 경계에서 끊는다 — 항목이 두 메시지에 걸쳐 잘리지 않게."""
    chunks, cur = [], ""
    for line in text.split("\n"):
        while len(line) > limit:
            if cur:
                chunks.append(cur); cur = ""
            chunks.append(line[:limit]); line = line[limit:]
        cand = line if not cur else cur + "\n" + line
        if len(cand) > limit:
            chunks.append(cur); cur = line
        else:
            cur = cand
    if cur:
        chunks.append(cur)
    return [c for c in chunks if c.strip()]


@owner_only
async def cmd_memory(update, context):
    """/memory — 배운 것 보기 / 지우기."""
    argv = context.args or context.chat_data.pop("argv", [])
    if argv and argv[0] in ("지우기", "삭제", "del", "delete"):
        try:
            n = int(argv[1])
        except (IndexError, ValueError):
            await update.message.reply_text("몇 번을 지울까요?  예)  /memory 지우기 2")
            return
        gone = learn.delete(n)
        await update.message.reply_text(f"지웠어요 — {gone}" if gone else f"{n}번 규칙이 없어요.")
        return
    await update.message.reply_text(learn.list_text())


async def _handle_learn(update, context, txt: str) -> bool:
    """직전에 못 알아들은 말을, 사용자가 알려준 명령으로 기억한다."""
    prev = context.chat_data.pop("pending_learn", None)
    if not prev:
        return False
    if re.match(r"^(됐어|아니|취소|괜찮)", txt):
        await update.message.reply_text("네, 넘어갑니다.")
        return True
    cmd = next((c for w, c in LEARN_WORDS.items() if w in txt), None)
    if not cmd:
        return False                                         # 명령 이름이 아니면 보통 말로 다시 처리
    key = max(re.findall(r"[가-힣A-Za-z]{2,}", prev), key=len, default="")
    if route.teach(key, cmd):
        await update.message.reply_text(f"기억했습니다 — '{key}' 가 들어가면 {cmd} 로 처리합니다.")
        context.chat_data["argv"] = []
        await _dispatch(update, context, cmd)
    else:
        await update.message.reply_text("그 말은 기억하기 어려워요(너무 짧음).")
    return True


async def _post_init(app):
    app.create_task(scheduler.run(app))
    log.info("LiteBot 시작됨 (봇 폴링 + 스케줄러)")


async def _on_error(update, context):
    """어떤 처리가 예외로 죽어도 '조용히 사라지지' 않게 — 로그 + 사용자에게 한 줄."""
    err = context.error
    log.error("처리 중 오류: %s", err, exc_info=err)
    try:
        if isinstance(update, Update) and update.effective_message:
            await update.effective_message.reply_text(
                f"처리 중 문제가 생겼어요 ({type(err).__name__}). 다시 시도해 주세요.")
    except Exception:                                        # noqa: BLE001
        pass


def build_app(token: str) -> Application:
    app = Application.builder().token(token).post_init(_post_init).build()
    app.add_error_handler(_on_error)
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("watch", cmd_watch))
    app.add_handler(CommandHandler("report", cmd_report))
    app.add_handler(CommandHandler("today", cmd_today))
    app.add_handler(CommandHandler("weather", cmd_weather))
    app.add_handler(CommandHandler("cal", cmd_cal))
    app.add_handler(CommandHandler("chart", cmd_chart))
    app.add_handler(CommandHandler("task", cmd_task))
    app.add_handler(CommandHandler("send", cmd_send))
    app.add_handler(CommandHandler("alias", cmd_alias))
    app.add_handler(CommandHandler("find", cmd_find))
    app.add_handler(CommandHandler("collect", cmd_collect))
    app.add_handler(CommandHandler("remind", cmd_remind))
    app.add_handler(CommandHandler("memory", cmd_memory))
    app.add_handler(CommandHandler("work", cmd_work))
    app.add_handler(CallbackQueryHandler(on_learn_button, pattern=r"^l[pd]:"))
    app.add_handler(MessageHandler(filters.Document.ALL, on_document))
    app.add_handler(MessageHandler(filters.PHOTO, on_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    return app


def run_bot(token: str):
    """블로킹 — 별도 스레드에서 호출. 시그널 핸들러 설치 안 함(메인스레드 아님).

    ★ 인터넷이 잠깐 끊기면 run_polling 이 NetworkError 로 빠져나온다. 예전엔 그러면
      스레드가 그냥 끝나 버렸다 — 프로세스는 멀쩡히 살아 있는데 텔레그램만 안 되는 상태.
      사람이 눈치채고 껐다 켜야 했다(2026-08-11 맥에서 실제로 그랬다).
      와이파이가 잠깐 끊기는 건 흔한 일이라, 교인에게 나눠주면 계속 겪을 문제다.
      → 끊기면 스스로 다시 붙는다. 간격은 5초에서 시작해 최대 5분까지 늘린다
        (인터넷이 오래 죽어 있을 때 헛되이 계속 두드리지 않게).
    """
    import asyncio
    import time

    delay = 5
    while True:
        started = time.time()
        try:
            asyncio.set_event_loop(asyncio.new_event_loop())
            app = build_app(token)
            log.info("텔레그램 연결 시작")
            app.run_polling(stop_signals=None, close_loop=False)
            # run_polling 이 정상 반환 = 종료 요청. 다시 붙지 않는다.
            log.info("텔레그램 폴링 정상 종료")
            return
        except Exception as e:                             # noqa: BLE001 — 어떤 이유든 끊기면 다시 붙는다
            # 한참 잘 붙어 있다가 끊긴 거면 일시적 장애다 → 대기시간을 처음으로 되돌린다.
            # (안 그러면 며칠 켜둔 뒤 한 번 끊겼을 때 5분을 기다린다)
            if time.time() - started > 60:
                delay = 5
            log.warning("텔레그램 연결 끊김(%s: %s) — %d초 뒤 다시 붙습니다",
                        type(e).__name__, str(e)[:120], delay)
            time.sleep(delay)
            delay = min(delay * 2, 300)                    # 5→10→20…→최대 5분
