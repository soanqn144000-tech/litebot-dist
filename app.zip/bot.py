# -*- coding: utf-8 -*-
"""LiteBot 텔레그램 배선 — python-telegram-bot v20+.

주인(chat_id) 외 차단. 명령: /start /help /weather /cal /chart /task /send /alias /find /collect /remind
차트는 파일(엑셀·CSV·TSV)·사진·숫자목록 아무거나 던지면 된다(사진은 머리(Gemini 키) 필요).
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from functools import wraps

from telegram import Update
from telegram.ext import (Application, CommandHandler, ContextTypes,
                          MessageHandler, filters)

import cal
import chart
import config
import extract
import llm
import route
import scheduler
import search
import sender
import tasks
import weather

log = config.get_logger()

HELP = """🤖 LiteBot 사용법

💬 슬래시 없이 그냥 말해도 됩니다
   "오늘 날씨" · "이번주 일정" · "내무부 피티 찾아줘" · "부녀회 출석 차트 그려줘"
   · 자주 쓰는 말은 머리(AI) 없이도 알아듣습니다.
   · 머리를 켜면 아무렇게나 말해도 알아듣고, 명령이 아니면 그냥 대답합니다.
   · 발송만은 항상 "이렇게 보낼까요?" 하고 확인받고 보냅니다.

/weather — 오늘 날씨 브리핑
/cal — 오늘 일정 · /cal 주간 · /cal 추가 7/25 14:00 제목 · /cal 삭제 <번호>
📊 차트 — 그냥 던지세요
   · 엑셀(.xlsx)·CSV·TSV 파일을 보내면 알아서 읽고 차트
   · 표 사진을 보내면 숫자를 읽어 차트 (머리 필요)
   · /chart 검색 <키워드> [일수] — 텔레그램을 뒤져 숫자를 모아 차트 (머리 필요)
   · /chart 12 15 9 20 · /chart 추이 · /chart 추세
/task — 반복업무. /task 추가 매일 09:00 <메시지> · /task 추가 매시간 정각 <메시지> · /task 삭제 <번호>
/send — 발송. /send 지금 <대상> <메시지> · /send 예약 7/25 09:00 <대상> <메시지>
/alias — 별칭. /alias 추가 부과장 123456789
/find <키워드…> [일수] — 텔레그램 검색. 문장으로 물어도 됨(핵심 낱말만 골라 씀).
   머리가 켜져 있으면 맨 위에 요약을 붙여 줍니다. 예) /find 내무부 피티 14
/collect <키워드…> [일수] — 같은 검색을 방별·사람별 건수로 취합
/remind <분> <메시지>  또는  /remind 14:00 <메시지> — 한 번 알림
/status — 머리(AI)·연결 상태
"""


def owner_only(handler):
    @wraps(handler)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        cfg = config.load_config() or {}
        owner = str(cfg.get("chat_id") or "")
        uid = str(update.effective_chat.id) if update.effective_chat else ""
        if not owner or uid != owner:
            try:
                await update.message.reply_text("등록되지 않은 사용자입니다.")
            except Exception:                                # noqa: BLE001
                pass
            log.info("차단된 접근 chat=%s", uid)
            return
        context.chat_data["cfg"] = cfg
        return await handler(update, context)
    return wrapper


def _args(update: Update, context: ContextTypes.DEFAULT_TYPE | None = None) -> list[str]:
    """명령 뒤의 인자들. 자연어로 들어온 경우엔 라우터가 넣어둔 argv 를 쓴다."""
    if context is not None:
        argv = context.chat_data.pop("argv", None)
        if argv is not None:
            return list(argv)
    txt = update.message.text or ""
    parts = txt.split()
    return parts[1:] if parts else []


@owner_only
async def cmd_start(update, context):
    await update.message.reply_text("안녕하세요, LiteBot 입니다. /help 로 사용법을 보세요.")


@owner_only
async def cmd_help(update, context):
    await update.message.reply_text(HELP)


@owner_only
async def cmd_status(update, context):
    cfg = context.chat_data["cfg"]
    ver = "?"
    try:
        ver = (config.APP_DIR / "app" / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:                                        # noqa: BLE001
        pass
    tg = "연결됨" if (cfg.get("tg_api_id") and cfg.get("tg_api_hash")) else "미설정(/find 불가)"
    await update.message.reply_text(
        f"🤖 LiteBot v{ver}\n"
        f"· 머리(AI): {llm.status(cfg)}\n"
        f"· 텔레그램 검색: {tg}\n"
        f"· 캘린더: {'연결됨' if cfg.get('icloud_id') else '미설정'}\n"
        f"· 브리핑: 매일 {cfg.get('briefing_time', '07:30')}")


@owner_only
async def cmd_weather(update, context):
    await update.message.reply_text(weather.brief(context.chat_data["cfg"]))


@owner_only
async def cmd_cal(update, context):
    await update.message.reply_text(cal.handle(_args(update, context)))


@owner_only
async def cmd_task(update, context):
    await update.message.reply_text(tasks.handle(_args(update, context)))


@owner_only
async def cmd_alias(update, context):
    await update.message.reply_text(sender.alias_handle(_args(update, context)))


@owner_only
async def cmd_send(update, context):
    res = sender.send_handle(_args(update, context))
    if res["now"]:
        cid, msg = res["now"]
        try:
            await context.bot.send_message(chat_id=int(cid), text=msg)
            await update.message.reply_text(f"📤 발송 성공 → {cid}")
        except Exception as e:                               # noqa: BLE001
            await update.message.reply_text(f"❌ 발송 실패 → {cid} ({type(e).__name__})")
    else:
        await update.message.reply_text(res["reply"])


@owner_only
async def cmd_find(update, context):
    await update.message.reply_text("검색 중…")
    await update.message.reply_text(await search.find(context.chat_data["cfg"], _args(update, context)))


@owner_only
async def cmd_collect(update, context):
    await update.message.reply_text("취합 중…")
    await update.message.reply_text(await search.collect(context.chat_data["cfg"], _args(update, context)))


@owner_only
async def cmd_remind(update, context):
    args = _args(update, context)
    if len(args) < 2:
        await update.message.reply_text("형식: /remind 30 <메시지>  또는  /remind 14:00 <메시지>")
        return
    cfg = context.chat_data["cfg"]
    when = None
    if args[0].isdigit():                                    # N분 후
        when = datetime.now() + timedelta(minutes=int(args[0]))
    elif re.fullmatch(r"\d{1,2}:\d{2}", args[0]):            # 오늘 HH:MM
        h, m = map(int, args[0].split(":"))
        t = datetime.now().replace(hour=h, minute=m, second=0, microsecond=0)
        if t < datetime.now():
            t += timedelta(days=1)
        when = t
    if not when:
        await update.message.reply_text("시간을 못 읽었어요 (예: 30 또는 14:00).")
        return
    msg = " ".join(args[1:]).strip()
    items = config.read_json("scheduled.json", [])
    items.append({"id": max([i.get("id", 0) for i in items], default=0) + 1,
                  "when": when.strftime("%Y-%m-%d %H:%M"),
                  "chat_id": cfg["chat_id"], "message": f"🔔 {msg}"})
    config.write_json("scheduled.json", items)
    await update.message.reply_text(f"🔔 알림 예약: {when:%m/%d %H:%M}\n{msg}")


@owner_only
async def cmd_chart(update, context):
    args = _args(update, context)
    if args and args[0] in ("검색", "텔레", "텔레그램"):        # /chart 검색 <키워드…> [일수]
        await _chart_from_telegram(update, context, args[1:])
        return
    kinds = {"꺾은선", "추이", "추세"}
    kind = "꺾은선"
    rest = []
    for a in args:
        if a in kinds:
            kind = a
        else:
            rest.append(a)
    context.chat_data["chart_kind"] = kind
    if rest:                                                 # 숫자목록 인라인
        path = chart.make(" ".join(rest), kind=kind, title=f"{kind} 차트")
        if path:
            await update.message.reply_photo(photo=open(path, "rb"))
        else:
            await update.message.reply_text("숫자를 못 읽었어요. 예: /chart 추세 12 15 9 20")
    else:
        await update.message.reply_text(
            f"'{kind}' 준비됨. TSV/CSV 파일이나 숫자목록을 보내주세요.")


async def _chart_from_telegram(update, context, words: list[str]) -> None:
    """텔레그램을 뒤져서 나온 글의 숫자로 바로 차트. 머리(Gemini 키)가 있어야 합니다."""
    cfg = context.chat_data["cfg"]
    if not words:
        await update.message.reply_text("형식: /chart 검색 <키워드…> [일수]\n예) /chart 검색 부녀회 출석 30")
        return
    if not llm.available(cfg):
        await update.message.reply_text(
            "대화 글에서 숫자를 뽑아 차트로 만드는 건 머리(AI)가 필요해요.\n"
            f"· 현재: {llm.status(cfg)}\n· 설정에서 Gemini 무료 키를 넣으면 됩니다.")
        return
    kw, days = search.parse_args(words)
    await update.message.reply_text(f"텔레그램에서 '{' '.join(kw)}' 찾는 중… (최근 {days}일)")
    try:
        hits, used, _dropped = await search.gather(cfg, kw, days)
    except search.SearchError as e:
        await update.message.reply_text(str(e))
        return
    if not hits:
        await update.message.reply_text("그 낱말로 찾은 글이 없어요.")
        return
    hits, _need = search.rank(hits)
    spec, how = extract.spec_from_messages(cfg, hits, " ".join(words))
    if spec:
        spec.setdefault("footer", f"텔레그램 '{' '.join(used)}' 최근 {days}일 · {len(hits)}건")
        if await _send_spec(update, spec, how):
            return
    await update.message.reply_text(
        f"글은 {len(hits)}건 찾았는데 차트로 만들 숫자를 못 뽑았어요.\n"
        f"`/find {' '.join(words)}` 로 내용부터 보시겠어요?")


async def _send_spec(update, spec: dict, how: str) -> bool:
    """차트 규격 → PNG 발송. 어떻게 읽었는지(AI/규칙)도 알려준다."""
    path = chart.make_spec(spec)
    if not path:
        return False
    cap = f"{spec.get('title') or '데이터 차트'}  ({'AI 해석' if how == 'AI' else '규칙 해석'})"
    await update.message.reply_photo(photo=open(path, "rb"), caption=cap[:1000])
    return True


@owner_only
async def on_document(update, context):
    """파일을 던지면 알아서 차트. 엑셀·CSV·TSV·TXT."""
    doc = update.message.document
    name = doc.file_name or ""
    hint = (update.message.caption or "").strip()
    try:
        f = await context.bot.get_file(doc.file_id)
        raw = bytes(await f.download_as_bytearray())
    except Exception as e:                                   # noqa: BLE001
        await update.message.reply_text(f"파일을 못 받았어요 ({type(e).__name__}).")
        return
    text, why = extract.read_document(name, raw)
    if text is None:
        await update.message.reply_text(why or "파일을 못 읽었어요.")
        return
    await update.message.reply_text("읽는 중…")
    spec, how = extract.spec_from_text(context.chat_data["cfg"], text, hint)
    if spec and await _send_spec(update, spec, how):
        return
    kind = context.chat_data.get("chart_kind", "꺾은선")      # 마지막 보루: 예전 방식
    path = chart.make(text, kind=kind, title=hint or f"{kind} 차트")
    if path:
        await update.message.reply_photo(photo=open(path, "rb"))
    else:
        await update.message.reply_text("데이터에서 숫자를 못 찾았어요.")


@owner_only
async def on_photo(update, context):
    """사진(표·보고 캡처)을 던지면 숫자를 읽어 차트. 머리(Gemini 키)가 있어야 합니다."""
    cfg = context.chat_data["cfg"]
    if not llm.available(cfg):
        await update.message.reply_text(
            "사진 속 숫자 읽기는 머리(AI)가 필요해요.\n"
            f"· 현재: {llm.status(cfg)}\n"
            "· 트레이 → 설정 → '선택 기능' → Gemini 무료 키 발급·입력하면 됩니다.")
        return
    try:
        f = await context.bot.get_file(update.message.photo[-1].file_id)
        jpg = bytes(await f.download_as_bytearray())
    except Exception as e:                                   # noqa: BLE001
        await update.message.reply_text(f"사진을 못 받았어요 ({type(e).__name__}).")
        return
    await update.message.reply_text("사진 읽는 중…")
    spec, how = extract.spec_from_image(cfg, jpg, (update.message.caption or "").strip())
    if not (spec and await _send_spec(update, spec, how)):
        await update.message.reply_text("사진에서 표·숫자를 못 찾았어요. 표가 또렷하게 나오게 다시 찍어주세요.")


YES = re.compile(r"^(응|어|네|예|ㅇㅇ|그래|맞아|보내|보내줘|ok|okay|yes)\b", re.I)
NO = re.compile(r"^(아니|아냐|취소|하지마|no)\b", re.I)

EXTRACT_SEND = """사용자가 텔레그램 메시지를 보내달라고 했다. 받는 사람과 보낼 내용을 뽑아 JSON 하나만 뱉어라.
설명 금지. 형식: {"target":"받는사람(별칭·이름·숫자id)","message":"보낼 내용"}
받는 사람을 모르겠으면 target 을 "" 로 둬라."""


async def _prepare_send(update, context, text: str) -> None:
    """발송은 절대 바로 쏘지 않는다 — 무엇을 누구에게 보낼지 보여주고 확인받는다."""
    cfg = context.chat_data["cfg"]
    target = msg = ""
    if llm.available(cfg):
        import json as _json
        got = llm.ask(cfg, f"{EXTRACT_SEND}\n\n사용자: {text}") or ""
        m = re.search(r"\{.*\}", got, re.S)
        if m:
            try:
                obj = _json.loads(m.group(0))
                target, msg = str(obj.get("target") or ""), str(obj.get("message") or "")
            except Exception:                                # noqa: BLE001
                pass
    if not (target and msg):
        await update.message.reply_text(
            "누구에게 무엇을 보낼지 못 알아들었어요.\n"
            "· /send 지금 <대상> <메시지>\n· 대상은 /alias 추가 <이름> <chat_id> 로 등록해두면 편해요.")
        return
    cid = sender.resolve(target)
    if not cid:
        await update.message.reply_text(
            f"대상 '{target}'를 못 찾았어요. /alias 추가 {target} <chat_id> 로 등록해주세요.")
        return
    context.chat_data["pending_send"] = {"cid": cid, "target": target, "text": msg}
    await update.message.reply_text(
        f"이렇게 보낼까요?\n\n받는 곳: {target}\n내용: {msg}\n\n맞으면 '응', 아니면 '아니'.")


@owner_only
async def on_text(update, context):
    """슬래시 없이 그냥 말해도 알아듣게 — 규칙 라우터, 안 되면 머리(AI) 라우터."""
    txt = (update.message.text or "").strip()
    cfg = context.chat_data["cfg"]

    pend = context.chat_data.get("pending_send")             # ① 발송 확인 대기 중
    if pend:
        if YES.match(txt):
            context.chat_data.pop("pending_send", None)
            try:
                await context.bot.send_message(chat_id=int(pend["cid"]), text=pend["text"])
                await update.message.reply_text(f"📤 발송 성공 → {pend['target']}")
            except Exception as e:                           # noqa: BLE001
                await update.message.reply_text(f"❌ 발송 실패 → {pend['target']} ({type(e).__name__})")
            return
        if NO.match(txt):
            context.chat_data.pop("pending_send", None)
            await update.message.reply_text("취소했어요.")
            return
        context.chat_data.pop("pending_send", None)          # 딴 말이면 발송은 없던 일로

    if context.chat_data.get("chart_kind") and re.search(r"\d", txt):   # ② /chart 뒤 숫자목록
        kind = context.chat_data["chart_kind"]
        path = chart.make(txt, kind=kind, title=f"{kind} 차트")
        if path:
            await update.message.reply_photo(photo=open(path, "rb"))
            return

    cmd, args, how = route.route(cfg, txt)                   # ③ 자연어 → 명령
    if cmd == "send_confirm":
        await _prepare_send(update, context, txt)
        return
    if cmd:
        log.info("자연어 라우팅(%s): %s → /%s %s", how, txt[:40], cmd, " ".join(args)[:40])
        context.chat_data["argv"] = args
        handler = {"weather": cmd_weather, "cal": cmd_cal, "find": cmd_find,
                   "collect": cmd_collect, "chart": cmd_chart, "task": cmd_task,
                   "remind": cmd_remind, "status": cmd_status}.get(cmd)
        if handler:
            await handler(update, context)
            return
        context.chat_data.pop("argv", None)

    if llm.available(cfg):                                   # ④ 명령이 아니면 그냥 대답
        got = llm.ask(cfg, "너는 교회 행정 비서다. 짧고 정확하게 한국어로 답해라. "
                           "모르면 모른다고 해라. 5줄 이내.\n\n" + txt)
        if got:
            await update.message.reply_text(got.strip())
            return
    await update.message.reply_text(
        "무슨 뜻인지 모르겠어요. /help 를 보시거나, 설정에서 머리(AI)를 켜면 말로 해도 알아듣습니다.")


async def _post_init(app):
    app.create_task(scheduler.run(app))
    log.info("LiteBot 시작됨 (봇 폴링 + 스케줄러)")


def build_app(token: str) -> Application:
    app = Application.builder().token(token).post_init(_post_init).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("weather", cmd_weather))
    app.add_handler(CommandHandler("cal", cmd_cal))
    app.add_handler(CommandHandler("chart", cmd_chart))
    app.add_handler(CommandHandler("task", cmd_task))
    app.add_handler(CommandHandler("send", cmd_send))
    app.add_handler(CommandHandler("alias", cmd_alias))
    app.add_handler(CommandHandler("find", cmd_find))
    app.add_handler(CommandHandler("collect", cmd_collect))
    app.add_handler(CommandHandler("remind", cmd_remind))
    app.add_handler(MessageHandler(filters.Document.ALL, on_document))
    app.add_handler(MessageHandler(filters.PHOTO, on_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    return app


def run_bot(token: str):
    """블로킹 — 별도 스레드에서 호출. 시그널 핸들러 설치 안 함(메인스레드 아님)."""
    import asyncio
    asyncio.set_event_loop(asyncio.new_event_loop())
    app = build_app(token)
    app.run_polling(stop_signals=None, close_loop=False)
