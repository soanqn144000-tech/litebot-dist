# -*- coding: utf-8 -*-
"""LiteBot 텔레그램 배선 — python-telegram-bot v20+.

주인(chat_id) 외 차단. 명령: /start /help /weather /cal /chart /task /send /alias /find /collect /remind
차트는 파일(엑셀·CSV·TSV)·사진·숫자목록 아무거나 던지면 된다(사진은 머리(Gemini 키) 필요).
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from functools import wraps

from telegram import Update
from telegram.ext import (Application, CommandHandler, ContextTypes,
                          MessageHandler, filters)

import cal
import chart
import compose
import config
import extract
import llm
import route
import scheduler
import search
import sender
import tasks
import weather

log = config.get_logger()

HELP = """🤖 LiteBot 사용법

💬 슬래시 없이 그냥 말해도 됩니다
   "오늘 뭐 하지" · "오늘 날씨" · "이번주 일정" · "내무부 피티 찾아줘"
   · 못 알아들으면 되물어보고, 알려주시면 다음부터 기억합니다.
   · 발송만은 항상 "이렇게 보낼까요?" 하고 확인받고 보냅니다.
   · 밖(AI)으로 나갈 때 사람 이름은 '인물1' 로 가려서 보내고, 화면엔 실명으로 되돌립니다.

/today — 오늘 종합(일정+날씨+알림+예약업무). AI 안 씀

/weather — 오늘 날씨 브리핑
/cal — 오늘 일정 · /cal 주간 · /cal 추가 7/25 14:00 제목 · /cal 삭제 <번호>
📊 차트 — 그냥 던지세요
   · 엑셀(.xlsx)·CSV·TSV 파일을 보내면 알아서 읽고 차트
   · 표 사진을 보내면 숫자를 읽어 차트 (머리 필요)
   · /chart 검색 <키워드> [일수] — 텔레그램을 뒤져 숫자를 모아 차트 (머리 필요)
   · /chart 12 15 9 20 · /chart 추이 · /chart 추세
/task — 반복업무. /task 추가 매일 09:00 <메시지> · /task 추가 매시간 정각 <메시지> · /task 삭제 <번호>
/send — 발송. /send 지금 <대상> <메시지> · /send 예약 7/25 09:00 <대상> <메시지>
/alias — 별칭. /alias 추가 부과장 123456789
/find <키워드…> [일수] — 텔레그램 검색. 문장으로 물어도 됨(핵심 낱말만 골라 씀).
   머리가 켜져 있으면 맨 위에 요약을 붙여 줍니다. 예) /find 내무부 피티 14
/collect <키워드…> [일수] — 같은 검색을 방별·사람별 건수로 취합
/remind <분> <메시지>  또는  /remind 14:00 <메시지> — 한 번 알림
/status — 머리(AI)·연결 상태
"""


def owner_only(handler):
    @wraps(handler)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        cfg = config.load_config() or {}
        owner = str(cfg.get("chat_id") or "")
        uid = str(update.effective_chat.id) if update.effective_chat else ""
        if not owner or uid != owner:
            try:
                await update.message.reply_text("등록되지 않은 사용자입니다.")
            except Exception:                                # noqa: BLE001
                pass
            log.info("차단된 접근 chat=%s", uid)
            return
        context.chat_data["cfg"] = cfg
        return await handler(update, context)
    return wrapper


def _args(update: Update, context: ContextTypes.DEFAULT_TYPE | None = None) -> list[str]:
    """명령 뒤의 인자들. 자연어로 들어온 경우엔 라우터가 넣어둔 argv 를 쓴다."""
    if context is not None:
        argv = context.chat_data.pop("argv", None)
        if argv is not None:
            return list(argv)
    txt = update.message.text or ""
    parts = txt.split()
    return parts[1:] if parts else []


@owner_only
async def cmd_start(update, context):
    await update.message.reply_text("안녕하세요, LiteBot 입니다. /help 로 사용법을 보세요.")


@owner_only
async def cmd_help(update, context):
    await update.message.reply_text(HELP)


@owner_only
async def cmd_status(update, context):
    cfg = context.chat_data["cfg"]
    ver = "?"
    try:
        ver = (config.APP_DIR / "app" / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:                                        # noqa: BLE001
        pass
    tg = "연결됨" if (cfg.get("tg_api_id") and cfg.get("tg_api_hash")) else "미설정(/find 불가)"
    await update.message.reply_text(
        f"🤖 LiteBot v{ver}\n"
        f"· 머리(AI): {llm.status(cfg)}\n"
        f"· 텔레그램 검색: {tg}\n"
        f"· 캘린더: {'연결됨' if cfg.get('icloud_id') else '미설정'}\n"
        f"· 브리핑: 매일 {cfg.get('briefing_time', '07:30')}")


@owner_only
async def cmd_today(update, context):
    """'오늘 뭐 하지' — 일정·날씨·알림·예약업무를 한 번에 엮어서. AI 안 씀."""
    await update.message.reply_text(compose.day_plan(context.chat_data["cfg"]))


@owner_only
async def cmd_weather(update, context):
    await update.message.reply_text(weather.brief(context.chat_data["cfg"]))


@owner_only
async def cmd_cal(update, context):
    await update.message.reply_text(cal.handle(_args(update, context)))


@owner_only
async def cmd_task(update, context):
    await update.message.reply_text(tasks.handle(_args(update, context)))


@owner_only
async def cmd_alias(update, context):
    await update.message.reply_text(sender.alias_handle(_args(update, context)))


@owner_only
async def cmd_send(update, context):
    res = sender.send_handle(_args(update, context))
    if res["now"]:
        cid, msg = res["now"]
        try:
            await context.bot.send_message(chat_id=int(cid), text=msg)
            await update.message.reply_text(f"📤 발송 성공 → {cid}")
        except Exception as e:                               # noqa: BLE001
            await update.message.reply_text(f"❌ 발송 실패 → {cid} ({type(e).__name__})")
    else:
        await update.message.reply_text(res["reply"])


@owner_only
async def cmd_find(update, context):
    await update.message.reply_text("검색 중…")
    await update.message.reply_text(await search.find(context.chat_data["cfg"], _args(update, context)))


@owner_only
async def cmd_collect(update, context):
    await update.message.reply_text("취합 중…")
    await update.message.reply_text(await search.collect(context.chat_data["cfg"], _args(update, context)))


@owner_only
async def cmd_remind(update, context):
    args = _args(update, context)
    if len(args) < 2:
        await update.message.reply_text("형식: /remind 30 <메시지>  또는  /remind 14:00 <메시지>")
        return
    cfg = context.chat_data["cfg"]
    when = None
    if args[0].isdigit():                                    # N분 후
        when = datetime.now() + timedelta(minutes=int(args[0]))
    elif re.fullmatch(r"\d{1,2}:\d{2}", args[0]):            # 오늘 HH:MM
        h, m = map(int, args[0].split(":"))
        t = datetime.now().replace(hour=h, minute=m, second=0, microsecond=0)
        if t < datetime.now():
            t += timedelta(days=1)
        when = t
    if not when:
        await update.message.reply_text("시간을 못 읽었어요 (예: 30 또는 14:00).")
        return
    msg = " ".join(args[1:]).strip()
    items = config.read_json("scheduled.json", [])
    items.append({"id": max([i.get("id", 0) for i in items], default=0) + 1,
                  "when": when.strftime("%Y-%m-%d %H:%M"),
                  "chat_id": cfg["chat_id"], "message": f"🔔 {msg}"})
    config.write_json("scheduled.json", items)
    await update.message.reply_text(f"🔔 알림 예약: {when:%m/%d %H:%M}\n{msg}")


@owner_only
async def cmd_chart(update, context):
    args = _args(update, context)
    if args and args[0] in ("검색", "텔레", "텔레그램"):        # /chart 검색 <키워드…> [일수]
        await _chart_from_telegram(update, context, args[1:])
        return
    kinds = {"꺾은선", "추이", "추세"}
    kind = "꺾은선"
    rest = []
    for a in args:
        if a in kinds:
            kind = a
        else:
            rest.append(a)
    context.chat_data["chart_kind"] = kind
    if rest:                                                 # 숫자목록 인라인
        path = chart.make(" ".join(rest), kind=kind, title=f"{kind} 차트")
        if path:
            await update.message.reply_photo(photo=open(path, "rb"))
        else:
            await update.message.reply_text("숫자를 못 읽었어요. 예: /chart 추세 12 15 9 20")
    else:
        await update.message.reply_text(
            f"'{kind}' 준비됨. TSV/CSV 파일이나 숫자목록을 보내주세요.")


async def _chart_from_telegram(update, context, words: list[str]) -> None:
    """텔레그램을 직접 뒤져서 차트. ① 올라온 파일(엑셀·CSV) 먼저 ② 없으면 글 속 숫자.

    "○○창에서 △△님이 어제 올려준 파일" 처럼 방·사람·때가 섞여 와도
    그건 검색어가 아니라 걸러내는 조건으로 쓴다(search.hints).
    """
    cfg = context.chat_data["cfg"]
    raw = (update.message.text or "")
    if not words:
        await update.message.reply_text(
            "무엇으로 차트를 만들까요?\n"
            "예) 부녀회 출석 차트 그려줘 · 취합창에 어제 올라온 출석 파일로 차트")
        return
    h = search.hints(raw)
    kw, days = search.parse_args(words)
    kw = search.strip_hints(kw, h)                           # 방·사람·때는 검색어에서 뺀다(조건으로만 씀)
    days = h["days"] or (days if days != 7 else 30)           # 파일은 좀 더 넓게 본다
    where = " · ".join(x for x in [h["room"] and f"방:{h['room']}",
                                   h["person"] and f"올린이:{h['person']}"] if x)
    await update.message.reply_text(
        f"텔레그램에서 파일 찾는 중… ('{' '.join(kw)}' 최근 {days}일{' · ' + where if where else ''})")

    try:                                                     # ① 첨부파일 먼저
        files = await search.find_files(cfg, kw, days, room=h["room"], person=h["person"])
    except search.SearchError as e:
        await update.message.reply_text(str(e))
        return

    for f in files[:3]:                                      # 잘 맞는 것부터 실제로 열어본다
        got = await search.download(cfg, f["chat_id"], f["msg_id"])
        if not got:
            continue
        name, data = got
        text, why = extract.read_document(name, data, cfg)
        if text is None:
            continue
        await update.message.reply_text(
            f"📄 {name}\n   {f['date']:%m/%d %H:%M} · {f['room']} · {f['sender']}\n   읽는 중…")
        spec, how = extract.spec_from_text(cfg, text, " ".join(kw))
        if spec:
            spec.setdefault("footer", f"{name} · {f['date']:%Y-%m-%d} · {f['room']}")
            if await _send_spec(update, spec, how):
                return
        await update.message.reply_text("   이 파일에선 숫자를 못 뽑았어요. 다음 파일을 봅니다…")

    if not llm.available(cfg):                               # ② 글 속 숫자 — 여기서부턴 머리가 필요
        await update.message.reply_text(
            "쓸 만한 파일을 못 찾았어요. 글에서 숫자를 뽑으려면 머리(AI)가 필요합니다.\n"
            f"· 현재: {llm.status(cfg)}")
        return
    try:
        hits, used, _dropped = await search.gather(cfg, kw, days)
    except search.SearchError as e:
        await update.message.reply_text(str(e))
        return
    if not hits:
        await update.message.reply_text("그 낱말로는 파일도 글도 못 찾았어요.")
        return
    hits, _need = search.rank(hits)
    if h["room"] or h["person"]:                             # 단서가 있으면 그걸로 좁힌다
        narrowed = [x for x in hits if search._match_hint(x["room"], h["room"])
                    and search._match_hint(x["sender"], h["person"])]
        hits = narrowed or hits
    spec, how = extract.spec_from_messages(cfg, hits, raw)
    if spec:
        spec.setdefault("footer", f"텔레그램 '{' '.join(used)}' 최근 {days}일 · {len(hits)}건")
        if await _send_spec(update, spec, how):
            return
    await update.message.reply_text(
        f"파일은 {len(files)}개, 글은 {len(hits)}건 찾았는데 차트로 만들 숫자를 못 뽑았어요.\n"
        f"/find {' '.join(kw)} 로 내용부터 보시겠어요?")


async def _send_spec(update, spec: dict, how: str) -> bool:
    """차트 규격 → PNG 발송. 어떻게 읽었는지(AI/규칙)도 알려준다."""
    path = chart.make_spec(spec)
    if not path:
        return False
    cap = f"{spec.get('title') or '데이터 차트'}  ({'AI 해석' if how == 'AI' else '규칙 해석'})"
    await update.message.reply_photo(photo=open(path, "rb"), caption=cap[:1000])
    return True


@owner_only
async def on_document(update, context):
    """파일을 던지면 알아서 차트. 엑셀·CSV·TSV·TXT."""
    doc = update.message.document
    name = doc.file_name or ""
    hint = (update.message.caption or "").strip()
    try:
        f = await context.bot.get_file(doc.file_id)
        raw = bytes(await f.download_as_bytearray())
    except Exception as e:                                   # noqa: BLE001
        await update.message.reply_text(f"파일을 못 받았어요 ({type(e).__name__}).")
        return
    text, why = extract.read_document(name, raw, context.chat_data["cfg"])
    if text is None:
        await update.message.reply_text(why or "파일을 못 읽었어요.")
        return
    await update.message.reply_text("읽는 중…")
    spec, how = extract.spec_from_text(context.chat_data["cfg"], text, hint)
    if spec and await _send_spec(update, spec, how):
        return
    kind = context.chat_data.get("chart_kind", "꺾은선")      # 마지막 보루: 예전 방식
    path = chart.make(text, kind=kind, title=hint or f"{kind} 차트")
    if path:
        await update.message.reply_photo(photo=open(path, "rb"))
    else:
        await update.message.reply_text("데이터에서 숫자를 못 찾았어요.")


@owner_only
async def on_photo(update, context):
    """사진(표·보고 캡처)을 던지면 숫자를 읽어 차트. 머리(Gemini 키)가 있어야 합니다."""
    cfg = context.chat_data["cfg"]
    if not llm.available(cfg):
        await update.message.reply_text(
            "사진 속 숫자 읽기는 머리(AI)가 필요해요.\n"
            f"· 현재: {llm.status(cfg)}\n"
            "· 트레이 → 설정 → '선택 기능' → Gemini 무료 키 발급·입력하면 됩니다.")
        return
    try:
        f = await context.bot.get_file(update.message.photo[-1].file_id)
        jpg = bytes(await f.download_as_bytearray())
    except Exception as e:                                   # noqa: BLE001
        await update.message.reply_text(f"사진을 못 받았어요 ({type(e).__name__}).")
        return
    await update.message.reply_text("사진 읽는 중…")
    spec, how = extract.spec_from_image(cfg, jpg, (update.message.caption or "").strip())
    if not (spec and await _send_spec(update, spec, how)):
        await update.message.reply_text("사진에서 표·숫자를 못 찾았어요. 표가 또렷하게 나오게 다시 찍어주세요.")


YES = re.compile(r"^(응|어|네|예|ㅇㅇ|그래|맞아|보내|보내줘|ok|okay|yes)\b", re.I)
NO = re.compile(r"^(아니|아냐|취소|하지마|no)\b", re.I)

EXTRACT_SEND = """사용자가 텔레그램 메시지를 보내달라고 했다. 받는 사람과 보낼 내용을 뽑아 JSON 하나만 뱉어라.
설명 금지. 형식: {"target":"받는사람(별칭·이름·숫자id)","message":"보낼 내용"}
받는 사람을 모르겠으면 target 을 "" 로 둬라."""


async def _prepare_send(update, context, text: str) -> None:
    """발송은 절대 바로 쏘지 않는다 — 무엇을 누구에게 보낼지 보여주고 확인받는다."""
    cfg = context.chat_data["cfg"]
    target = msg = ""
    if llm.available(cfg):
        import json as _json
        got = llm.ask(cfg, f"{EXTRACT_SEND}\n\n사용자: {text}") or ""
        m = re.search(r"\{.*\}", got, re.S)
        if m:
            try:
                obj = _json.loads(m.group(0))
                target, msg = str(obj.get("target") or ""), str(obj.get("message") or "")
            except Exception:                                # noqa: BLE001
                pass
    if not (target and msg):
        await update.message.reply_text(
            "누구에게 무엇을 보낼지 못 알아들었어요.\n"
            "· /send 지금 <대상> <메시지>\n· 대상은 /alias 추가 <이름> <chat_id> 로 등록해두면 편해요.")
        return
    cid = sender.resolve(target)
    if not cid:
        await update.message.reply_text(
            f"대상 '{target}'를 못 찾았어요. /alias 추가 {target} <chat_id> 로 등록해주세요.")
        return
    context.chat_data["pending_send"] = {"cid": cid, "target": target, "text": msg}
    await update.message.reply_text(
        f"이렇게 보낼까요?\n\n받는 곳: {target}\n내용: {msg}\n\n맞으면 '응', 아니면 '아니'.")


@owner_only
async def on_text(update, context):
    """슬래시 없이 그냥 말해도 알아듣게 — 규칙 라우터, 안 되면 머리(AI) 라우터."""
    txt = (update.message.text or "").strip()
    cfg = context.chat_data["cfg"]

    if await _handle_learn(update, context, txt):            # ⓪ 방금 가르쳐 주는 중이면
        return

    pend = context.chat_data.get("pending_send")             # ① 발송 확인 대기 중
    if pend:
        if YES.match(txt):
            context.chat_data.pop("pending_send", None)
            try:
                await context.bot.send_message(chat_id=int(pend["cid"]), text=pend["text"])
                await update.message.reply_text(f"📤 발송 성공 → {pend['target']}")
            except Exception as e:                           # noqa: BLE001
                await update.message.reply_text(f"❌ 발송 실패 → {pend['target']} ({type(e).__name__})")
            return
        if NO.match(txt):
            context.chat_data.pop("pending_send", None)
            await update.message.reply_text("취소했어요.")
            return
        context.chat_data.pop("pending_send", None)          # 딴 말이면 발송은 없던 일로

    if context.chat_data.get("chart_kind") and re.search(r"\d", txt):   # ② /chart 뒤 숫자목록
        kind = context.chat_data["chart_kind"]
        path = chart.make(txt, kind=kind, title=f"{kind} 차트")
        if path:
            await update.message.reply_photo(photo=open(path, "rb"))
            return

    cmd, args, how = route.route(cfg, txt)                   # ③ 자연어 → 명령
    if cmd == "send_confirm":
        await _prepare_send(update, context, txt)
        return
    if cmd:
        log.info("자연어 라우팅(%s): %s → /%s %s", how, txt[:40], cmd, " ".join(args)[:40])
        context.chat_data["argv"] = args
        if await _dispatch(update, context, cmd):
            return
        context.chat_data.pop("argv", None)

    if llm.available(cfg):                                   # ④ 명령이 아니면 그냥 대답
        got = llm.ask(cfg, "너는 교회 행정 비서다. 짧고 정확하게 한국어로 답해라. "
                           "모르면 모른다고 해라. 5줄 이내.\n\n" + txt)
        if got:
            await update.message.reply_text(got.strip())
            return

    context.chat_data["pending_learn"] = txt                 # ⑤ 못 알아들었으면 배운다
    await update.message.reply_text(
        "이 말은 아직 모릅니다. 무엇을 하라는 거였나요?\n"
        "  오늘 · 날씨 · 일정 · 검색 · 취합 · 차트 · 알림 · 상태\n"
        "중 하나로 답해주시면 다음부터는 바로 알아듣습니다. (건너뛰려면 '됐어')")


LEARN_WORDS = {"오늘": "today", "날씨": "weather", "일정": "cal", "검색": "find",
               "취합": "collect", "차트": "chart", "알림": "remind", "상태": "status"}


async def _dispatch(update, context, cmd: str) -> bool:
    handler = {"today": cmd_today, "weather": cmd_weather, "cal": cmd_cal, "find": cmd_find,
               "collect": cmd_collect, "chart": cmd_chart, "task": cmd_task,
               "remind": cmd_remind, "status": cmd_status}.get(cmd)
    if not handler:
        return False
    await handler(update, context)
    return True


async def _handle_learn(update, context, txt: str) -> bool:
    """직전에 못 알아들은 말을, 사용자가 알려준 명령으로 기억한다."""
    prev = context.chat_data.pop("pending_learn", None)
    if not prev:
        return False
    if re.match(r"^(됐어|아니|취소|괜찮)", txt):
        await update.message.reply_text("네, 넘어갑니다.")
        return True
    cmd = next((c for w, c in LEARN_WORDS.items() if w in txt), None)
    if not cmd:
        return False                                         # 명령 이름이 아니면 보통 말로 다시 처리
    key = max(re.findall(r"[가-힣A-Za-z]{2,}", prev), key=len, default="")
    if route.teach(key, cmd):
        await update.message.reply_text(f"기억했습니다 — '{key}' 가 들어가면 {cmd} 로 처리합니다.")
        context.chat_data["argv"] = []
        await _dispatch(update, context, cmd)
    else:
        await update.message.reply_text("그 말은 기억하기 어려워요(너무 짧음).")
    return True


async def _post_init(app):
    app.create_task(scheduler.run(app))
    log.info("LiteBot 시작됨 (봇 폴링 + 스케줄러)")


def build_app(token: str) -> Application:
    app = Application.builder().token(token).post_init(_post_init).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("today", cmd_today))
    app.add_handler(CommandHandler("weather", cmd_weather))
    app.add_handler(CommandHandler("cal", cmd_cal))
    app.add_handler(CommandHandler("chart", cmd_chart))
    app.add_handler(CommandHandler("task", cmd_task))
    app.add_handler(CommandHandler("send", cmd_send))
    app.add_handler(CommandHandler("alias", cmd_alias))
    app.add_handler(CommandHandler("find", cmd_find))
    app.add_handler(CommandHandler("collect", cmd_collect))
    app.add_handler(CommandHandler("remind", cmd_remind))
    app.add_handler(MessageHandler(filters.Document.ALL, on_document))
    app.add_handler(MessageHandler(filters.PHOTO, on_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    return app


def run_bot(token: str):
    """블로킹 — 별도 스레드에서 호출. 시그널 핸들러 설치 안 함(메인스레드 아님)."""
    import asyncio
    asyncio.set_event_loop(asyncio.new_event_loop())
    app = build_app(token)
    app.run_polling(stop_signals=None, close_loop=False)
