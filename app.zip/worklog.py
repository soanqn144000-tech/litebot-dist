# -*- coding: utf-8 -*-
"""⑰ 업무현황 — 텔레그램을 훑어 '무슨 일이 어디까지 왔나' 를 정리한다.

업무가 여러 사람에게 흩어져 있고 텔레그램은 직렬로 흘러가서, 어느 일정에 무슨 일을
마감해야 하는지가 안 보인다. 대시보드에 손으로 넣는 건 더 번거로우니 이미 오간
대화에서 뽑아낸다. (아델 scripts/worklog_brief.py 를 라이트봇으로 옮긴 것)

역할 분담:
  · 이 모듈 = 모으기 + 걸러내기 + 날짜계산 + 글로 뽑기 (판단 안 함)
  · llm.ask = 읽고 판단해서 **업무 목록 JSON** 을 만든다 (머리)
    → 밖으로 나갈 때 이름은 privacy 가 가리고, 배운 것(learn)은 자동으로 따라간다.

지어내지 않는다:
  · 마감일은 원문에 적힌 말에서만. 없으면 '마감 없음'.
  · D-day 계산과 '마감 임박' 판정은 **여기서** 한다 — 머리에 날짜 계산을 시키면 자주 틀린다.
  · JSON 을 못 받으면 그럴듯한 걸 만들지 않고 실패했다고 말한다.

설정(config.json):
  work_rooms : "내무부) 서무 점검창, 업무 소통창"   ← 비면 전체 방
  work_days  : 7
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone

import config
import llm
import privacy
import search

KST = timezone(timedelta(hours=9))
log = config.get_logger()
DEFAULT_DAYS = 7
SCAN_LIMIT = 400                                             # 방 하나에서 볼 최근 글 수
MAX_CHARS = 200_000                                          # 머리에 넘길 상한

# 내용 없는 반응 — 업무 진척으로 보지 않는다.
ACK = re.compile(
    r"^(아멘+|넵+|네+|예+|옙|감사(합니다|해요|드립니다)?|고생(하셨|많으)|수고(하셨|하세요)?"
    r"|확인(했습니다|하겠습니다|했어요)?|알겠습니다|알겠어요|ㅇㅇ|ㅋ+|ㅎ+|👍|🙏|❤|~+|\.+"
    r"|\[첨부\]|화이팅|파이팅|좋습니다|좋아요|굿|오케이|ok|okay)[\s!.~♡❤🙏👍👏😊😂ㅋㅎ]*$", re.I)
# 방은 맞는데 내용이 일이 아닌 것.
JUNK = re.compile(r"막국수|메뉴\s*주문|점심\s*뭐|저녁\s*뭐|밥은|맥날|커피|생일|축구|농구|야구")


def rooms(cfg: dict) -> list[str]:
    return [r.strip() for r in str(cfg.get("work_rooms") or "").split(",") if r.strip()]


def days_of(cfg: dict) -> int:
    try:
        return max(1, min(30, int(cfg.get("work_days") or DEFAULT_DAYS)))
    except (TypeError, ValueError):
        return DEFAULT_DAYS


# ------------------------------------------------------------------ 모으기
async def collect(cfg: dict, days: int, want: list[str]) -> tuple[str, list[str]]:
    """지정한 방들의 최근 글을 원문 그대로 모은다. 요약하지 않는다.

    want 가 비면 전체 방. 방 이름은 부분일치(사람이 정확히 안 쓴다).
    돌려주는 것: (다이제스트, 방별 건수 메모)
    """
    since = datetime.now(KST) - timedelta(days=days)
    lowants = [w.lower() for w in want]
    by: dict[str, list[dict]] = {}
    stat: list[str] = []

    async with search.TG_LOCK:                               # 감시·검색과 세션을 동시에 안 열게
        client = search.open_client(cfg)
        try:
            await client.connect()
            if not await client.is_user_authorized():
                raise search.SearchError("텔레그램 개인계정 인증이 안 돼 있어요.")
            me = await client.get_me()
            async for d in client.iter_dialogs():
                name = search._name_of(d.entity)
                if lowants and not any(w in name.lower() for w in lowants):
                    continue
                n = 0
                try:
                    async for m in client.iter_messages(d.entity, limit=SCAN_LIMIT):
                        if m.date and m.date.astimezone(KST) < since:
                            break
                        txt = (m.message or "").strip()
                        if not txt and m.media:
                            txt = "[첨부]"
                        if not txt or txt.startswith("/"):
                            continue
                        if len(txt) <= 20 and ACK.match(txt):
                            continue
                        if JUNK.search(txt[:60]):
                            continue
                        who = "나" if (me and m.sender_id == me.id) else search._name_of(m.sender)
                        by.setdefault(name, []).append({
                            "when": m.date.astimezone(KST).strftime("%m/%d %H:%M"),
                            "ts": m.date.timestamp(), "who": who,
                            "text": txt.replace("\n", " ⏎ ")})
                        n += 1
                except Exception as e:                       # noqa: BLE001 — 방 하나 실패해도 나머지는 계속
                    stat.append(f"{name}: 읽기 실패({type(e).__name__})")
                    continue
                if n:
                    stat.append(f"{name}: {n}건")
        finally:
            try:
                await client.disconnect()
            except Exception:                                # noqa: BLE001
                pass

    for ms in by.values():
        ms.sort(key=lambda r: r["ts"])
        privacy.learn(m["who"] for m in ms)                  # 사람 이름을 가릴 수 있게 알려둔다
    out = []
    for room, ms in by.items():
        out.append(f"\n### {room} ({len(ms)}건)")
        out += [f"[{m['when']}] {m['who']}: {m['text']}" for m in ms]
    return "\n".join(out)[:MAX_CHARS], stat


# ------------------------------------------------------------------ 판단(머리)
PROMPT = """아래는 텔레그램 방 {days}일치 원문이다. 업무 대화가 대부분이다. 지금은 {now} 이다.

이걸 읽고 **업무 목록**을 JSON 으로만 출력해라. 설명·인사말·``` 없이 JSON 만.

반드시 지킬 것
- 마감일은 원문에 적힌 말에서만 뽑아라. 없으면 due 를 null 로. 날짜를 추측해서 만들지 마라.
- D-day 는 계산하지 마라. due 만 정확히 적으면 날짜 계산은 프로그램이 한다.
- state 가 "완료"인 것은 끝났다는 말이 원문에 있을 때만. 인사말을 완료로 세지 마라.
- 일이 아닌 잡담·개인사는 넣지 마라.
- 근거(source)는 원문에 실제로 있는 발언으로 채워라. 없으면 그 항목을 만들지 마라.

형식
{{"items": [
  {{"title": "일 이름(짧게)",
    "state": "미회신" | "진행중" | "완료",
    "due": "2026-08-17" 또는 null,
    "detail": "지금 어디까지 왔는지 한 줄",
    "owner": ["이름"],
    "waiting_on": "미회신일 때만 — 누구 답을 기다리는가. 아니면 null",
    "source": {{"room": "방 이름", "who": "발언자", "when": "08/14 21:03"}} }}
]}}

state: "미회신"=시키거나 물었는데 그 뒤 답이 없음 / "진행중"=오가는 중 / "완료"=끝났다는 말이 있음

원문
{digest}
"""


def _parse(raw: str) -> dict | None:
    """머리 답에서 JSON 만 건진다. 못 건지면 None — 지어내지 않는다."""
    t = (raw or "").strip()
    if t.startswith("```"):
        t = re.sub(r"^```[a-zA-Z]*\n?", "", t)
        t = re.sub(r"\n?```\s*$", "", t)
    i, j = t.find("{"), t.rfind("}")
    if i < 0 or j <= i:
        return None
    try:
        obj = json.loads(t[i:j + 1])
    except json.JSONDecodeError:
        return None
    return obj if isinstance(obj.get("items"), list) else None


def think(cfg: dict, digest: str, days: int) -> dict | None:
    now = datetime.now(KST).strftime("%m/%d %H:%M")
    got = llm.ask(cfg, PROMPT.format(days=days, now=now, digest=digest), max_chars=MAX_CHARS)
    if not got:
        return None
    board = _parse(got)
    if board is None:
        log.info("업무현황 JSON 파싱 실패 — 앞 200자: %s", (got or "")[:200])
    return board


# ------------------------------------------------------------------ 날짜 계산(프로그램)
def enrich(board: dict) -> dict:
    """D-day·'마감 임박' 판정은 여기서 한다 — 머리에 날짜 계산을 시키지 않는다."""
    today = datetime.now(KST).date()
    items = []
    for it in board.get("items", []):
        if not isinstance(it, dict) or not it.get("title"):
            continue
        due, dday = it.get("due"), None
        if due:
            try:
                dday = (datetime.strptime(str(due)[:10], "%Y-%m-%d").date() - today).days
            except ValueError:
                due, dday = None, None                       # 형식이 이상하면 마감 없음으로
        state = it.get("state") if it.get("state") in ("미회신", "진행중", "완료") else "진행중"
        items.append({**it, "due": due, "dday": dday, "state": state})
    return {"as_of": datetime.now(KST).isoformat(timespec="seconds"), "items": items}


# ------------------------------------------------------------------ 글로 뽑기
WEEKDAY = "월화수목금토일"


def render(board: dict, me: str = "") -> str:
    """'내가 뭘 해야 하나' 만 짧게. 한 업무는 한 칸에만 넣는다 — 겹치면 뭐가 급한지 흐려진다."""
    now = datetime.fromisoformat(board["as_of"])
    overdue, mine, soon, waiting, rest, done = [], [], [], [], [], []
    for it in board["items"]:
        if it["state"] == "완료":
            done.append(it)
            continue
        d = it.get("dday")
        if d is not None and d < 0:
            overdue.append(it)
        elif me and it.get("waiting_on") == me:
            mine.append(it)
        elif d is not None and d <= 3:
            soon.append(it)
        elif it.get("waiting_on"):
            waiting.append(it)
        else:
            rest.append(it)
    overdue.sort(key=lambda x: x["dday"])
    soon.sort(key=lambda x: x["dday"])

    def mmdd(s):
        return str(s)[5:10].replace("-", "/")

    out = [f"📋 업무현황 — {now.month}/{now.day}({WEEKDAY[now.weekday()]})"]
    if overdue:
        out.append(f"\n🔴 기한 지난 것 ({len(overdue)})")
        out += [f"· {i['title']} — D+{-i['dday']} (마감 {mmdd(i['due'])})" for i in overdue]
    if mine:
        out.append(f"\n🟠 내 답을 기다리는 것 ({len(mine)})")
        out += [f"· {i['title']}" + (f" — {(i.get('source') or {}).get('room', '')}" if (i.get('source') or {}).get('room') else "")
                for i in mine]
    if soon:
        out.append(f"\n🟡 마감 임박 ({len(soon)})")
        for i in soon:
            when = "오늘" if i["dday"] == 0 else f"D-{i['dday']}"
            who = "·".join(i.get("owner") or [])
            out.append(f"· {i['title']} — {when} ({mmdd(i['due'])}) {who}".rstrip())
    if waiting:
        out.append(f"\n⏳ 답 기다리는 것 ({len(waiting)})")
        out += [f"· {i['title']} — {i['waiting_on']}" for i in waiting]
    if not (overdue or mine or soon or waiting):
        out.append("\n급한 것 없음 — 기한 지난 것도, 답할 것도 없습니다.")
    out.append(f"\n그 밖에 진행중 {len(rest)}건 · 최근 완료 {len(done)}건")
    out.append(f"({now:%m/%d %H:%M} 기준)")
    return "\n".join(out)


# ------------------------------------------------------------------ 한 번에
async def brief(cfg: dict, days: int | None = None) -> str:
    """모으기 → 판단 → 글. 실패하면 왜 실패했는지 말한다(그럴듯한 걸 만들지 않는다)."""
    if not (cfg.get("tg_api_id") and cfg.get("tg_api_hash")):
        return ("업무현황은 텔레그램 개인계정 연결이 필요해요.\n"
                "설정에서 tg_api_id / tg_api_hash 를 넣고 한 번 인증해 주세요.")
    if not llm.available(cfg):
        return ("업무현황은 머리(AI)가 필요해요 — 글을 읽고 판단해야 해서요.\n"
                "설정에서 제미나이 키를 넣거나 클로드 코드를 설치해 주세요.")
    d = days or days_of(cfg)
    want = rooms(cfg)
    digest, stat = await collect(cfg, d, want)
    if not digest.strip():
        where = f"({', '.join(want)})" if want else "(전체 방)"
        return f"최근 {d}일 동안 읽을 글이 없었어요 {where}."
    board = think(cfg, digest, d)
    if board is None:
        return ("업무현황을 만들지 못했어요 — 머리가 답을 못 주거나 형식이 깨졌어요.\n"
                "잠시 뒤 다시 해보시고, 계속 그러면 /status 로 머리 상태를 봐주세요.")
    b = enrich(board)
    text = render(b, me=str(cfg.get("my_name") or ""))
    log.info("업무현황: %s", " / ".join(stat[:8]))
    return text
