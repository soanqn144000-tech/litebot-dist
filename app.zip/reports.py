# -*- coding: utf-8 -*-
"""서무 주간 출결 보고문 읽기 — 엑셀이 없는 주를 메우는 두 번째 원천.

왜 필요한가: 예배출결 엑셀이 매주 다 올라오지는 않는다(3/29·6/14 처럼 빠지는 주가 있다).
그런데 서무는 매주 같은 형식의 **글**로 출결을 보고한다. 그 글은 사람이 확인해 올린
공식 수치다 — 지어낸 값이 아니다. 그래서 엑셀이 없을 때만 이걸로 채운다.

지키는 것(데이터 무결성 규칙):
  · 결석을 (재적 − 대면 − 줌) 으로 만들지 않는다. 글에 결석이 적혀 있을 때만 쓴다.
  · 대면+줌+결석 = 재적 이 아니면 그 주는 **버린다**. 그럴듯하게 맞추지 않는다.
  · 출처를 'report' 로 달아 엑셀('excel') 과 구분한다.

글 생김새(예):
    « 6월 14일(주일) 예배 출결 현황 »
    ㅇ전체재적: 4,546명
    ㅇ대면예배: 3,261명(71.2%)
    ㅇ줌예배: 902명(19.8%)
    ㅇ결석자: 383명(8.4%)
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta

import search

ROOM_HINTS = ("취합 및 보고", "담임강사님보고", "서무 점검")

_HEAD = re.compile(r"(\d{1,2})\s*월\s*(\d{1,2})\s*일\s*\(\s*(주일|수요)")
_NUM = r"[\d,]+"
_FIELDS = {                                                    # 우리 이름 → 글에 쓰인 말들
    "출결재적": ("전체재적", "총재적", "출결재적"),
    "대면":     ("대면예배", "대면"),
    "줌":       ("줌예배", "Zoom", "줌"),
    "결석":     ("결석자", "결석"),
    "대체":     ("대체예배", "대체"),
}


def _pick(text: str, words: tuple) -> int | None:
    """'ㅇ대면예배: 3,261명' 에서 3261 을 뽑는다. 못 찾으면 None(0 아님)."""
    for w in words:
        m = re.search(re.escape(w) + r"\s*[:：]?\s*(" + _NUM + r")\s*명", text)
        if m:
            try:
                return int(m.group(1).replace(",", ""))
            except ValueError:
                pass
    return None


def parse_report(text: str, year: int) -> tuple[str, str, dict] | None:
    """보고문 한 편 → (예배일 'YYYY-MM-DD', '주일'|'수요', 수치). 못 읽으면 None."""
    if not text or "재적" not in text:
        return None
    head = _HEAD.search(text)
    if not head:
        return None
    mo, day, kind = int(head.group(1)), int(head.group(2)), head.group(3)
    vals = {k: _pick(text, w) for k, w in _FIELDS.items()}
    cap = vals.get("출결재적")
    if not cap or vals.get("대면") is None:
        return None
    # 교차검증: 구성요소 합이 재적과 안 맞으면 버린다(차트 렌더 전 확인 규칙)
    parts = sum(v for k, v in vals.items() if k != "출결재적" and v)
    if parts and abs(parts - cap) > 1:
        return None
    d = {k: v for k, v in vals.items() if v is not None}
    if vals.get("대면") is not None:
        d["전체출석"] = cap - (vals.get("결석") or 0) if vals.get("결석") is not None else None
        if d["전체출석"] is None:
            d.pop("전체출석")
    return ("%04d-%02d-%02d" % (year, mo, day), kind, d)


async def weekly_numbers(cfg: dict, days: int = 220, kind: str = "주일") -> dict:
    """보고방들을 훑어 {예배일: 수치} 로 돌려준다. 같은 날이 여러 번이면 **가장 나중 것**(최종 보고)."""
    out: dict = {}
    client = search.open_client(cfg)
    try:
        await client.connect()
        if not await client.is_user_authorized():
            return {}
        KST = search.KST
        since = datetime.now(KST) - timedelta(days=days)
        best: dict = {}
        async for dlg in client.iter_dialogs(limit=400):
            name = dlg.name or ""
            if not any(h in name for h in ROOM_HINTS):
                continue
            async for m in client.iter_messages(dlg.id, limit=3000):
                when = m.date.astimezone(KST)
                if when < since:
                    break
                got = parse_report(m.message or "", when.year)
                if not got:
                    continue
                key, k, vals = got
                if k != kind:
                    continue
                prev = best.get(key)
                if prev is None or when > prev[0]:
                    best[key] = (when, vals)
        out = {k: v for k, (_when, v) in best.items()}
    finally:
        await client.disconnect()
    return out
