# -*- coding: utf-8 -*-
"""③ 데이터 차트 — matplotlib. TSV/CSV 파일 또는 숫자목록 → PNG.

종류: 꺾은선(기본) · 추이(전주 대비 증감) · 추세(선형회귀 점선).
스타일: 다크그린 배경 #0e2a20 · 골드 강조 #d8b15e · 큰 글씨 · 한글 폰트.
%라벨 상단(굵게 #FFDD77) · 명수 하단(회색) — 아델 차트 규칙.
"""
from __future__ import annotations

import csv
import io
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

import config

BG = "#0e2a20"
GOLD = "#d8b15e"
PCT = "#FFDD77"
GRAY = "#b9c4bd"
GRID = "#20463a"

# 한글 폰트: NotoSansCJK 있으면 우선, 없으면 맑은 고딕
_FONT_CANDIDATES = [
    r"C:\Windows\Fonts\NotoSansCJKkr-Regular.otf",
    r"C:\Windows\Fonts\NotoSansKR-Regular.otf",
    r"C:\Windows\Fonts\malgun.ttf",
    r"C:\Windows\Fonts\malgunbd.ttf",
]


def _apply_font():
    for p in _FONT_CANDIDATES:
        try:
            fm.fontManager.addfont(p)
            name = fm.FontProperties(fname=p).get_name()
            plt.rcParams["font.family"] = name
            break
        except Exception:                                    # noqa: BLE001
            continue
    plt.rcParams["axes.unicode_minus"] = False


def parse_series(text: str) -> tuple[list[str], list[float]]:
    """TSV/CSV/숫자목록 텍스트 → (labels, values).

    - 2열이면 (label, value)
    - 1열이면 label 은 1,2,3…
    - 구분자 자동(탭/콤마/공백/줄바꿈)
    """
    labels: list[str] = []
    values: list[float] = []
    txt = text.strip()
    # 한 줄에 콤마/공백으로 나열된 숫자목록도 허용
    if "\n" not in txt and re.search(r"[,\s]", txt):
        nums = re.split(r"[,\s]+", txt)
        for i, n in enumerate(nums, 1):
            v = _num(n)
            if v is not None:
                labels.append(str(i)); values.append(v)
        return labels, values

    reader = csv.reader(io.StringIO(txt), delimiter=_sniff(txt))
    for i, row in enumerate(reader, 1):
        row = [c.strip() for c in row if c.strip() != ""]
        if not row:
            continue
        if len(row) == 1:
            v = _num(row[0])
            if v is not None:
                labels.append(str(len(values) + 1)); values.append(v)
        else:
            v = _num(row[-1])
            if v is not None:
                labels.append(row[0]); values.append(v)
    return labels, values


def _sniff(txt: str) -> str:
    first = txt.splitlines()[0] if txt.splitlines() else txt
    if "\t" in first: return "\t"
    if "," in first: return ","
    return " "


def _num(s: str):
    s = (s or "").strip().replace(",", "").replace("%", "")
    if s in ("", "-"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def make(text: str, kind: str = "꺾은선", title: str = "데이터 차트") -> str | None:
    labels, values = parse_series(text)
    if len(values) < 1:
        return None
    _apply_font()

    fig, ax = plt.subplots(figsize=(11, 6), dpi=150)
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(BG)

    x = list(range(len(values)))
    plot_vals = values
    ylabel = "값"

    if kind == "추이":                                       # 전주 대비 증감
        deltas = [0.0] + [values[i] - values[i - 1] for i in range(1, len(values))]
        plot_vals = deltas
        ylabel = "전 구간 대비 증감"
        colors = ["#7ecb9a" if d >= 0 else "#e07b6a" for d in deltas]
        ax.bar(x, deltas, color=colors, edgecolor=GOLD, linewidth=0.6)
        ax.axhline(0, color=GOLD, linewidth=1)
        for xi, d in zip(x, deltas):
            ax.text(xi, d + (0.02 * (max(deltas) - min(deltas) + 1)) * (1 if d >= 0 else -3),
                    f"{d:+.0f}", ha="center", color=PCT, fontsize=12, fontweight="bold")
    else:
        ax.plot(x, values, "-o", color=GOLD, linewidth=2.6, markersize=8,
                markerfacecolor=GOLD, markeredgecolor="white", label="값")
        for xi, v in zip(x, values):
            ax.text(xi, v, f"{v:g}", ha="center", va="bottom",
                    color=PCT, fontsize=12, fontweight="bold")
        if kind == "추세" and len(values) >= 2:              # 선형회귀 점선
            import numpy as np
            a, b = np.polyfit(x, values, 1)
            ax.plot(x, [a * xi + b for xi in x], "--", color=GRAY, linewidth=1.8,
                    label=f"추세({'+' if a >= 0 else ''}{a:.1f}/구간)")
            ax.legend(facecolor=BG, edgecolor=GRID, labelcolor="white", fontsize=12)

    ax.set_title(title, color=GOLD, fontsize=22, fontweight="bold", pad=16)
    ax.set_ylabel(ylabel, color=GRAY, fontsize=13)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, color="white", fontsize=12, rotation=0)
    ax.tick_params(colors=GRAY)
    for sp in ax.spines.values():
        sp.set_color(GRID)
    ax.grid(True, axis="y", color=GRID, alpha=0.5)
    fig.tight_layout()

    out = config.data_file("chart.png")
    fig.savefig(out, facecolor=BG, bbox_inches="tight")
    plt.close(fig)
    return str(out)
