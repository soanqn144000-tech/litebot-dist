# -*- coding: utf-8 -*-
"""③ 데이터 차트 — matplotlib. TSV/CSV 파일 또는 숫자목록 → PNG.

종류: 꺾은선(기본) · 추이(전주 대비 증감) · 추세(선형회귀 점선).
스타일: 다크그린 배경 #0e2a20 · 골드 강조 #d8b15e · 큰 글씨 · 한글 폰트.
%라벨 상단(굵게 #FFDD77) · 명수 하단(회색) — 아델 차트 규칙.
"""
from __future__ import annotations

import csv
import io
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import os
from matplotlib import font_manager as fm

import config

BG = "#0e2a20"
GOLD = "#d8b15e"
PCT = "#FFDD77"
GRAY = "#b9c4bd"
GRID = "#20463a"

# 한글 폰트 후보 — 윈도우/맥/리눅스 공통. 있는 것 중 먼저 잡히는 걸 쓴다.
_FONT_CANDIDATES = [
    # Windows
    r"C:\Windows\Fonts\NotoSansCJKkr-Regular.otf",
    r"C:\Windows\Fonts\NotoSansKR-Regular.otf",
    r"C:\Windows\Fonts\malgun.ttf",
    r"C:\Windows\Fonts\malgunbd.ttf",
    # macOS
    "/System/Library/Fonts/AppleSDGothicNeo.ttc",
    "/System/Library/Fonts/Supplemental/AppleGothic.ttf",
    "/Library/Fonts/NanumGothic.ttf",
    str(Path.home() / "Library/Fonts/NanumGothic.ttf"),
    # Linux
    "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
]
_FONT_APPLIED = None



_HEAVY_PATHS = [                                              # 굵은 한글 — 있는 것 중 첫 번째
    os.path.expanduser("~/Library/Fonts/NanumSquare_acEB.ttf"),
    os.path.expanduser("~/Library/Fonts/NanumSquare_acB.ttf"),
    "/System/Library/Fonts/AppleSDGothicNeo.ttc",
    r"C:\Windows\Fonts\malgunbd.ttf",
]
_heavy_cache: dict = {}


def _heavy(size: float):
    """제목용 굵은 글꼴. 없으면 None 을 줘서 기본 글꼴 bold 로 떨어지게 한다.

    matplotlib 의 fontweight='bold' 는 그 글꼴에 굵은 판이 있어야 진짜로 굵어진다.
    한글 기본 글꼴은 굵은 판이 없어 얇게 나온다(사용자 지적 2026-08-13).
    """
    if size in _heavy_cache:
        return _heavy_cache[size]
    got = None
    for path in _HEAVY_PATHS:
        if os.path.exists(path):
            try:
                got = fm.FontProperties(fname=path, size=size)
                break
            except Exception:                                  # noqa: BLE001
                continue
    _heavy_cache[size] = got
    return got

def _apply_font():
    global _FONT_APPLIED
    if _FONT_APPLIED:
        plt.rcParams["font.family"] = _FONT_APPLIED
        plt.rcParams["axes.unicode_minus"] = False
        return
    import os
    for p in _FONT_CANDIDATES:
        try:
            if not os.path.exists(p):
                continue
            fm.fontManager.addfont(p)
            name = fm.FontProperties(fname=p).get_name()
            _FONT_APPLIED = name
            plt.rcParams["font.family"] = name
            break
        except Exception:                                    # noqa: BLE001
            continue
    if not _FONT_APPLIED:                                    # 경로로 못 찾으면 설치된 폰트 중 한글 되는 걸 검색
        for f in fm.fontManager.ttflist:
            if any(k in f.name for k in ("Gothic", "Nanum", "Noto Sans CJK", "Noto Sans KR",
                                         "Malgun", "AppleGothic", "PingFang", "Apple SD")):
                _FONT_APPLIED = f.name
                plt.rcParams["font.family"] = f.name
                break
    plt.rcParams["axes.unicode_minus"] = False


def parse_series(text: str) -> tuple[list[str], list[float]]:
    """TSV/CSV/숫자목록 텍스트 → (labels, values).

    - 2열이면 (label, value)
    - 1열이면 label 은 1,2,3…
    - 구분자 자동(탭/콤마/공백/줄바꿈)
    """
    labels: list[str] = []
    values: list[float] = []
    txt = text.strip()
    # 한 줄에 콤마/공백으로 나열된 숫자목록도 허용
    if "\n" not in txt and re.search(r"[,\s]", txt):
        nums = re.split(r"[,\s]+", txt)
        for i, n in enumerate(nums, 1):
            v = _num(n)
            if v is not None:
                labels.append(str(i)); values.append(v)
        return labels, values

    reader = csv.reader(io.StringIO(txt), delimiter=_sniff(txt))
    for i, row in enumerate(reader, 1):
        row = [c.strip() for c in row if c.strip() != ""]
        if not row:
            continue
        if len(row) == 1:
            v = _num(row[0])
            if v is not None:
                labels.append(str(len(values) + 1)); values.append(v)
        else:
            v = _num(row[-1])
            if v is not None:
                labels.append(row[0]); values.append(v)
    return labels, values


def _sniff(txt: str) -> str:
    first = txt.splitlines()[0] if txt.splitlines() else txt
    if "\t" in first: return "\t"
    if "," in first: return ","
    return " "


def _num(s: str):
    s = (s or "").strip().replace(",", "").replace("%", "")
    if s in ("", "-"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def make(text: str, kind: str = "꺾은선", title: str = "데이터 차트") -> str | None:
    labels, values = parse_series(text)
    if len(values) < 1:
        return None
    _apply_font()

    fig, ax = plt.subplots(figsize=(11, 6), dpi=150)
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(BG)

    x = list(range(len(values)))
    plot_vals = values
    ylabel = "값"

    if kind == "추이":                                       # 전주 대비 증감
        deltas = [0.0] + [values[i] - values[i - 1] for i in range(1, len(values))]
        plot_vals = deltas
        ylabel = "전 구간 대비 증감"
        colors = ["#7ecb9a" if d >= 0 else "#e07b6a" for d in deltas]
        ax.bar(x, deltas, color=colors, edgecolor=GOLD, linewidth=0.6)
        ax.axhline(0, color=GOLD, linewidth=1)
        for xi, d in zip(x, deltas):
            ax.text(xi, d + (0.02 * (max(deltas) - min(deltas) + 1)) * (1 if d >= 0 else -3),
                    f"{d:+.0f}", ha="center", color=PCT, fontsize=12, fontweight="bold")
    else:
        ax.plot(x, values, "-o", color=GOLD, linewidth=2.6, markersize=8,
                markerfacecolor=GOLD, markeredgecolor="white", label="값")
        for xi, v in zip(x, values):
            ax.text(xi, v, f"{v:g}", ha="center", va="bottom",
                    color=PCT, fontsize=12, fontweight="bold")
        if kind == "추세" and len(values) >= 2:              # 선형회귀 점선
            import numpy as np
            a, b = np.polyfit(x, values, 1)
            ax.plot(x, [a * xi + b for xi in x], "--", color=GRAY, linewidth=1.8,
                    label=f"추세({'+' if a >= 0 else ''}{a:.1f}/구간)")
            ax.legend(facecolor=BG, edgecolor=GRID, labelcolor="white", fontsize=12)

    ax.set_title(title, color=GOLD, fontsize=22, fontweight="bold", pad=16)
    ax.set_ylabel(ylabel, color=GRAY, fontsize=13)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, color="white", fontsize=12, rotation=0)
    ax.tick_params(colors=GRAY)
    for sp in ax.spines.values():
        sp.set_color(GRID)
    ax.grid(True, axis="y", color=GRID, alpha=0.5)
    fig.tight_layout()

    out = config.data_file("chart.png")
    fig.savefig(out, facecolor=BG, bbox_inches="tight", pad_inches=0.42)
    plt.close(fig)
    return str(out)


# ── 규격 차트(아델 render_chart.py 와 같은 JSON 규격) ────────────────────────────
# {"type":"bar|hbar|line|pie|grouped|stacked", "title":…, "labels":[…],
#  "values":[…] 또는 "series":[{"name":…,"values":[…]}], "unit":"명", "footer":"출처"}
SERIES_COLORS = [GOLD, "#7ecb9a", "#8fb8e0", "#e0a3a3", "#c9a7e0", "#e0cf8f"]
TEXT_CREAM = "#e8e0cf"


def _fmt(v: float, unit: str) -> str:
    s = f"{v:,.0f}" if abs(v - round(v)) < 0.05 else f"{v:,.1f}"
    return s + (unit or "")


PANEL_COLORS = {"전체출석": GOLD, "대면": "#7ecb9a", "줌": "#8fb8e0", "대체": "#e0a3a3",
                "결석": "#c9a7e0", "영상": "#e0cf8f", "심방": "#9ad0c0", "인시센": "#d0b0e0"}


# 늘면 좋은 지표. 이 둘만 긍정이고 나머지 출결 지표는 늘면 나쁨(아델 theme.POSITIVE_METRICS 와 같은 규칙).
POSITIVE = {"전체출석", "대면"}
V_GREEN, V_YELLOW, V_RED = "#4ade80", "#e7c65a", "#e0607a"


def verdict_color(metric: str, d_cnt: float, d_pct: float) -> str:
    """증감(명수·%p)을 지표 성격에 따라 색으로 판정 — 아델과 같은 기준.
    긍정: 명↑ 초록 / 명↓%↑ 노랑 / 명↓%↓ 빨강.   부정: 명↑ 빨강 / 명↓%↑ 노랑 / 명↓%↓ 초록."""
    if d_cnt == 0 and d_pct == 0:
        return GRAY
    up = d_cnt > 0
    p_up = d_pct > 0
    if metric in POSITIVE:
        return V_GREEN if up else (V_YELLOW if p_up else V_RED)
    return V_RED if up else (V_YELLOW if p_up else V_GREEN)


def make_trend_one(labels: list[str], name: str, pcts: list[float], counts: list[float],
                   page: str = "", footer: str = "", out_name: str = "chart.png",
                   suptitle: str = "", sub1: str = "", sub2: str = "",
                   disp: str = "") -> str | None:
    """지표 하나를 한 장 크게(아델 1/8 방식).
    선은 %축, 점마다 위=% (라이트옐로·볼드) / 아래=명수 (회색). 제목에 %p·명 증감 둘 다."""
    import numpy as np
    pv = [float(v) for v in pcts]
    cv = [float(v) for v in counts]
    if not any(v != 0 for v in cv):
        return None
    _apply_font()
    x = list(range(len(labels)))
    c = PANEL_COLORS.get(name, GOLD)
    fig, ax = plt.subplots(figsize=(17.8, 10.0), dpi=150)   # 아델과 같은 16:9
    fig.patch.set_facecolor(BG); ax.set_facecolor(BG)

    if len(pv) >= 2:                                          # 추세선(점선)
        a, b = np.polyfit(x, pv, 1)
        ax.plot(x, [a * xi + b for xi in x], "--", color=c, linewidth=1.4, alpha=0.45)
    ax.plot(x, pv, "-o", color=c, linewidth=2.6, markersize=7,
            markeredgecolor="white", zorder=3)
    # 글자 뒤에 배경을 깔아 선·추세선이 지나가도 안 가리게 한다.
    # (2026-08-12: 경사가 급한 구간에서 '4,397'·'93.6%' 가 선에 걸려 안 읽혔다.
    #  라벨 위치가 고정이라 기울기가 크면 선이 글자를 관통한다 — 배경으로 막는 게 확실하다.)
    _box = dict(boxstyle="round,pad=0.18", facecolor=BG, edgecolor="none", alpha=0.88)
    # 홀짝으로 높이를 엇갈린다(아델 stagger) — 점이 촘촘해도 옆 라벨과 안 겹친다.
    STAG = 40
    for i, (xi, p, cnt) in enumerate(zip(x, pv, cv)):        # 위=% / 아래=명수
        off = STAG if (i % 2) else 0
        ax.annotate(f"{p:.1f}%", (xi, p), textcoords="offset points", xytext=(0, 27 + off),
                    ha="center", fontsize=31, fontweight="bold", color=PCT, zorder=6,
                    bbox=_box)
        # 명수엔 단위를 붙인다 — 숫자만 있으면 % 인지 명수인지 헷갈린다(부장님 지시 2026-08-13)
        ax.annotate(f"{cnt:,.0f}명", (xi, p), textcoords="offset points", xytext=(0, -46 - off),
                    ha="center", fontsize=28, fontweight="bold", color=GRAY, zorder=6, bbox=_box)

    # ── 머리글: 큰제목 + 가운데 지표제목(전후값·증감) ──
    # 설명 2줄(sub1·sub2)은 안 그린다. 글씨가 너무 작아 읽히지도 않으면서 제목 자리만 먹었다
    # (사용자 지시 2026-08-13). 인자는 남겨둔다 — 부르는 쪽을 안 건드리려고.
    if suptitle:
        fig.suptitle(suptitle, color=GOLD, fontsize=38, fontweight="bold", y=0.988,
                     fontproperties=_heavy(38))

    # 지표 제목 — 증감은 '직전 전주 대비'(아델 기준). 색은 지표 성격 판정색.
    if len(pv) >= 2:
        dp, dc = pv[-1] - pv[-2], cv[-1] - cv[-2]
    else:
        dp = dc = 0.0
    col = verdict_color(name, dc, dp)
    ap = "▲" if dp > 0 else ("▼" if dp < 0 else "–")
    acn = "▲" if dc > 0 else ("▼" if dc < 0 else "–")
    fig.text(0.5, 0.838, disp or name, ha="center", color=col, fontsize=32,
             fontweight="bold", fontproperties=_heavy(32))
    if len(pv) >= 2:
        fig.text(0.5, 0.774, f"%   {pv[-2]:.1f} → {pv[-1]:.1f}    {ap}{abs(dp):.1f}%p",
                 ha="center", color=col, fontsize=25, fontweight="bold", fontproperties=_heavy(25))
        fig.text(0.5, 0.722, f"명   {cv[-2]:,.0f} → {cv[-1]:,.0f}    {acn}{abs(dc):,.0f}",
                 ha="center", color=col, fontsize=25, fontweight="bold", fontproperties=_heavy(25))
    ax.set_xticks(x); ax.set_xticklabels(labels, color="white", fontsize=17)
    ax.tick_params(colors=GRAY, labelsize=16)
    from matplotlib.ticker import FuncFormatter
    # y축 눈금. 인시센처럼 0.1~0.2% 대에서 노는 지표는 정수로 찍으면 눈금이 전부 '0%' 가 돼
    # 눈금 구실을 못 한다(2026-08-13 확인). 눈금 간격이 좁으면 소수 자리를 늘린다.
    _ticks = ax.get_yticks()
    _step = min((abs(b - a) for a, b in zip(_ticks, _ticks[1:])), default=1.0)
    _dec = 0 if _step >= 1 else (1 if _step >= 0.1 else 2)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _p: f"{v:.{_dec}f}%"))
    for sp in ax.spines.values():
        sp.set_color(GRID)
    ax.grid(True, axis="y", color=GRID, alpha=0.5)
    ax.set_ylabel("출결재적 대비 %", color=GRAY, fontsize=14)
    ax.margins(y=0.74)                                        # 위아래 라벨 잘리지 않게 여백
    if footer:
        fig.text(0.5, 0.018, footer, ha="center", color=GRAY, fontsize=11)
    fig.subplots_adjust(top=0.638, bottom=0.125, left=0.055, right=0.985)
    out = config.data_file(out_name)
    fig.savefig(out, facecolor=BG, bbox_inches="tight", pad_inches=0.42)
    plt.close(fig)
    return str(out)


def make_trend_panels(labels: list[str], series: list[dict], unit: str,
                      order: list[str], title: str, footer: str = "") -> str | None:
    """아델식 추이 — 지표마다 개별 패널(y축 자동 확대), 선 + 추세선(점선) + 값 라벨 + 증감.
    지표별로 나눠야 스케일이 다른 항목(전체 4400 vs 결석 100)도 변화가 보인다."""
    import numpy as np
    smap = {s["name"]: [float(v) for v in s["values"]] for s in series}
    metrics = [n for n in order if n in smap and any(v != 0 for v in smap[n])]
    if not metrics:
        return None
    _apply_font()
    x = list(range(len(labels)))
    cols = 1 if len(metrics) <= 2 else 2
    rows = (len(metrics) + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(7.2 * cols, 3.2 * rows + 0.8),
                             dpi=150, squeeze=False)
    fig.patch.set_facecolor(BG)
    fig.suptitle(title, color=GOLD, fontsize=23, fontweight="bold", y=0.998)
    flat = [axes[r][c] for r in range(rows) for c in range(cols)]

    for ax, nm in zip(flat, metrics):
        ax.set_facecolor(BG)
        vals = smap[nm]
        c = PANEL_COLORS.get(nm, GOLD)
        ax.plot(x, vals, "-o", color=c, linewidth=2.8, markersize=7,
                markeredgecolor="white", zorder=3)
        for xi, v in zip(x, vals):
            ax.text(xi, v, _fmt(v, ""), ha="center", va="bottom",
                    color=PCT, fontsize=9.5, fontweight="bold", zorder=4)
        delta = ""
        if len(vals) >= 2:
            a, b = np.polyfit(x, vals, 1)
            ax.plot(x, [a * xi + b for xi in x], "--", color=c, linewidth=1.3, alpha=0.55)
            dv = vals[-1] - vals[0]
            arrow = "▲" if dv > 0 else ("▼" if dv < 0 else "–")
            delta = f"   {arrow}{abs(dv):.1f}{unit}".rstrip("0").rstrip(".") if unit == "%" \
                else f"   {arrow}{abs(dv):.0f}{unit}"
        ax.set_title(f"{nm}{delta}", color=TEXT_CREAM, fontsize=15, fontweight="bold",
                     loc="left", pad=6)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, color="white", fontsize=9.5, rotation=0)
        ax.tick_params(colors=GRAY)
        for sp in ax.spines.values():
            sp.set_color(GRID)
        ax.grid(True, axis="y", color=GRID, alpha=0.45)
        ax.margins(y=0.28)                                   # y축을 데이터 범위로 확대(변화가 보이게)

    for ax in flat[len(metrics):]:                           # 남는 칸은 숨김
        ax.axis("off")
    if footer:
        fig.text(0.99, 0.005, footer, ha="right", color=GRAY, fontsize=11)
    fig.tight_layout(rect=(0, 0.015, 1, 0.975))
    out = config.data_file("chart.png")
    fig.savefig(out, facecolor=BG, bbox_inches="tight", pad_inches=0.42)
    plt.close(fig)
    return str(out)


def make_spec(spec: dict) -> str | None:
    """JSON 규격 하나로 막대·가로막대·꺾은선·원형·묶음·누적까지. 실패하면 None."""
    labels = [str(x) for x in (spec.get("labels") or [])]
    series = spec.get("series") or ([{"name": spec.get("name") or "값",
                                      "values": spec.get("values")}]
                                    if spec.get("values") else [])
    series = [s for s in series if s.get("values")]
    if not series or not labels:
        return None
    for s in series:                                         # 라벨 수에 맞춰 자르거나 채움
        v = [_num(str(x)) or 0.0 for x in s["values"]][:len(labels)]
        s["values"] = v + [0.0] * (len(labels) - len(v))

    kind = (spec.get("type") or "bar").lower()
    unit = spec.get("unit") or ""
    title = spec.get("title") or "데이터 차트"
    _apply_font()
    fig, ax = plt.subplots(figsize=(12, 6.5), dpi=150)
    fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
    x = list(range(len(labels)))

    if kind in ("pie", "donut"):
        vals = series[0]["values"]
        wedges, _t, autot = ax.pie(
            vals, labels=labels, autopct=lambda p: f"{p:.0f}%", startangle=90,
            colors=SERIES_COLORS * 4, textprops={"color": "white", "fontsize": 14},
            wedgeprops={"width": 0.45 if kind == "donut" else 1.0, "edgecolor": BG})
        for t in autot:
            t.set_color(PCT); t.set_fontweight("bold"); t.set_fontsize(15)
        ax.set_aspect("equal")
    elif kind == "hbar":
        vals = series[0]["values"]
        ax.barh(x, vals, color=GOLD, edgecolor=GRID)
        ax.set_yticks(x); ax.set_yticklabels(labels, color="white", fontsize=14)
        ax.invert_yaxis()
        for xi, v in zip(x, vals):
            ax.text(v, xi, " " + _fmt(v, unit), va="center", color=PCT,
                    fontsize=14, fontweight="bold")
    elif kind == "line":
        for i, s in enumerate(series):
            c = SERIES_COLORS[i % len(SERIES_COLORS)]
            ax.plot(x, s["values"], "-o", color=c, linewidth=2.6, markersize=8,
                    markeredgecolor="white", label=s.get("name") or f"계열{i+1}")
            for xi, v in zip(x, s["values"]):
                ax.text(xi, v, _fmt(v, unit), ha="center", va="bottom",
                        color=PCT, fontsize=13, fontweight="bold")
        ax.set_xticks(x); ax.set_xticklabels(labels, color="white", fontsize=13)
    elif kind == "stacked":
        bottom = [0.0] * len(labels)
        for i, s in enumerate(series):
            ax.bar(x, s["values"], bottom=bottom, color=SERIES_COLORS[i % len(SERIES_COLORS)],
                   edgecolor=BG, label=s.get("name") or f"계열{i+1}")
            bottom = [b + v for b, v in zip(bottom, s["values"])]
        for xi, tot in zip(x, bottom):
            ax.text(xi, tot, _fmt(tot, unit), ha="center", va="bottom",
                    color=PCT, fontsize=13, fontweight="bold")
        ax.set_xticks(x); ax.set_xticklabels(labels, color="white", fontsize=13)
    else:                                                    # bar / grouped
        n = len(series)
        w = 0.8 / n
        for i, s in enumerate(series):
            pos = [xi - 0.4 + w * (i + 0.5) for xi in x]
            ax.bar(pos, s["values"], width=w, color=SERIES_COLORS[i % len(SERIES_COLORS)],
                   edgecolor=GRID, label=s.get("name") or f"계열{i+1}")
            for px, v in zip(pos, s["values"]):
                ax.text(px, v, _fmt(v, unit), ha="center", va="bottom",
                        color=PCT, fontsize=13 if n == 1 else 11, fontweight="bold")
        ax.set_xticks(x); ax.set_xticklabels(labels, color="white", fontsize=13)

    ax.set_title(title, color=GOLD, fontsize=24, fontweight="bold", pad=16)
    if kind not in ("pie", "donut"):
        ax.tick_params(colors=GRAY)
        for sp in ax.spines.values():
            sp.set_color(GRID)
        ax.grid(True, axis="x" if kind == "hbar" else "y", color=GRID, alpha=0.5)
        if len(series) > 1:
            ax.legend(facecolor=BG, edgecolor=GRID, labelcolor="white", fontsize=13)
    if spec.get("footer"):                                   # 출처는 축 라벨과 안 겹치게 아래 여백을 두고
        fig.tight_layout(rect=(0, 0.05, 1, 1))
        fig.text(0.99, 0.015, str(spec["footer"]), ha="right", color=GRAY, fontsize=11)
    else:
        fig.tight_layout()

    out = config.data_file("chart.png")
    fig.savefig(out, facecolor=BG, bbox_inches="tight", pad_inches=0.42)
    plt.close(fig)
    return str(out)


DEPT_COLORS = {                                               # 디자인 시스템 색(부서 고정 배정)
    "자문회": "#01934E",                                       # 그린
    "장년회": "#d8b15e",                                       # 골드
    "부녀회": "#FD8A69",                                       # 코랄
    "청년회": "#5BC8E8",                                       # 하늘 — 틸(#2E7D74)은 배경에 묻힌다
}


def make_dept_trend(labels: list[str], metric: str, series: dict,
                    out_name: str = "dept.png", suptitle: str = "", footer: str = "",
                    disp: str = "") -> str | None:
    """한 지표를 부서 4개로. 한 판에 선 4개를 겹치면 읽을 수가 없어서(부장님 지적 2026-08-14)
    **2x2 로 쪼개** 부서마다 자기 칸을 준다.

    한 칸엔 그 부서 선 하나만. 나머지 부서를 회색으로 깔아봤더니 선이 너무 많아져서
    도로 뺐다(2026-08-14). 위아래 비교는 눈금(y축)을 네 칸 똑같이 두는 것으로 충분하다.
    """
    import numpy as np
    _apply_font()
    have = {d: v for d, v in series.items() if v and any(c is not None for c in v[1])}
    if len(have) < 2 or len(labels) < 2:
        return None
    depts = [d for d in ("자문회", "장년회", "부녀회", "청년회") if d in have]
    x = np.arange(len(labels))
    lo = min(min(v[0]) for v in have.values())
    hi = max(max(v[0]) for v in have.values())
    pad = max((hi - lo) * 0.30, 0.6)

    fig, axes = plt.subplots(2, 2, figsize=(19.2, 11.4), dpi=150, sharex=True, sharey=True)
    fig.patch.set_facecolor(BG)
    _box = dict(boxstyle="round,pad=0.16", facecolor=BG, edgecolor="none", alpha=0.9)
    from matplotlib.ticker import FuncFormatter
    _dec = 0 if (hi - lo) >= 6 else (1 if (hi - lo) >= 0.6 else 2)

    for ax, dept in zip(axes.ravel(), depts + [None] * 4):
        ax.set_facecolor(BG)
        for sp in ax.spines.values():
            sp.set_color(GRID)
        if dept is None:
            ax.axis("off")
            continue
        pcts, counts = have[dept]
        col = DEPT_COLORS.get(dept, GOLD)
        ax.plot(x, pcts, color=col, linewidth=3.4, marker="o", markersize=9,
                markerfacecolor=BG, markeredgewidth=2.6, markeredgecolor=col, zorder=5)
        for k, (xi, pv, cv) in enumerate(zip(x, pcts, counts)):
            if k % 2 and k != len(x) - 1:                     # 촘촘하면 한 칸 걸러 - 끝점은 항상
                continue
            ax.annotate(f"{pv:.1f}%", (xi, pv), textcoords="offset points", xytext=(0, 15),
                        ha="center", fontsize=17, fontweight="bold", color=PCT,
                        zorder=6, bbox=_box)
            ax.annotate(f"{cv:,.0f}명", (xi, pv), textcoords="offset points", xytext=(0, -26),
                        ha="center", fontsize=15, fontweight="bold", color=GRAY,
                        zorder=6, bbox=_box)
        d_p = pcts[-1] - pcts[-2]
        d_c = counts[-1] - counts[-2]
        ap = "▲" if d_p > 0 else ("▼" if d_p < 0 else "-")
        ac = "▲" if d_c > 0 else ("▼" if d_c < 0 else "-")
        vc = verdict_color(metric, d_c, d_p)
        ax.set_title(f"{dept}   {pcts[-1]:.1f}% {ap}{abs(d_p):.1f}%p   "
                     f"{counts[-1]:,.0f}명 {ac}{abs(d_c):,.0f}",
                     color=vc, fontsize=25, fontweight="bold", pad=12,
                     fontproperties=_heavy(25))
        ax.grid(True, axis="y", color=GRID, alpha=0.5)
        ax.tick_params(colors=GRAY, labelsize=14)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, color="white", fontsize=14)
        ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _p: f"{v:.{_dec}f}%"))
    axes[0][0].set_ylim(lo - pad, hi + pad)                   # sharey 라 한 번만 잡으면 된다

    if suptitle:
        fig.suptitle(suptitle, color=GOLD, fontsize=36, fontweight="bold", y=0.978,
                     fontproperties=_heavy(36))
    fig.text(0.5, 0.868, disp or metric, ha="center", color=TEXT_CREAM, fontsize=29,
             fontweight="bold", fontproperties=_heavy(29))
    if footer:
        fig.text(0.5, 0.014, footer, ha="center", color=GRAY, fontsize=11)
    fig.subplots_adjust(top=0.808, bottom=0.075, left=0.045, right=0.985,
                        hspace=0.30, wspace=0.10)
    out = config.data_file(out_name)
    fig.savefig(out, facecolor=BG, bbox_inches="tight", pad_inches=0.42)
    plt.close(fig)
    return str(out)
