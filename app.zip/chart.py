# -*- coding: utf-8 -*-
"""③ 데이터 차트 — matplotlib. TSV/CSV 파일 또는 숫자목록 → PNG.

종류: 꺾은선(기본) · 추이(전주 대비 증감) · 추세(선형회귀 점선).
스타일: 다크그린 배경 #0e2a20 · 골드 강조 #d8b15e · 큰 글씨 · 한글 폰트.
%라벨 상단(굵게 #FFDD77) · 명수 하단(회색) — 아델 차트 규칙.
"""
from __future__ import annotations

import csv
import io
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

import config

BG = "#0e2a20"
GOLD = "#d8b15e"
PCT = "#FFDD77"
GRAY = "#b9c4bd"
GRID = "#20463a"

# 한글 폰트: NotoSansCJK 있으면 우선, 없으면 맑은 고딕
_FONT_CANDIDATES = [
    r"C:\Windows\Fonts\NotoSansCJKkr-Regular.otf",
    r"C:\Windows\Fonts\NotoSansKR-Regular.otf",
    r"C:\Windows\Fonts\malgun.ttf",
    r"C:\Windows\Fonts\malgunbd.ttf",
]


def _apply_font():
    for p in _FONT_CANDIDATES:
        try:
            fm.fontManager.addfont(p)
            name = fm.FontProperties(fname=p).get_name()
            plt.rcParams["font.family"] = name
            break
        except Exception:                                    # noqa: BLE001
            continue
    plt.rcParams["axes.unicode_minus"] = False


def parse_series(text: str) -> tuple[list[str], list[float]]:
    """TSV/CSV/숫자목록 텍스트 → (labels, values).

    - 2열이면 (label, value)
    - 1열이면 label 은 1,2,3…
    - 구분자 자동(탭/콤마/공백/줄바꿈)
    """
    labels: list[str] = []
    values: list[float] = []
    txt = text.strip()
    # 한 줄에 콤마/공백으로 나열된 숫자목록도 허용
    if "\n" not in txt and re.search(r"[,\s]", txt):
        nums = re.split(r"[,\s]+", txt)
        for i, n in enumerate(nums, 1):
            v = _num(n)
            if v is not None:
                labels.append(str(i)); values.append(v)
        return labels, values

    reader = csv.reader(io.StringIO(txt), delimiter=_sniff(txt))
    for i, row in enumerate(reader, 1):
        row = [c.strip() for c in row if c.strip() != ""]
        if not row:
            continue
        if len(row) == 1:
            v = _num(row[0])
            if v is not None:
                labels.append(str(len(values) + 1)); values.append(v)
        else:
            v = _num(row[-1])
            if v is not None:
                labels.append(row[0]); values.append(v)
    return labels, values


def _sniff(txt: str) -> str:
    first = txt.splitlines()[0] if txt.splitlines() else txt
    if "\t" in first: return "\t"
    if "," in first: return ","
    return " "


def _num(s: str):
    s = (s or "").strip().replace(",", "").replace("%", "")
    if s in ("", "-"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def make(text: str, kind: str = "꺾은선", title: str = "데이터 차트") -> str | None:
    labels, values = parse_series(text)
    if len(values) < 1:
        return None
    _apply_font()

    fig, ax = plt.subplots(figsize=(11, 6), dpi=150)
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(BG)

    x = list(range(len(values)))
    plot_vals = values
    ylabel = "값"

    if kind == "추이":                                       # 전주 대비 증감
        deltas = [0.0] + [values[i] - values[i - 1] for i in range(1, len(values))]
        plot_vals = deltas
        ylabel = "전 구간 대비 증감"
        colors = ["#7ecb9a" if d >= 0 else "#e07b6a" for d in deltas]
        ax.bar(x, deltas, color=colors, edgecolor=GOLD, linewidth=0.6)
        ax.axhline(0, color=GOLD, linewidth=1)
        for xi, d in zip(x, deltas):
            ax.text(xi, d + (0.02 * (max(deltas) - min(deltas) + 1)) * (1 if d >= 0 else -3),
                    f"{d:+.0f}", ha="center", color=PCT, fontsize=12, fontweight="bold")
    else:
        ax.plot(x, values, "-o", color=GOLD, linewidth=2.6, markersize=8,
                markerfacecolor=GOLD, markeredgecolor="white", label="값")
        for xi, v in zip(x, values):
            ax.text(xi, v, f"{v:g}", ha="center", va="bottom",
                    color=PCT, fontsize=12, fontweight="bold")
        if kind == "추세" and len(values) >= 2:              # 선형회귀 점선
            import numpy as np
            a, b = np.polyfit(x, values, 1)
            ax.plot(x, [a * xi + b for xi in x], "--", color=GRAY, linewidth=1.8,
                    label=f"추세({'+' if a >= 0 else ''}{a:.1f}/구간)")
            ax.legend(facecolor=BG, edgecolor=GRID, labelcolor="white", fontsize=12)

    ax.set_title(title, color=GOLD, fontsize=22, fontweight="bold", pad=16)
    ax.set_ylabel(ylabel, color=GRAY, fontsize=13)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, color="white", fontsize=12, rotation=0)
    ax.tick_params(colors=GRAY)
    for sp in ax.spines.values():
        sp.set_color(GRID)
    ax.grid(True, axis="y", color=GRID, alpha=0.5)
    fig.tight_layout()

    out = config.data_file("chart.png")
    fig.savefig(out, facecolor=BG, bbox_inches="tight")
    plt.close(fig)
    return str(out)


# ── 규격 차트(아델 render_chart.py 와 같은 JSON 규격) ────────────────────────────
# {"type":"bar|hbar|line|pie|grouped|stacked", "title":…, "labels":[…],
#  "values":[…] 또는 "series":[{"name":…,"values":[…]}], "unit":"명", "footer":"출처"}
SERIES_COLORS = [GOLD, "#7ecb9a", "#8fb8e0", "#e0a3a3", "#c9a7e0", "#e0cf8f"]
TEXT_CREAM = "#e8e0cf"


def _fmt(v: float, unit: str) -> str:
    s = f"{v:,.0f}" if abs(v - round(v)) < 0.05 else f"{v:,.1f}"
    return s + (unit or "")


PANEL_COLORS = {"전체출석": GOLD, "대면": "#7ecb9a", "줌": "#8fb8e0", "대체": "#e0a3a3",
                "결석": "#c9a7e0", "영상": "#e0cf8f", "심방": "#9ad0c0", "인시센": "#d0b0e0"}


def make_trend_panels(labels: list[str], series: list[dict], unit: str,
                      groups: list[list[str]], title: str, footer: str = "") -> str | None:
    """아델식 여러 장 추이 — 패널마다 선 + 추세선(점선) + 값 라벨 + 시작→끝 증감.
    groups = [['전체출석'], ['대면','줌'], ['대체','결석'], ['영상','심방','인시센']] 처럼."""
    smap = {s["name"]: [float(v) for v in s["values"]] for s in series}
    groups = [[n for n in g if n in smap and any(smap[n])] for g in groups]
    groups = [g for g in groups if g]
    if not groups:
        return None
    _apply_font()
    x = list(range(len(labels)))
    n = len(groups)
    fig, axes = plt.subplots(n, 1, figsize=(13, 3.1 * n + 0.6), dpi=150, squeeze=False)
    fig.patch.set_facecolor(BG)
    fig.suptitle(title, color=GOLD, fontsize=24, fontweight="bold", y=0.995)

    for ax, names in zip((a[0] for a in axes), groups):
        ax.set_facecolor(BG)
        deltas = []
        for nm in names:
            vals = smap[nm]
            c = PANEL_COLORS.get(nm, GOLD)
            ax.plot(x, vals, "-o", color=c, linewidth=2.6, markersize=7,
                    markeredgecolor="white", label=nm, zorder=3)
            for xi, v in zip(x, vals):
                ax.text(xi, v, _fmt(v, ""), ha="center", va="bottom",
                        color=PCT, fontsize=10, fontweight="bold", zorder=4)
            if len(vals) >= 2:                               # 추세선(점선)
                import numpy as np
                a, b = np.polyfit(x, vals, 1)
                ax.plot(x, [a * xi + b for xi in x], "--", color=c, linewidth=1.3, alpha=0.6)
                deltas.append(f"{nm} {vals[-1] - vals[0]:+.0f}{unit}")
        head = " · ".join(names) + (("   (" + ", ".join(deltas) + ")") if deltas else "")
        ax.set_title(head, color=TEXT_CREAM, fontsize=15, fontweight="bold", loc="left", pad=6)
        ax.set_xticks(x); ax.set_xticklabels(labels, color="white", fontsize=11)
        ax.tick_params(colors=GRAY)
        for sp in ax.spines.values():
            sp.set_color(GRID)
        ax.grid(True, axis="y", color=GRID, alpha=0.5)
        ax.margins(y=0.22)
        if len(names) > 1:
            ax.legend(facecolor=BG, edgecolor=GRID, labelcolor="white", fontsize=12, loc="best")

    if footer:
        fig.text(0.99, 0.006, footer, ha="right", color=GRAY, fontsize=11)
    fig.tight_layout(rect=(0, 0.02, 1, 0.98))
    out = config.data_file("chart.png")
    fig.savefig(out, facecolor=BG, bbox_inches="tight")
    plt.close(fig)
    return str(out)


def make_spec(spec: dict) -> str | None:
    """JSON 규격 하나로 막대·가로막대·꺾은선·원형·묶음·누적까지. 실패하면 None."""
    labels = [str(x) for x in (spec.get("labels") or [])]
    series = spec.get("series") or ([{"name": spec.get("name") or "값",
                                      "values": spec.get("values")}]
                                    if spec.get("values") else [])
    series = [s for s in series if s.get("values")]
    if not series or not labels:
        return None
    for s in series:                                         # 라벨 수에 맞춰 자르거나 채움
        v = [_num(str(x)) or 0.0 for x in s["values"]][:len(labels)]
        s["values"] = v + [0.0] * (len(labels) - len(v))

    kind = (spec.get("type") or "bar").lower()
    unit = spec.get("unit") or ""
    title = spec.get("title") or "데이터 차트"
    _apply_font()
    fig, ax = plt.subplots(figsize=(12, 6.5), dpi=150)
    fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
    x = list(range(len(labels)))

    if kind in ("pie", "donut"):
        vals = series[0]["values"]
        wedges, _t, autot = ax.pie(
            vals, labels=labels, autopct=lambda p: f"{p:.0f}%", startangle=90,
            colors=SERIES_COLORS * 4, textprops={"color": "white", "fontsize": 14},
            wedgeprops={"width": 0.45 if kind == "donut" else 1.0, "edgecolor": BG})
        for t in autot:
            t.set_color(PCT); t.set_fontweight("bold"); t.set_fontsize(15)
        ax.set_aspect("equal")
    elif kind == "hbar":
        vals = series[0]["values"]
        ax.barh(x, vals, color=GOLD, edgecolor=GRID)
        ax.set_yticks(x); ax.set_yticklabels(labels, color="white", fontsize=14)
        ax.invert_yaxis()
        for xi, v in zip(x, vals):
            ax.text(v, xi, " " + _fmt(v, unit), va="center", color=PCT,
                    fontsize=14, fontweight="bold")
    elif kind == "line":
        for i, s in enumerate(series):
            c = SERIES_COLORS[i % len(SERIES_COLORS)]
            ax.plot(x, s["values"], "-o", color=c, linewidth=2.6, markersize=8,
                    markeredgecolor="white", label=s.get("name") or f"계열{i+1}")
            for xi, v in zip(x, s["values"]):
                ax.text(xi, v, _fmt(v, unit), ha="center", va="bottom",
                        color=PCT, fontsize=13, fontweight="bold")
        ax.set_xticks(x); ax.set_xticklabels(labels, color="white", fontsize=13)
    elif kind == "stacked":
        bottom = [0.0] * len(labels)
        for i, s in enumerate(series):
            ax.bar(x, s["values"], bottom=bottom, color=SERIES_COLORS[i % len(SERIES_COLORS)],
                   edgecolor=BG, label=s.get("name") or f"계열{i+1}")
            bottom = [b + v for b, v in zip(bottom, s["values"])]
        for xi, tot in zip(x, bottom):
            ax.text(xi, tot, _fmt(tot, unit), ha="center", va="bottom",
                    color=PCT, fontsize=13, fontweight="bold")
        ax.set_xticks(x); ax.set_xticklabels(labels, color="white", fontsize=13)
    else:                                                    # bar / grouped
        n = len(series)
        w = 0.8 / n
        for i, s in enumerate(series):
            pos = [xi - 0.4 + w * (i + 0.5) for xi in x]
            ax.bar(pos, s["values"], width=w, color=SERIES_COLORS[i % len(SERIES_COLORS)],
                   edgecolor=GRID, label=s.get("name") or f"계열{i+1}")
            for px, v in zip(pos, s["values"]):
                ax.text(px, v, _fmt(v, unit), ha="center", va="bottom",
                        color=PCT, fontsize=13 if n == 1 else 11, fontweight="bold")
        ax.set_xticks(x); ax.set_xticklabels(labels, color="white", fontsize=13)

    ax.set_title(title, color=GOLD, fontsize=24, fontweight="bold", pad=16)
    if kind not in ("pie", "donut"):
        ax.tick_params(colors=GRAY)
        for sp in ax.spines.values():
            sp.set_color(GRID)
        ax.grid(True, axis="x" if kind == "hbar" else "y", color=GRID, alpha=0.5)
        if len(series) > 1:
            ax.legend(facecolor=BG, edgecolor=GRID, labelcolor="white", fontsize=13)
    if spec.get("footer"):                                   # 출처는 축 라벨과 안 겹치게 아래 여백을 두고
        fig.tight_layout(rect=(0, 0.05, 1, 1))
        fig.text(0.99, 0.015, str(spec["footer"]), ha="right", color=GRAY, fontsize=11)
    else:
        fig.tight_layout()

    out = config.data_file("chart.png")
    fig.savefig(out, facecolor=BG, bbox_inches="tight")
    plt.close(fig)
    return str(out)
