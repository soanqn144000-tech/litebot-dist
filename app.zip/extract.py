# -*- coding: utf-8 -*-
"""⑨ 아무거나 → 차트 규격(JSON). 파일·사진·대화글에서 숫자를 뽑는다.

  · 엑셀(.xlsx)·CSV·TSV·TXT → 표 텍스트로 변환(규칙, 머리 없이도 됨)
  · 머리(Gemini)가 있으면 그 표/사진/대화글을 읽어 차트 규격 JSON 을 만든다
  · 머리가 없거나 한도가 끝났으면 → 규칙 기반(첫 열=이름, 마지막 열=숫자)으로 내려간다

밖으로 나가는 글의 사람 이름은 llm.ask() 가 자동으로 가명 처리한다(privacy.py).

규격은 chart.make_spec() 이 그대로 받는다:
  {"type":"bar|hbar|line|pie|grouped|stacked","title":…,"labels":[…],
   "values":[…] 또는 "series":[{"name":…,"values":[…]}],"unit":"명","footer":…}
"""
from __future__ import annotations

import io
import json
import re

import chart
import config
import forms
import llm

log = config.get_logger()

SPEC_RULE = """너는 표를 읽어 차트 규격 JSON 하나만 뱉는 도구다. 설명·인사·코드펜스 금지, JSON 만.

규격:
{"type":"bar|hbar|line|pie|grouped|stacked","title":"짧은 제목","labels":["항목",…],
 "values":[숫자,…]  또는  "series":[{"name":"계열이름","values":[숫자,…]},…],
 "unit":"명|%|건 등(없으면 생략)","footer":"자료 출처·기간(있으면)"}

규칙:
- 숫자는 원문에 실제로 있는 값만. 없는 값을 지어내지 마라. 합계·평균 행은 빼라.
- 항목이 시간 순(주차·월·날짜)이면 type=line, 그 외 비교면 bar, 비율 한 벌이면 pie.
- 계열이 둘 이상(대면/줌 같은)이면 series 로, type=grouped 또는 stacked.
- 항목이 12개를 넘으면 큰 것부터 12개만.
- 표에서 숫자를 못 찾으면 {"error":"숫자 없음"} 만 뱉어라."""


def _json_from(reply: str) -> dict | None:
    if not reply:
        return None
    m = re.search(r"\{.*\}", reply.replace("```json", "").replace("```", ""), re.S)
    if not m:
        return None
    try:
        spec = json.loads(m.group(0))
    except Exception:                                        # noqa: BLE001
        return None
    return spec if isinstance(spec, dict) and not spec.get("error") else None


XLNS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def _col_index(ref: str) -> int:
    """'C7' → 2 (0부터). 빈 칸이 있어도 자리를 맞추려고."""
    n = 0
    for ch in ref:
        if not ch.isalpha():
            break
        n = n * 26 + (ord(ch.upper()) - 64)
    return max(n - 1, 0)


def xlsx_to_text(data: bytes, max_rows: int = 200, max_sheets: int = 3) -> str | None:
    """엑셀(.xlsx) → 탭 구분 표 텍스트. 표준 라이브러리만 사용(xlsx 는 zip+xml).

    새 라이브러리를 안 쓰는 이유: 로직(.py)만 중앙 배포되므로, exe 를 다시 깔지 않아도
    모든 PC 에서 바로 동작해야 한다.
    """
    import xml.etree.ElementTree as ET
    import zipfile
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
        shared: list[str] = []
        if "xl/sharedStrings.xml" in z.namelist():
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall(f"{XLNS}si"):
                shared.append("".join(t.text or "" for t in si.iter(f"{XLNS}t")))
        sheets = sorted(n for n in z.namelist()
                        if n.startswith("xl/worksheets/sheet") and n.endswith(".xml"))
        lines: list[str] = []
        for sn in sheets[:max_sheets]:
            root = ET.fromstring(z.read(sn))
            lines.append(f"# 시트: {sn.split('/')[-1].replace('.xml', '')}")
            for r, row in enumerate(root.iter(f"{XLNS}row")):
                if r >= max_rows:
                    break
                cells: list[str] = []
                for c in row.findall(f"{XLNS}c"):
                    i = _col_index(c.get("r", ""))
                    while len(cells) <= i:
                        cells.append("")
                    if c.get("t") == "s":                    # 공유문자열 색인
                        v = c.find(f"{XLNS}v")
                        idx = int(v.text) if v is not None and (v.text or "").isdigit() else -1
                        cells[i] = shared[idx] if 0 <= idx < len(shared) else ""
                    elif c.get("t") == "inlineStr":
                        cells[i] = "".join(t.text or "" for t in c.iter(f"{XLNS}t"))
                    else:
                        v = c.find(f"{XLNS}v")
                        cells[i] = (v.text or "") if v is not None else ""
                line = "\t".join(x.strip() for x in cells).rstrip("\t")
                if line.strip():
                    lines.append(line)
        return "\n".join(lines) if len(lines) > 1 else None
    except Exception as e:                                   # noqa: BLE001
        log.info("엑셀 읽기 실패: %s", type(e).__name__)
        return None


def has_decryptor() -> bool:
    """암호 해제 라이브러리가 이 설치본에 들어 있나(옛 exe 에는 없다)."""
    try:
        import msoffcrypto                                    # noqa: F401
        return True
    except Exception:                                        # noqa: BLE001
        return False


def decrypt_xlsx(data: bytes, passwords: list[str]) -> tuple[bytes | None, str]:
    """암호 걸린 엑셀 풀기. (푼 내용, 쓴 암호). 암호를 알아야 열린다 — 뚫는 게 아니다."""
    try:
        import msoffcrypto
    except Exception:                                        # noqa: BLE001
        return None, ""                                      # 옛 exe 에는 없음 → 조용히 포기
    for pw in passwords:
        pw = (pw or "").strip()
        if not pw:
            continue
        try:
            f = msoffcrypto.OfficeFile(io.BytesIO(data))
            f.load_key(password=pw)
            out = io.BytesIO()
            f.decrypt(out)
            return out.getvalue(), pw
        except Exception:                                    # noqa: BLE001
            continue
    return None, ""


def read_document(name: str, data: bytes, cfg: dict | None = None) -> tuple[str | None, str | None]:
    """파일 → (표 텍스트, 못 읽은 이유). 둘 중 하나만 채워진다."""
    low = (name or "").lower()
    if low.endswith((".xlsx", ".xlsm")):
        if data[:4] == b"\xd0\xcf\x11\xe0":                  # OLE = 암호 걸린 엑셀
            pwds = [p.strip() for p in str((cfg or {}).get("xlsx_passwords") or "").split(",")]
            dec, used = decrypt_xlsx(data, pwds)
            if dec is None:
                if not has_decryptor():
                    return None, ("암호가 걸린 엑셀입니다. 이 설치본은 암호 해제 기능이 없어요 — "
                                  "새 설치파일로 한 번 다시 설치하면 됩니다.")
                if not any(p.strip() for p in pwds):
                    return None, ("암호가 걸린 엑셀이에요. 설정 → '엑셀 암호' 칸에 암호를 넣어두면 "
                                  "다음부터 자동으로 열립니다.\n(여러 개면 쉼표로: 0114,198403!)")
                return None, "암호가 걸린 엑셀인데 설정해둔 암호로는 안 열려요. 암호를 확인해주세요."
            log.info("암호 걸린 엑셀 해제 — %s", name)
            data = dec
        txt = xlsx_to_text(data)
        return (txt, None) if txt else (None, "엑셀은 열었는데 표를 못 찾았어요.")
    if low.endswith((".csv", ".tsv", ".txt", ".md", ".json")):
        try:
            return bytes(data).decode("utf-8-sig", errors="replace"), None
        except Exception:                                    # noqa: BLE001
            return None, "글자 인코딩을 못 읽었어요."
    if low.endswith((".xls",)):
        return None, "옛 엑셀(.xls)은 못 읽어요. .xlsx 로 저장해 보내주세요."
    if low.endswith((".hwp", ".hwpx", ".pdf", ".pptx", ".docx")):
        return None, f"{low.rsplit('.', 1)[-1]} 는 아직 못 읽어요. 표는 엑셀·CSV 로, 아니면 사진으로 보내주세요."
    return None, "엑셀(.xlsx)·CSV·TSV·TXT 파일이나 표 사진을 보내주세요."


def spec_from_text(cfg: dict, text: str, hint: str = "") -> tuple[dict | None, str]:
    """표 텍스트 → (차트규격, 방식). 방식은 사용자에게 알려줄 표시용.

    ① 우리 양식이면 전용 파서로(오프라인·정확·밖으로 안 나감)
    ② 아니면 머리(AI)로  ③ 그것도 안 되면 단순 규칙
    """
    if forms.is_attendance(text):                            # ① 예배출석현황 — 전용 파서
        spec = forms.attendance_spec(text, hint, src=hint)
        if spec:
            return spec, "양식"
    if llm.available(cfg):
        want = f"\n사용자 요청: {hint}\n" if hint else ""
        reply = llm.ask(cfg, f"{SPEC_RULE}\n{want}\n--- 표/데이터 ---\n{text[:40000]}")
        spec = _json_from(reply or "")
        if spec:
            return spec, "AI"
    labels, values = chart.parse_series(text)                # 머리 없을 때: 첫 열=이름, 끝 열=숫자
    if values:
        return ({"type": "line" if len(values) > 6 else "bar",
                 "title": hint or "데이터 차트", "labels": labels, "values": values}, "규칙")
    return None, "규칙"


def spec_from_image(cfg: dict, jpg: bytes, hint: str = "") -> tuple[dict | None, str]:
    """사진(표·보고 캡처) → 차트규격. 사진은 머리가 있어야 읽을 수 있다."""
    if not llm.available(cfg):
        return None, "없음"
    want = f"\n사용자 요청: {hint}\n" if hint else ""
    reply = llm.ask(cfg, f"{SPEC_RULE}\n{want}\n--- 위 사진 속 표를 읽어라 ---", images=[jpg])
    return _json_from(reply or ""), "AI"


def spec_from_messages(cfg: dict, hits: list[dict], question: str) -> tuple[dict | None, str]:
    """텔레그램 검색 결과(여러 글) → 차트규격. 글 속에 흩어진 숫자를 모은다."""
    if not llm.available(cfg):
        return None, "없음"
    body = "\n".join(f"[{h['date']:%m/%d %H:%M}] {h['sender']}: {h['text'][:400]}"
                     for h in hits[:60])
    reply = llm.ask(cfg, f"{SPEC_RULE}\n\n사용자 질문: {question}\n"
                         f"--- 텔레그램에서 찾은 글들 ---\n{body}")
    return _json_from(reply or ""), "AI"
