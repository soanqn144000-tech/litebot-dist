# -*- coding: utf-8 -*-
"""차트 PNG 여러 장 → 발표용 PPT 한 파일.

아델(_build_church_rate_ppt.py)과 같은 방식이다 — 16:9 슬라이드에 차트를 꽉 차게 얹는다.
표지도 pptx 글상자가 아니라 **matplotlib 으로 그린 PNG** 를 쓴다. 그래야
  · 한글 글꼴이 받는 사람 PC 에 없어도 안 깨지고
  · 차트와 색·글꼴이 정확히 같아진다.
"""
from __future__ import annotations

import config

log = config.get_logger()


def _cover(title: str, subtitle: str = "", foot: str = "",
           out_name: str = "ppt_cover.png") -> str | None:
    """표지 한 장을 차트와 같은 규격(다크그린+골드)으로 그린다."""
    import chart                                              # matplotlib 은 여기서만 필요
    chart._apply_font()
    plt = chart.plt
    fig = plt.figure(figsize=(17.8, 10.0), dpi=150)
    fig.patch.set_facecolor(chart.BG)
    fig.text(0.5, 0.60, title, ha="center", va="center", color=chart.GOLD,
             fontsize=54, fontweight="bold", fontproperties=chart._heavy(54))
    if subtitle:
        fig.text(0.5, 0.455, subtitle, ha="center", va="center", color=chart.TEXT_CREAM,
                 fontsize=28, fontweight="bold", fontproperties=chart._heavy(28))
    if foot:
        fig.text(0.5, 0.10, foot, ha="center", va="center", color=chart.GRAY, fontsize=15)
    fig.add_artist(plt.Line2D([0.30, 0.70], [0.525, 0.525], color=chart.GOLD, linewidth=2.4))
    out = config.data_file(out_name)
    # 표지는 bbox_inches="tight" 를 쓰면 안 된다. 글자 크기만큼 잘려 16:9 가 깨지고
    # 제목이 가장자리에 딱 붙는다(2026-08-14 확인). 캔버스를 그대로 저장한다.
    fig.savefig(out, facecolor=chart.BG)
    plt.close(fig)
    return str(out)


def make_deck(images: list, title: str, subtitle: str = "", foot: str = "",
              out_name: str = "report.pptx") -> str | None:
    """PNG 목록 → PPT 파일 경로. 표지 1장 + 차트 n장. 없으면 None.

    out_name 은 반드시 ASCII 로. 한글 파일명은 받는 쪽에서 다운로드가 깨진다(집안 규칙).
    한글이 섞여 오면 여기서 막고 안전한 이름으로 바꾼다 — 슬라이드 안 제목은 한글 그대로다.
    """
    paths = [p for p in images if p]
    if not paths:
        return None
    try:
        out_name.encode("ascii")
    except UnicodeEncodeError:
        log.warning("PPT 파일명에 한글이 있어 바꿉니다 — %s → report.pptx", out_name)
        out_name = "report.pptx"
    try:
        from pptx import Presentation
        from pptx.util import Inches
        from PIL import Image
    except Exception as e:                                     # noqa: BLE001
        log.error("PPT 만들기 실패 — %s", e)
        return None

    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)   # 16:9
    blank = prs.slide_layouts[6]
    SW, SH = prs.slide_width, prs.slide_height

    cover = _cover(title, subtitle, foot)
    for img in ([cover] if cover else []) + paths:
        s = prs.slides.add_slide(blank)
        w, h = Image.open(img).size
        # 레터박스 없이 꽉 차게(넘치는 쪽만 살짝 잘림) — 아델과 같은 방식
        scale = max(SW / w, SH / h)
        nw, nh = int(w * scale), int(h * scale)
        s.shapes.add_picture(str(img), int((SW - nw) / 2), int((SH - nh) / 2), nw, nh)

    out = config.data_file(out_name)
    prs.save(str(out))
    log.info("PPT 저장 — %s (%d장)", out, len(prs.slides))
    return str(out)
