# -*- coding: utf-8 -*-
"""⑯ 학습 — 쓸수록 나아지게. (아델 학습루프의 라이트봇판)

한 번 지적하면 다시는 같은 실수를 안 하게 만드는 것이 목적이다.
아델은 이걸 마크다운 3계층(교정→규칙→용어)으로 하지만, 라이트봇은 교인이 쓰는 것이라
파일 하나(data/learned.json)에 담고 조작은 버튼 한 번으로 끝낸다.

세 가지를 기억한다:
  · 규칙(rules)      — "앞으로 ~해" 라고 명시적으로 시킨 것. 즉시 적용.
  · 교정(corrections) — 지적당한 것. 조용히 쌓이다가 **같은 게 2번** 나오면 규칙으로 올릴지 물어본다.
  · 용어(glossary)   — "A는 B야" 로 알려준 우리 조직 말.

핵심은 inject_text() 다 — llm.ask() 가 밖으로 나가는 유일한 문이라, 거기에 이 글을 앞에 붙인다.
그래서 어떤 기능에서 물어보든(차트·요약·표읽기) 같은 기억이 따라간다.

지어내지 않는다:
  · 사용자가 한 말을 **그대로** 저장한다. 해석하거나 다듬지 않는다.
  · 원인을 모르면 비워둔다. 그럴듯한 이유를 만들지 않는다.
  · 교정 기록은 조용히 한다 — 지적할 때마다 "기록했어요" 하면 성가시다.
  · 지운 적 없는 척하지 않는다 — 승격돼도 교정은 남기고 표시만 바꾼다.

밖에서 쓰는 것:
    learn.inject_text()                  -> str   # 모든 AI 호출 앞에 붙일 기억
    learn.detect(text)                   -> dict | None
    learn.record(text, hit)              -> dict   # {"id","count","propose":bool}
    learn.register_intent(text)          -> str | None   # 명시 등록 의도면 내용
    learn.add_rule(text, src)            -> dict
    learn.term_intent(text)              -> tuple | None
    learn.add_term(term, mean)           -> dict
    learn.promote(cid)                   -> dict | None
    learn.list_text() / learn.delete(n)
"""
from __future__ import annotations

import difflib
import re
from datetime import datetime, timedelta, timezone

import config

KST = timezone(timedelta(hours=9))
FILE = "learned.json"
MAX_RULES = 30                    # 이보다 많으면 프롬프트가 커지고 규칙끼리 부딪힌다
PROMOTE_AT = 2                    # 같은 지적이 이만큼 나오면 규칙으로 올릴지 물어본다
log = config.get_logger()


# ── 지적 감지 ────────────────────────────────────────────────────────────────
# 아델과 같은 신호. '애매하면 기록' 이 원칙이라 폭넓게 잡되, 아래 두 가지로 오탐을 막는다.
SIGNALS = {
    "명시지시": ("앞으로는", "앞으로", "항상", "무조건", "절대", "기억해", "잊지마", "잊지 마"),
    "부정정정": ("아니", "틀렸", "그거 말고", "그게 아니", "왜 이래", "왜이래", "다시 해", "다시해"),
    "불만":     ("안 보여", "안보여", "깨졌", "겹쳐", "잘렸", "지저분", "이상해", "너무 작", "너무 얇",
                 "너무 크", "안 맞", "안맞", "이상한데"),
}
# 일 시키는 말 — 이게 보이면 지적이 아니라 업무 지시다.
WORK_VERBS = ("만들어", "그려", "뽑아", "정리해", "작성해", "보내", "올려", "찾아", "검색",
              "이미지로", "차트로", "표로", "피피티", "ppt", "요약해", "추가해", "등록해",
              "잡아줘", "알려줘", "확인해", "보여줘")
MAX_LEN = 120                     # 진짜 지적은 짧다. 길면 업무 설명일 확률이 높다.


def _now() -> str:
    return datetime.now(KST).strftime("%Y-%m-%d %H:%M")


def _load() -> dict:
    d = config.read_json(FILE, {})
    for k in ("rules", "corrections", "glossary"):
        d.setdefault(k, [])
    return d


def _save(d: dict) -> None:
    config.write_json(FILE, d)


def _norm(s: str) -> str:
    return re.sub(r"\s+", "", str(s or "")).lower()


def _similar(a: str, b: str, threshold: float = 0.6) -> bool:
    return difflib.SequenceMatcher(None, _norm(a), _norm(b)).ratio() >= threshold


def detect(text: str) -> dict | None:
    """이 말이 지적인가. 맞으면 {"kind","signal"}, 아니면 None."""
    t = (text or "").strip()
    if not t or len(_norm(t)) > MAX_LEN:
        return None
    low = t.lower()
    if any(v in low for v in WORK_VERBS):                     # 일 시키는 말은 지적이 아니다
        return None
    for kind, words in SIGNALS.items():
        for w in words:
            if w in t:
                return {"kind": kind, "signal": w}
    return None


def record(text: str, hit: dict) -> dict:
    """지적을 남긴다. 비슷한 게 이미 있으면 새로 만들지 않고 횟수만 올린다.

    조용히 한다 — 호출자는 propose 가 True 일 때만 사용자에게 말을 건다.
    """
    d = _load()
    for c in d["corrections"]:
        if c.get("promoted"):
            continue
        if _similar(c.get("quote", ""), text):
            c["count"] = int(c.get("count", 1)) + 1
            c["last"] = _now()
            _save(d)
            return {"id": c["id"], "count": c["count"],
                    "propose": c["count"] == PROMOTE_AT, "quote": c["quote"]}
    cid = f"C-{len(d['corrections']) + 1}"
    d["corrections"].append({"id": cid, "quote": text.strip(), "kind": hit.get("kind", ""),
                             "count": 1, "first": _now(), "last": _now(), "promoted": False})
    _save(d)
    return {"id": cid, "count": 1, "propose": False, "quote": text.strip()}


# ── 명시 등록 ────────────────────────────────────────────────────────────────
_REG = re.compile(r"^\s*(?:이건\s*)?(?:규칙\s*(?:추가|등록)|룰\s*(?:추가|등록)|기억해\s*줘?|외워\s*둬?)\s*[:：]?\s*(.+)$")
_REG_TAIL = re.compile(r"^(.+?)\s*(?:규칙\s*(?:추가|등록)|기억해\s*줘?|외워\s*둬?)\s*[.!~]*$")


def register_intent(text: str) -> str | None:
    """'기억해 / 규칙 추가' 처럼 **대놓고** 시킬 때만 규칙으로 본다. 추측해서 만들지 않는다."""
    t = (text or "").strip()
    m = _REG.match(t)
    if m and m.group(1).strip():
        return m.group(1).strip()
    m = _REG_TAIL.match(t)
    if m and m.group(1).strip():
        return m.group(1).strip()
    return None


def add_rule(text: str, src: str = "직접") -> dict:
    """규칙 추가. 이미 같은 게 있으면 새로 안 만든다."""
    d = _load()
    for r in d["rules"]:
        if _similar(r.get("text", ""), text, 0.8):
            return {"id": r["id"], "text": r["text"], "dup": True,
                    "total": len(d["rules"]), "over": False}
    rid = f"R-{len(d['rules']) + 1}"
    d["rules"].append({"id": rid, "text": text.strip(), "when": _now(), "src": src})
    _save(d)
    return {"id": rid, "text": text.strip(), "dup": False,
            "total": len(d["rules"]), "over": len(d["rules"]) > MAX_RULES}


# ── 용어 ────────────────────────────────────────────────────────────────────
_TERM = re.compile(r"^\s*([^\s은는이가]{1,20})\s*(?:은|는|이란|란)\s*(.{2,80}?)\s*(?:이야|야|입니다|이다|다)\s*[.!~]*$")


def term_intent(text: str) -> tuple[str, str] | None:
    """'네생물은 자문·장년·부녀·청년회야' 같은 말에서 (용어, 뜻)."""
    m = _TERM.match((text or "").strip())
    if not m:
        return None
    term, mean = m.group(1).strip(), m.group(2).strip()
    if len(_norm(term)) < 2 or _norm(term) == _norm(mean):
        return None
    return term, mean


def add_term(term: str, mean: str) -> dict:
    d = _load()
    for g in d["glossary"]:
        if _norm(g.get("term")) == _norm(term):
            g["mean"], g["when"] = mean, _now()               # 뜻이 바뀌면 갱신
            _save(d)
            return {"term": term, "mean": mean, "updated": True}
    d["glossary"].append({"term": term, "mean": mean, "when": _now()})
    _save(d)
    return {"term": term, "mean": mean, "updated": False}


# ── 승격 ────────────────────────────────────────────────────────────────────
def promote(cid: str) -> dict | None:
    """교정 → 규칙. 교정은 지우지 않고 표시만 바꾼다(무슨 일이 있었는지 남겨야 한다)."""
    d = _load()
    for c in d["corrections"]:
        if c["id"] == cid and not c.get("promoted"):
            r = add_rule(c["quote"], src=f"지적 {c['count']}회")
            d2 = _load()                                       # add_rule 이 이미 저장했으므로 다시 읽는다
            for c2 in d2["corrections"]:
                if c2["id"] == cid:
                    c2["promoted"] = True
                    c2["rule_id"] = r["id"]
            _save(d2)
            return r
    return None


def dismiss(cid: str) -> bool:
    """규칙으로 안 만들기. 다시 안 묻도록 표시만 하고 기록은 남긴다."""
    d = _load()
    for c in d["corrections"]:
        if c["id"] == cid:
            c["promoted"] = True
            c["rule_id"] = None
            _save(d)
            return True
    return False


# ── 주입 ────────────────────────────────────────────────────────────────────
def inject_text() -> str:
    """AI 에게 매번 붙여 보낼 기억. 없으면 빈 문자열(쓸데없이 토큰 쓰지 않게)."""
    d = _load()
    parts = []
    if d["rules"]:
        parts.append("[꼭 지킬 것]\n" + "\n".join(f"- {r['text']}" for r in d["rules"][-MAX_RULES:]))
    if d["glossary"]:
        parts.append("[우리 말]\n" + "\n".join(f"- {g['term']}: {g['mean']}" for g in d["glossary"]))
    return ("\n\n".join(parts) + "\n\n") if parts else ""


# ── 보기·지우기 ──────────────────────────────────────────────────────────────
def list_text() -> str:
    d = _load()
    out = []
    if d["rules"]:
        out.append("📌 꼭 지킬 것")
        for i, r in enumerate(d["rules"], 1):
            out.append(f"{i}. {r['text']}   ({r['when']}, {r.get('src', '')})")
    if d["glossary"]:
        out.append("\n📖 우리 말")
        for g in d["glossary"]:
            out.append(f"· {g['term']} = {g['mean']}")
    pend = [c for c in d["corrections"] if not c.get("promoted")]
    if pend:
        out.append("\n✏️ 아직 규칙은 아닌 지적")
        for c in pend:
            out.append(f"· {c['quote']}  ({c['count']}회)")
    if not out:
        return "아직 기억한 게 없어요.\n\n「앞으로 차트에 숫자도 같이 넣어줘 기억해」 처럼 말하면 기억합니다."
    if len(d["rules"]) > MAX_RULES:
        out.append(f"\n⚠️ 규칙이 {len(d['rules'])}개예요. {MAX_RULES}개가 넘으면 서로 부딪힐 수 있어요 — 안 쓰는 건 지워주세요.")
    return "\n".join(out)


def delete(n: int) -> str | None:
    """보이는 번호(1부터)로 규칙 삭제. 지운 내용을 돌려준다."""
    d = _load()
    if not (1 <= n <= len(d["rules"])):
        return None
    gone = d["rules"].pop(n - 1)
    _save(d)
    return gone["text"]
