# -*- coding: utf-8 -*-
"""⑬ 우리 양식 전용 파서 — 매주 같은 형식으로 오는 보고서를 규칙만으로(AI 없이) 정확히 읽는다.

AI 로 아무 표나 읽는 건 편하지만 ⓐ 성도 데이터가 밖으로 나가고 ⓑ 무료 한도에 막힌다.
강동 보고서는 형식이 고정이라, 그 형식은 여기서 오프라인으로 확실하게 뽑는다.

지금 지원: 예배출석현황(등록구분별) — '부서별 출석률' / '부서별 출석인원' 차트.
"""
from __future__ import annotations

import re

DEPTS = ("교역자", "장로회", "자문회", "장년회", "부녀회", "청년회")
SECTIONS = ("총회등록", "교회등록", "입교")


def _cells(line: str) -> list[str]:
    return [c.strip() for c in line.split("\t")]


def _num(s: str):
    s = (s or "").replace(",", "").strip()
    try:
        return float(s)
    except ValueError:
        return None


def is_attendance(text: str) -> bool:
    head = text[:400]
    return ("출결 현황" in head or "출석현황" in head or "예배 출결" in head) \
        and any(d in text for d in DEPTS)


def parse_attendance(text: str) -> dict | None:
    """예배출석현황 → 등록구분별·부서별 {재적, 출석, 출석률}. 못 읽으면 None.

    각 데이터 행의 신호:
      · 부서명(교역자…청년회 또는 '계')이 앞쪽 칸에 있다
      · 0<x<1 인 소수 하나 = 출석률
      · 그 소수 바로 앞의 정수 = 출석 계, 행의 첫 정수 = 현 재적수
    """
    section = None
    rows: list[dict] = []
    for line in text.splitlines():
        cs = _cells(line)
        joined = "".join(cs)
        for s in SECTIONS:                                   # 등록구분은 줄 맨 앞에 한 번 나온다
            if joined.startswith(s):
                section = s
                break
        dept = next((d for d in DEPTS if d in cs[:3]), None)
        is_total = cs[:2].count("계") > 0 or (cs and cs[0].endswith("계"))
        if not dept and not is_total:
            continue
        nums = [(_num(c), i) for i, c in enumerate(cs)]
        rate = next((v for v, _ in nums if v is not None and 0 < v < 1), None)
        ints = [v for v, _ in nums if v is not None and v >= 1]
        if rate is None or not ints:
            continue
        rows.append({"section": section, "dept": dept or "계",
                     "재적": ints[0], "출석률": round(rate * 100, 1),
                     "출석": _attend_before_rate(cs, rate)})
    if not rows:
        return None
    return {"rows": rows}


def _attend_before_rate(cells: list[str], rate: float) -> float | None:
    """출석률 칸 바로 왼쪽의 정수 = 출석 계."""
    idx = None
    for i, c in enumerate(cells):
        v = _num(c)
        if v is not None and abs(v - rate) < 1e-9:
            idx = i
            break
    if idx is None:
        return None
    for j in range(idx - 1, -1, -1):
        v = _num(cells[j])
        if v is not None and v >= 1:
            return v
    return None


def attendance_spec(text: str, want: str = "") -> dict | None:
    """출석현황 → 차트 규격. 기본은 총회등록 부서별 출석률(요청에 '인원' 있으면 출석인원)."""
    data = parse_attendance(text)
    if not data:
        return None
    by_person = "인원" in want or "명" in want or "출석수" in want
    section = "총회등록"
    for s in SECTIONS:                                       # 요청에 섹션명이 있으면 그걸로
        if s in want:
            section = s
            break
    labels, values, seen = [], [], set()
    for r in data["rows"]:
        if r["section"] != section or r["dept"] not in DEPTS or r["dept"] in seen:
            continue                                         # 부서 첫 등장만(시트2 중복 방지)
        v = r["출석"] if by_person else r["출석률"]
        if v is None:
            continue
        seen.add(r["dept"])
        labels.append(r["dept"])
        values.append(v)
    if len(values) < 2:
        return None
    return {"type": "bar", "title": f"{section} 부서별 " + ("출석 인원" if by_person else "출석률"),
            "labels": labels, "values": values, "unit": "명" if by_person else "%"}
