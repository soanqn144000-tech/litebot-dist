# -*- coding: utf-8 -*-
"""⑬ 우리 양식 전용 파서 — 매주 같은 형식으로 오는 보고서를 규칙만으로(AI 없이) 정확히 읽는다.

AI 로 아무 표나 읽는 건 편하지만 ⓐ 성도 데이터가 밖으로 나가고 ⓑ 무료 한도에 막힌다.
강동 보고서는 형식이 고정이라, 그 형식은 여기서 오프라인으로 확실하게 뽑는다.

예배출석현황 = 아델(scripts/parse_church_sunday.py)과 똑같은 열 매핑·검증을 쓴다.
'총계' 행에서 출석률(0~1 소수)이 있는 열 위치(ri)로 양식 버전을 판별한다:
  대면+줌+인시센+대체+심방+영상 == 전체출석,  결석 = 출결재적 - 전체출석
"""
from __future__ import annotations

import re

DEPTS = ("교역자", "장로회", "자문회", "장년회", "부녀회", "청년회")
# 예배 형태(차트에 나올 순서). 심방·영상은 구양식엔 없어 None(미집계) → 차트에서 뺀다.
KINDS = ("대면", "줌", "영상", "심방", "대체", "인시센", "결석")


def _cells(line: str) -> list[str]:
    return [c.strip() for c in line.split("\t")]


def _num(s):
    if isinstance(s, (int, float)):
        return float(s)
    s = str(s or "").replace(",", "").strip()
    try:
        return float(s)
    except ValueError:
        return None


def _n(v) -> float:
    return v if isinstance(v, (int, float)) else 0.0


def is_attendance(text: str) -> bool:
    head = text[:400]
    return ("출결 현황" in head or "출석현황" in head or "예배 출결" in head) \
        and any(d in text for d in DEPTS)


FN_DATE = re.compile(r"\((\d{4})\)\s*\.\s*(\d{1,2})\s*\.\s*(\d{1,2})")


def file_date(name: str):
    """파일명 '…(2026).7.19.' → (연,월,일) 또는 None."""
    m = FN_DATE.search(name or "")
    if not m:
        return None
    try:
        return (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def is_church_total(name: str) -> bool:
    """교회 전체 예배출석현황인가(부서별·새신자 파일 제외)."""
    n = (name or "")
    if "예배출석현황" not in n.replace(" ", ""):
        return False
    if any(k in n for k in ("새신자", "청년회", "부녀회", "장년회", "자문회",
                            "유년회", "학생회", "국제부", "장로회", "교역자")):
        return False
    # 예전 파일은 이름이 '요한강동-예배출석현황…' 이라 '강동교회' 가 안 들어간다.
    # 그것만 보면 3/29 같은 옛 주가 통째로 빠진다(2026-08-13 확인) → '부서 이름이 없으면 교회 전체'.
    return True


def find_date(text: str, fallback: str = "") -> str:
    """제목의 '신 43(2026). 7. 19.(일)' 또는 파일명에서 예배일. 못 찾으면 fallback."""
    m = re.search(r"\((\d{4})\)\s*\.\s*(\d{1,2})\s*\.\s*(\d{1,2})", text[:300])
    if not m and fallback:
        m = re.search(r"\((\d{4})\)\.(\d{1,2})\.(\d{1,2})", fallback)
    if m:
        return f"{int(m.group(2))}/{int(m.group(3))}"
    return ""


def parse_total(text: str) -> dict | None:
    """'총계' 행 → 예배 형태별 집계(교회 전체). 아델과 동일. 검증 실패 시 None."""
    row = None
    for line in text.splitlines():
        cs = _cells(line)
        if cs and str(cs[0]).replace(" ", "") == "총계":
            row = [_num(c) for c in cs]
            break
    if row is None:
        return None
    # 양식이 세 번 바뀌었다. 열 자리를 엑셀 머리글로 직접 확인한 결과(2026-08-13):
    #   구양식(3/29~4/12)  G대면 H줌 I인시센 J+K대체 → 영상예배 칸 자체가 없음
    #   전환기(4/26~7/1)   J대면계 M줌계 N인시센 R대체계 → 여기도 영상예배 없음
    #   신양식(7/5~)       J대면계 M온라인계 [N+O]영상예배 P심방 Q(또는 V)대체
    #                      └ 영상예배는 N(인시센)·O(그외) 두 칸으로 쪼개져 있다
    # 예전엔 O(그외)를 '영상'이라고 불러 차트에 잘못 그렸다 → 영상예배 = N+O 로 바로잡음.
    ri = next((i for i, c in enumerate(row) if isinstance(c, float) and 0 < c < 1), None)
    if ri == 12:        # 구 요한강동 (3/29~4/12)
        대면, 줌, 인시센, 대체 = _n(row[6]), _n(row[7]), _n(row[8]), _n(row[9]) + _n(row[10])
        심방 = 영상 = None
    elif ri == 19:      # 전환기 (4/26~7/1)
        대면, 줌, 인시센, 대체 = _n(row[9]), _n(row[12]), _n(row[13]), _n(row[17])
        심방 = 영상 = None
    elif ri in (23, 18):    # 신양식 (23=7/5 / 18=7/12~ 대체예배 칸이 하나로 줄어듦)
        대면, 줌, 인시센 = _n(row[9]), _n(row[12]), _n(row[13])
        대체 = _n(row[21]) if ri == 23 else _n(row[16])
        심방 = _n(row[15])
        영상 = 인시센 + _n(row[14])                          # 영상예배 = 인시센 + 그외
    else:
        return None                                          # 모르는 양식 → AI 나 단순규칙에 넘긴다
    전체출석 = _n(row[ri - 1])
    재적 = _n(row[5])
    결석 = 재적 - 전체출석
    # 교차검증. 신양식은 인시센이 영상예배 안에 들어 있으므로 합에 두 번 넣지 않는다.
    구성 = (대면 + 줌 + 대체 + _n(심방) + (영상 if 영상 is not None else 인시센))
    if 재적 <= 0 or abs(전체출석 - 구성) > 2:                  # 항목 합이 전체출석과 안 맞으면 버린다
        return None
    return {"출결재적": 재적, "전체출석": 전체출석, "대면": 대면, "줌": 줌, "영상": 영상,
            "심방": 심방, "대체": 대체, "인시센": 인시센, "결석": 결석}



def _cols(row: list, ri: int):
    """양식 판별(ri) 에 따라 한 행에서 예배 형태별 값을 뽑는다. parse_total 과 같은 자리.
    돌려주는 것: (대면, 줌, 인시센, 대체, 심방, 영상) — 없는 칸은 None."""
    if ri == 12:        # 구 요한강동 (3/29~4/12)
        return _n(row[6]), _n(row[7]), _n(row[8]), _n(row[9]) + _n(row[10]), None, None
    if ri == 19:        # 전환기 (4/26~7/1)
        return _n(row[9]), _n(row[12]), _n(row[13]), _n(row[17]), None, None
    if ri in (23, 18):  # 신양식 (23=7/5 / 18=7/12~)
        인시센 = _n(row[13])
        대체 = _n(row[21]) if ri == 23 else _n(row[16])
        return (_n(row[9]), _n(row[12]), 인시센, 대체, _n(row[15]),
                인시센 + _n(row[14]))                          # 영상예배 = 인시센 + 그외
    return None


NET4 = ("자문회", "장년회", "부녀회", "청년회")                   # 네생물(자문·장년·부녀·청년)


def parse_departments(text: str) -> dict | None:
    """부서별 집계. {부서: {지표: 값}}. 못 읽거나 검증 실패하면 None.

    한 파일 안에 같은 부서가 여러 번 나온다(총회등록·교회등록·입교 블록). 전부 더한다.
    소계 행('계'·'총 계'·'총교등 계')은 더하면 두 배가 되므로 건너뛴다.
    검증: 부서 합 == '총계' 행. 안 맞으면 통째로 버린다(맞춰 넣지 않는다).
    """
    # 파일에 시트가 여럿이면 첫 시트(등록구분별 교회 전체)만 본다.
    # 뒤 시트에도 같은 부서명이 나와서 그냥 훑으면 남의 표 숫자까지 더해진다(2026-08-13 확인).
    lines = []
    for line in text.splitlines():
        if line.startswith("# 시트:"):
            if lines:
                break
            continue
        lines.append(line)
    total_row = None
    for line in lines:
        cs = _cells(line)
        if cs and str(cs[0]).replace(" ", "") == "총계":
            total_row = [_num(c) for c in cs]
            break
    if total_row is None:
        return None
    ri = next((i for i, c in enumerate(total_row) if isinstance(c, float) and 0 < c < 1), None)
    if ri is None or _cols(total_row, ri) is None:
        return None

    out: dict = {}
    for line in lines:
        cs = _cells(line)
        # 부서명은 둘째 칸(등록구분이 첫 칸). 등록구분만 있는 줄엔 부서명이 첫 칸에 올 때도 있다.
        name = next((c for c in cs[:2] if c.replace(" ", "") in DEPTS), "")
        if not name:
            continue
        name = name.replace(" ", "")
        row = [_num(c) for c in cs]
        if len(row) <= ri or not isinstance(row[ri], float):
            continue                                          # 출석률이 그 자리에 없으면 데이터 행이 아니다
        got = _cols(row, ri)
        if got is None:
            continue
        대면, 줌, 인시센, 대체, 심방, 영상 = got
        d = out.setdefault(name, {"출결재적": 0.0, "전체출석": 0.0, "대면": 0.0, "줌": 0.0,
                                  "대체": 0.0, "인시센": 0.0, "심방": None, "영상": None})
        d["출결재적"] += _n(row[5])
        d["전체출석"] += _n(row[ri - 1])
        d["대면"] += 대면
        d["줌"] += 줌
        d["인시센"] += 인시센
        d["대체"] += 대체
        for key, v in (("심방", 심방), ("영상", 영상)):
            if v is not None:
                d[key] = _n(d[key]) + v
    if not out:
        return None
    for d in out.values():
        d["결석"] = d["출결재적"] - d["전체출석"]

    # 교차검증 — 부서 합이 '총계' 행과 맞아야 한다
    tot = parse_total(text)
    if not tot:
        return None
    for key in ("출결재적", "전체출석", "대면", "줌"):
        if abs(sum(d[key] for d in out.values()) - tot[key]) > 2:
            return None
    return out

def attendance_spec(text: str, want: str = "", src: str = "") -> dict | None:
    """출석현황 → 예배 형태별 차트. 기본=인원, 요청에 '률/율/%' 있으면 출결재적 대비 비율."""
    d = parse_total(text)
    if not d:
        return None
    day = find_date(text, src)
    as_rate = any(k in want for k in ("률", "율", "%", "퍼센트"))
    재적 = d["출결재적"]

    order = [("대면", d["대면"]), ("줌", d["줌"]), ("영상", d["영상"]),
             ("심방", d["심방"]), ("대체", d["대체"]), ("인시센", d["인시센"]),
             ("결석", d["결석"])]
    labels, values = [], []
    for name, v in order:
        if v is None:                                        # 구양식 미집계 항목은 뺀다
            continue
        if not as_rate and v == 0:                           # 0 인 항목은 인원 차트에서 생략
            continue
        labels.append(name)
        values.append(round(v / 재적 * 100, 1) if as_rate else v)

    title = f"{day + ' ' if day else ''}예배 출결 " + ("비율" if as_rate else "인원")
    foot = (f"전체출석 {d['전체출석']:.0f} / 출결재적 {재적:.0f}"
            f" (전체출석률 {d['전체출석'] / 재적 * 100:.1f}%)")
    return {"type": "bar", "title": title, "labels": labels, "values": values,
            "unit": "%" if as_rate else "명", "footer": foot}
