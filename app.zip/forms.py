# -*- coding: utf-8 -*-
"""⑬ 우리 양식 전용 파서 — 매주 같은 형식으로 오는 보고서를 규칙만으로(AI 없이) 정확히 읽는다.

AI 로 아무 표나 읽는 건 편하지만 ⓐ 성도 데이터가 밖으로 나가고 ⓑ 무료 한도에 막힌다.
강동 보고서는 형식이 고정이라, 그 형식은 여기서 오프라인으로 확실하게 뽑는다.

예배출석현황 = 아델(scripts/parse_church_sunday.py)과 똑같은 열 매핑·검증을 쓴다.
'총계' 행에서 출석률(0~1 소수)이 있는 열 위치(ri)로 양식 버전을 판별한다:
  대면+줌+인시센+대체+심방+영상 == 전체출석,  결석 = 출결재적 - 전체출석
"""
from __future__ import annotations

import re

DEPTS = ("교역자", "장로회", "자문회", "장년회", "부녀회", "청년회")
# 예배 형태(차트에 나올 순서). 심방·영상은 구양식엔 없어 None(미집계) → 차트에서 뺀다.
KINDS = ("대면", "줌", "영상", "심방", "대체", "인시센", "결석")


def _cells(line: str) -> list[str]:
    return [c.strip() for c in line.split("\t")]


def _num(s):
    if isinstance(s, (int, float)):
        return float(s)
    s = str(s or "").replace(",", "").strip()
    try:
        return float(s)
    except ValueError:
        return None


def _n(v) -> float:
    return v if isinstance(v, (int, float)) else 0.0


def is_attendance(text: str) -> bool:
    head = text[:400]
    return ("출결 현황" in head or "출석현황" in head or "예배 출결" in head) \
        and any(d in text for d in DEPTS)


FN_DATE = re.compile(r"\((\d{4})\)\s*\.\s*(\d{1,2})\s*\.\s*(\d{1,2})")


def file_date(name: str):
    """파일명 '…(2026).7.19.' → (연,월,일) 또는 None."""
    m = FN_DATE.search(name or "")
    if not m:
        return None
    try:
        return (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def is_church_total(name: str) -> bool:
    """교회 전체 예배출석현황인가(부서별·새신자 파일 제외)."""
    n = (name or "")
    if "예배출석현황" not in n.replace(" ", ""):
        return False
    if any(k in n for k in ("새신자", "청년회", "부녀회", "장년회", "자문회")):
        return False
    return "강동교회" in n


def find_date(text: str, fallback: str = "") -> str:
    """제목의 '신 43(2026). 7. 19.(일)' 또는 파일명에서 예배일. 못 찾으면 fallback."""
    m = re.search(r"\((\d{4})\)\s*\.\s*(\d{1,2})\s*\.\s*(\d{1,2})", text[:300])
    if not m and fallback:
        m = re.search(r"\((\d{4})\)\.(\d{1,2})\.(\d{1,2})", fallback)
    if m:
        return f"{int(m.group(2))}/{int(m.group(3))}"
    return ""


def parse_total(text: str) -> dict | None:
    """'총계' 행 → 예배 형태별 집계(교회 전체). 아델과 동일. 검증 실패 시 None."""
    row = None
    for line in text.splitlines():
        cs = _cells(line)
        if cs and str(cs[0]).replace(" ", "") == "총계":
            row = [_num(c) for c in cs]
            break
    if row is None:
        return None
    ri = next((i for i, c in enumerate(row) if isinstance(c, float) and 0 < c < 1), None)
    if ri == 12:        # 구 요한강동 (3/29~4/12)
        대면, 줌, 인시센, 대체 = _n(row[6]), _n(row[7]), _n(row[8]), _n(row[9]) + _n(row[10])
        심방 = 영상 = None
    elif ri == 19:      # 전환기 (4/26~7/1)
        대면, 줌, 인시센, 대체 = _n(row[9]), _n(row[12]), _n(row[13]), _n(row[17])
        심방 = 영상 = None
    elif ri == 23:      # 신양식 (7/5)
        대면, 줌, 인시센, 대체 = _n(row[9]), _n(row[12]), _n(row[13]), _n(row[21])
        심방, 영상 = _n(row[15]), _n(row[14])
    elif ri == 18:      # 신양식2 (7/12~)
        대면, 줌, 인시센, 대체 = _n(row[9]), _n(row[12]), _n(row[13]), _n(row[16])
        심방, 영상 = _n(row[15]), _n(row[14])
    else:
        return None                                          # 모르는 양식 → AI 나 단순규칙에 넘긴다
    전체출석 = _n(row[ri - 1])
    재적 = _n(row[5])
    결석 = 재적 - 전체출석
    기타 = 전체출석 - (대면 + 줌 + 인시센 + 대체 + _n(심방) + _n(영상))
    if 재적 <= 0 or abs(기타) > 2:                            # 검증: 항목 합이 전체출석과 안 맞으면 버린다
        return None
    return {"출결재적": 재적, "전체출석": 전체출석, "대면": 대면, "줌": 줌, "영상": 영상,
            "심방": 심방, "대체": 대체, "인시센": 인시센, "결석": 결석}


def attendance_spec(text: str, want: str = "", src: str = "") -> dict | None:
    """출석현황 → 예배 형태별 차트. 기본=인원, 요청에 '률/율/%' 있으면 출결재적 대비 비율."""
    d = parse_total(text)
    if not d:
        return None
    day = find_date(text, src)
    as_rate = any(k in want for k in ("률", "율", "%", "퍼센트"))
    재적 = d["출결재적"]

    order = [("대면", d["대면"]), ("줌", d["줌"]), ("영상", d["영상"]),
             ("심방", d["심방"]), ("대체", d["대체"]), ("인시센", d["인시센"]),
             ("결석", d["결석"])]
    labels, values = [], []
    for name, v in order:
        if v is None:                                        # 구양식 미집계 항목은 뺀다
            continue
        if not as_rate and v == 0:                           # 0 인 항목은 인원 차트에서 생략
            continue
        labels.append(name)
        values.append(round(v / 재적 * 100, 1) if as_rate else v)

    title = f"{day + ' ' if day else ''}예배 출결 " + ("비율" if as_rate else "인원")
    foot = (f"전체출석 {d['전체출석']:.0f} / 출결재적 {재적:.0f}"
            f" (전체출석률 {d['전체출석'] / 재적 * 100:.1f}%)")
    return {"type": "bar", "title": title, "labels": labels, "values": values,
            "unit": "%" if as_rate else "명", "footer": foot}
