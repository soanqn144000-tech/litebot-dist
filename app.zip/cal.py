# -*- coding: utf-8 -*-
"""② 일정 추가·브리핑 — 로컬 캘린더(data/calendar.json).

iCloud(CalDAV)는 config에 자격증명 있을 때만 선택적으로 함께 조회.
명령 형식 — 말로 하셔도 됩니다:
  /cal 추가 7/25 14:00 부과장 회의
  /cal 추가 3040모임 금주 목요일 12:30 장소는 교회
  /cal              → 오늘
  /cal 주간          → 이번 주(월~일)
  /cal 삭제 3
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

import config

CAL = "calendar.json"


def _load() -> list[dict]:
    return config.read_json(CAL, [])


def _save(items: list[dict]) -> None:
    config.write_json(CAL, items)


def _parse_date(tok: str) -> str | None:
    """'7/25' '2026-07-25' '7.25' '오늘' '내일' → YYYY-MM-DD."""
    today = date.today()
    if tok in ("오늘", "today"):
        return today.isoformat()
    if tok in ("내일", "tomorrow"):
        return (today + timedelta(days=1)).isoformat()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", tok)
    if m:
        y, mo, d = map(int, m.groups())
        try: return date(y, mo, d).isoformat()
        except ValueError: return None
    m = re.fullmatch(r"(\d{1,2})[/.](\d{1,2})", tok)
    if m:
        mo, d = map(int, m.groups())
        y = today.year
        try:
            dd = date(y, mo, d)
            if dd < today - timedelta(days=180):   # 지난 달 크게 지났으면 내년
                dd = date(y + 1, mo, d)
            return dd.isoformat()
        except ValueError:
            return None
    return None


# ── 말로 쓴 날짜·시간 읽기 ────────────────────────────────────────────────────
# "/cal 추가 7/25 14:00 제목" 처럼 또박또박 쓰는 사람은 없다. 실제로는
# "3040모임 금주 목요일 12:30 장소는 교회. 일정 등록" 처럼 온다(2026-08-17).
# 그래서 문장 어디에 있든 날짜·시간을 찾아내고, 남는 말을 제목으로 삼는다.
_WD = "월화수목금토일"
_THIS_WEEK = ("이번주", "이번 주", "금주", "이주", "요번주", "요번 주")
_NEXT_WEEK = ("다음주", "다음 주", "차주", "담주", "내주")

_RE_YMD   = re.compile(r"(20\d{2})[-./](\d{1,2})[-./](\d{1,2})")
_RE_MD    = re.compile(r"(?<!\d)(\d{1,2})\s*[/.]\s*(\d{1,2})(?!\d)")
_RE_MD_KO = re.compile(r"(\d{1,2})\s*월\s*(\d{1,2})\s*일")
_RE_D_KO  = re.compile(r"(?<!\d)(\d{1,2})\s*일(?!\s*(?:간|째|동안))")
_RE_WD    = re.compile(r"(이번\s*주|금주|이주|요번\s*주|다음\s*주|차주|담주|내주)?\s*([월화수목금토일])\s*요일")
_RE_HM    = re.compile(r"(?<!\d)(\d{1,2})\s*:\s*(\d{2})(?!\d)")
_RE_H_KO  = re.compile(r"(오전|오후|아침|저녁|밤)?\s*(\d{1,2})\s*시\s*(?:(\d{1,2})\s*분|(반))?")

# 제목에서 걷어낼 말 — 명령이지 일 이름이 아니다.
_NOISE = re.compile(r"(일정\s*등록해?줘?|일정\s*등록|일정\s*잡아\s*줘?|일정\s*추가해?줘?|일정\s*추가"
                    r"|캘린더에?\s*(추가|등록)해?줘?|스케줄\s*(추가|등록)해?줘?"
                    r"|등록해?\s*줘?|추가해?\s*줘?|잡아\s*줘?|넣어\s*줘?|해\s*줘?"
                    r"|일정|캘린더|스케줄|약속)")


def _cut(text: str, m) -> str:
    return text[:m.start()] + " " + text[m.end():]


def parse_event(text: str) -> tuple[str | None, str, str, str]:
    """말로 쓴 한 줄 → (날짜, 시각, 제목, 못 읽은 이유).

    날짜를 못 찾으면 (None, "", "", 이유). 지어내지 않는다 — 오늘로 때려넣지 않는다.
    """
    t = " " + (text or "").strip() + " "
    today = date.today()
    d = None

    # 1) 딱 떨어지는 날짜부터 (2026-07-25 / 7/25 / 7월 25일)
    for rx, build in (
        (_RE_YMD, lambda g: (int(g[0]), int(g[1]), int(g[2]))),
        (_RE_MD_KO, lambda g: (today.year, int(g[0]), int(g[1]))),
        (_RE_MD, lambda g: (today.year, int(g[0]), int(g[1]))),
    ):
        m = rx.search(t)
        if m:
            y, mo, dd = build(m.groups())
            try:
                got = date(y, mo, dd)
            except ValueError:
                return None, "", "", f"그런 날짜가 없어요: '{m.group(0).strip()}'"
            if rx is not _RE_YMD and got < today - timedelta(days=180):
                got = date(y + 1, mo, dd)                     # 한참 지난 날짜면 내년으로
            d, t = got, _cut(t, m)
            break

    # 2) 요일 (금주 목요일 / 다음주 화요일 / 목요일)
    if d is None:
        m = _RE_WD.search(t)
        if m:
            mod = (m.group(1) or "").replace(" ", "")
            want = _WD.index(m.group(2))
            monday = today - timedelta(days=today.weekday())
            if mod in _NEXT_WEEK:
                got = monday + timedelta(days=7 + want)
            elif mod in _THIS_WEEK:
                got = monday + timedelta(days=want)
            else:                                            # 그냥 '목요일' = 다가오는 그 요일(오늘 포함)
                got = today + timedelta(days=(want - today.weekday()) % 7)
            d, t = got, _cut(t, m)

    # 3) 오늘·내일·모레
    if d is None:
        for word, off in (("오늘", 0), ("금일", 0), ("내일", 1), ("명일", 1), ("모레", 2), ("글피", 3)):
            i = t.find(word)
            if i >= 0:
                d = today + timedelta(days=off)
                t = t[:i] + " " + t[i + len(word):]
                break

    # 4) 'N일' 만 준 경우 — 이번 달, 지났으면 다음 달
    if d is None:
        m = _RE_D_KO.search(t)
        if m:
            dd = int(m.group(1))
            try:
                got = today.replace(day=dd)
            except ValueError:
                return None, "", "", f"그런 날짜가 없어요: '{m.group(0).strip()}'"
            if got < today:
                nxt = (today.replace(day=1) + timedelta(days=32)).replace(day=1)
                try:
                    got = nxt.replace(day=dd)
                except ValueError:
                    return None, "", "", f"다음 달엔 {dd}일이 없어요."
            d, t = got, _cut(t, m)

    if d is None:
        return None, "", "", "날짜를 못 읽었어요 (예: 내일 / 금주 목요일 / 7월 25일 / 7/25)"

    # 5) 시각 — 12:30 · 오후 2시 · 2시 반 · 14시
    tm = ""
    m = _RE_HM.search(t)
    if m:
        h, mi = int(m.group(1)), int(m.group(2))
        if h < 24 and mi < 60:
            tm, t = f"{h:02d}:{mi:02d}", _cut(t, m)
    if not tm:
        m = _RE_H_KO.search(t)
        if m:
            ampm, h = m.group(1), int(m.group(2))
            mi = int(m.group(3)) if m.group(3) else (30 if m.group(4) else 0)
            if ampm in ("오후", "저녁", "밤") and h < 12:
                h += 12
            if h < 24 and mi < 60:
                tm, t = f"{h:02d}:{mi:02d}", _cut(t, m)

    # 6) 남은 말이 제목 — 명령어와 군더더기를 걷어낸다
    t = _NOISE.sub(" ", t)
    title = re.sub(r"\s+", " ", t).strip(" .,·~!?")
    if not title:
        return d.isoformat(), tm, "", "제목이 없어요. 무슨 일정인가요?"
    return d.isoformat(), tm, title, ""


def _parse_time(tok: str) -> str | None:
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", tok)
    if m:
        h, mi = int(m.group(1)), int(m.group(2))
        if 0 <= h < 24 and 0 <= mi < 60:
            return f"{h:02d}:{mi:02d}"
    return None


def _fmt(it: dict, idx: int) -> str:
    t = f" {it['time']}" if it.get("time") else ""
    return f"{idx}. {it['date']}{t}  {it['title']}"


def handle(args: list[str]) -> str:
    if not args:
        return _list(date.today(), date.today(), "오늘")
    sub = args[0]

    if sub == "추가":
        rest = " ".join(args[1:]).strip()
        if not rest:
            return "형식: /cal 추가 7/25 14:00 제목   (말로 하셔도 됩니다 — '내일 3시 부과장 회의')"
        d, tm, title, why = parse_event(rest)                 # 말로 써도 읽는다
        if why:
            return why
        items = _load()
        items.append({"id": (max([i.get("id", 0) for i in items], default=0) + 1),
                      "date": d, "time": tm, "title": title})
        items.sort(key=lambda x: (x["date"], x.get("time") or "99:99"))
        _save(items)
        return f"✅ 등록: {d}{(' ' + tm) if tm else ''} {title}"

    if sub in ("삭제", "삭제하기", "del"):
        if len(args) < 2 or not args[1].isdigit():
            return "형식: /cal 삭제 <번호> (번호는 /cal 목록의 앞 숫자)"
        n = int(args[1])
        items = _load()
        shown = sorted(items, key=lambda x: (x["date"], x.get("time") or "99:99"))
        if not (1 <= n <= len(shown)):
            return f"{n}번 일정이 없어요."
        target = shown[n - 1]
        items = [i for i in items if i is not target]
        _save(items)
        return f"🗑 삭제: {target['date']} {target['title']}"

    if sub in ("주간", "week", "이번주"):
        today = date.today()
        mon = today - timedelta(days=today.weekday())
        return _list(mon, mon + timedelta(days=6), "이번 주")

    if sub in ("전체", "all"):
        items = sorted(_load(), key=lambda x: (x["date"], x.get("time") or "99:99"))
        if not items:
            return "등록된 일정이 없어요."
        return "📅 전체 일정\n" + "\n".join(_fmt(it, i + 1) for i, it in enumerate(items))

    # 날짜만 준 경우: /cal 7/25
    d = _parse_date(sub)
    if d:
        dd = date.fromisoformat(d)
        return _list(dd, dd, d)
    return "사용법: /cal · /cal 주간 · /cal 추가 7/25 14:00 제목 · /cal 삭제 <번호>"


def _list(d0: date, d1: date, label: str) -> str:
    items = sorted(_load(), key=lambda x: (x["date"], x.get("time") or "99:99"))
    sel = [it for it in items if d0.isoformat() <= it["date"] <= d1.isoformat()]
    ext = _caldav_range(d0, d1)
    head = f"📅 {label} 일정"
    if not sel and not ext:
        return head + "\n(없음)"
    body = "\n".join(_fmt(it, i + 1) for i, it in enumerate(sel))
    if ext:
        body += ("\n" if body else "") + "─ iCloud ─\n" + "\n".join(ext)
    return head + "\n" + body


def today_lines() -> list[str]:
    """아침 브리핑용 — 오늘 일정 한 줄씩."""
    t = date.today().isoformat()
    items = sorted(_load(), key=lambda x: (x["date"], x.get("time") or "99:99"))
    out = [f"{it.get('time','') or '종일'} {it['title']}" for it in items if it["date"] == t]
    return out + _caldav_range(date.today(), date.today())


def _caldav_range(d0: date, d1: date) -> list[str]:
    """iCloud 자격증명이 config에 있을 때만. 실패해도 조용히 빈 목록."""
    cfg = config.load_config() or {}
    if not (cfg.get("icloud_id") and cfg.get("icloud_pw")):
        return []
    try:
        import caldav
        from caldav.lib.error import DAVError
    except Exception:                                        # noqa: BLE001
        return []
    try:
        client = caldav.DAVClient(url="https://caldav.icloud.com/",
                                  username=cfg["icloud_id"], password=cfg["icloud_pw"])
        principal = client.principal()
        out = []
        start = datetime(d0.year, d0.month, d0.day)
        end = datetime(d1.year, d1.month, d1.day, 23, 59)
        for cal in principal.calendars():
            for ev in cal.date_search(start=start, end=end, expand=True):
                try:
                    comp = ev.icalendar_component
                    summ = str(comp.get("summary", "(제목없음)"))
                    dt = comp.get("dtstart")
                    tstr = ""
                    if dt is not None and hasattr(dt.dt, "hour"):
                        tstr = dt.dt.strftime("%m/%d %H:%M")
                    elif dt is not None:
                        tstr = dt.dt.strftime("%m/%d")
                    out.append(f"· {tstr} {summ}".strip())
                except Exception:                            # noqa: BLE001
                    continue
        return out[:20]
    except Exception:                                        # noqa: BLE001
        return []
