# -*- coding: utf-8 -*-
"""② 일정 추가·브리핑 — 로컬 캘린더(data/calendar.json).

iCloud(CalDAV)는 config에 자격증명 있을 때만 선택적으로 함께 조회.
명령 형식(자연어 파싱 아님):
  /cal 추가 7/25 14:00 부과장 회의
  /cal              → 오늘
  /cal 주간          → 이번 주(월~일)
  /cal 삭제 3
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

import config

CAL = "calendar.json"


def _load() -> list[dict]:
    return config.read_json(CAL, [])


def _save(items: list[dict]) -> None:
    config.write_json(CAL, items)


def _parse_date(tok: str) -> str | None:
    """'7/25' '2026-07-25' '7.25' '오늘' '내일' → YYYY-MM-DD."""
    today = date.today()
    if tok in ("오늘", "today"):
        return today.isoformat()
    if tok in ("내일", "tomorrow"):
        return (today + timedelta(days=1)).isoformat()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", tok)
    if m:
        y, mo, d = map(int, m.groups())
        try: return date(y, mo, d).isoformat()
        except ValueError: return None
    m = re.fullmatch(r"(\d{1,2})[/.](\d{1,2})", tok)
    if m:
        mo, d = map(int, m.groups())
        y = today.year
        try:
            dd = date(y, mo, d)
            if dd < today - timedelta(days=180):   # 지난 달 크게 지났으면 내년
                dd = date(y + 1, mo, d)
            return dd.isoformat()
        except ValueError:
            return None
    return None


def _parse_time(tok: str) -> str | None:
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", tok)
    if m:
        h, mi = int(m.group(1)), int(m.group(2))
        if 0 <= h < 24 and 0 <= mi < 60:
            return f"{h:02d}:{mi:02d}"
    return None


def _fmt(it: dict, idx: int) -> str:
    t = f" {it['time']}" if it.get("time") else ""
    return f"{idx}. {it['date']}{t}  {it['title']}"


def handle(args: list[str]) -> str:
    if not args:
        return _list(date.today(), date.today(), "오늘")
    sub = args[0]

    if sub == "추가":
        rest = args[1:]
        if not rest:
            return "형식: /cal 추가 7/25 14:00 제목"
        d = _parse_date(rest[0])
        if not d:
            return f"날짜를 못 읽었어요: '{rest[0]}' (예: 7/25)"
        rest = rest[1:]
        tm = ""
        if rest and _parse_time(rest[0]):
            tm = _parse_time(rest[0]); rest = rest[1:]
        title = " ".join(rest).strip()
        if not title:
            return "제목이 없어요. 예: /cal 추가 7/25 14:00 부과장 회의"
        items = _load()
        items.append({"id": (max([i.get("id", 0) for i in items], default=0) + 1),
                      "date": d, "time": tm, "title": title})
        items.sort(key=lambda x: (x["date"], x.get("time") or "99:99"))
        _save(items)
        return f"✅ 등록: {d}{(' ' + tm) if tm else ''} {title}"

    if sub in ("삭제", "삭제하기", "del"):
        if len(args) < 2 or not args[1].isdigit():
            return "형식: /cal 삭제 <번호> (번호는 /cal 목록의 앞 숫자)"
        n = int(args[1])
        items = _load()
        shown = sorted(items, key=lambda x: (x["date"], x.get("time") or "99:99"))
        if not (1 <= n <= len(shown)):
            return f"{n}번 일정이 없어요."
        target = shown[n - 1]
        items = [i for i in items if i is not target]
        _save(items)
        return f"🗑 삭제: {target['date']} {target['title']}"

    if sub in ("주간", "week", "이번주"):
        today = date.today()
        mon = today - timedelta(days=today.weekday())
        return _list(mon, mon + timedelta(days=6), "이번 주")

    if sub in ("전체", "all"):
        items = sorted(_load(), key=lambda x: (x["date"], x.get("time") or "99:99"))
        if not items:
            return "등록된 일정이 없어요."
        return "📅 전체 일정\n" + "\n".join(_fmt(it, i + 1) for i, it in enumerate(items))

    # 날짜만 준 경우: /cal 7/25
    d = _parse_date(sub)
    if d:
        dd = date.fromisoformat(d)
        return _list(dd, dd, d)
    return "사용법: /cal · /cal 주간 · /cal 추가 7/25 14:00 제목 · /cal 삭제 <번호>"


def _list(d0: date, d1: date, label: str) -> str:
    items = sorted(_load(), key=lambda x: (x["date"], x.get("time") or "99:99"))
    sel = [it for it in items if d0.isoformat() <= it["date"] <= d1.isoformat()]
    ext = _caldav_range(d0, d1)
    head = f"📅 {label} 일정"
    if not sel and not ext:
        return head + "\n(없음)"
    body = "\n".join(_fmt(it, i + 1) for i, it in enumerate(sel))
    if ext:
        body += ("\n" if body else "") + "─ iCloud ─\n" + "\n".join(ext)
    return head + "\n" + body


def today_lines() -> list[str]:
    """아침 브리핑용 — 오늘 일정 한 줄씩."""
    t = date.today().isoformat()
    items = sorted(_load(), key=lambda x: (x["date"], x.get("time") or "99:99"))
    out = [f"{it.get('time','') or '종일'} {it['title']}" for it in items if it["date"] == t]
    return out + _caldav_range(date.today(), date.today())


def _caldav_range(d0: date, d1: date) -> list[str]:
    """iCloud 자격증명이 config에 있을 때만. 실패해도 조용히 빈 목록."""
    cfg = config.load_config() or {}
    if not (cfg.get("icloud_id") and cfg.get("icloud_pw")):
        return []
    try:
        import caldav
        from caldav.lib.error import DAVError
    except Exception:                                        # noqa: BLE001
        return []
    try:
        client = caldav.DAVClient(url="https://caldav.icloud.com/",
                                  username=cfg["icloud_id"], password=cfg["icloud_pw"])
        principal = client.principal()
        out = []
        start = datetime(d0.year, d0.month, d0.day)
        end = datetime(d1.year, d1.month, d1.day, 23, 59)
        for cal in principal.calendars():
            for ev in cal.date_search(start=start, end=end, expand=True):
                try:
                    comp = ev.icalendar_component
                    summ = str(comp.get("summary", "(제목없음)"))
                    dt = comp.get("dtstart")
                    tstr = ""
                    if dt is not None and hasattr(dt.dt, "hour"):
                        tstr = dt.dt.strftime("%m/%d %H:%M")
                    elif dt is not None:
                        tstr = dt.dt.strftime("%m/%d")
                    out.append(f"· {tstr} {summ}".strip())
                except Exception:                            # noqa: BLE001
                    continue
        return out[:20]
    except Exception:                                        # noqa: BLE001
        return []
