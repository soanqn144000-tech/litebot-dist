# -*- coding: utf-8 -*-
"""⑧-b 머리(선택) — 클로드 코드. 클로드 프로/맥스 구독이 있는 사람용(아델과 같은 구조).

  · API 키가 아니라 그 PC 의 `claude` 로그인(구독)으로 돈다 — 쓴 만큼 과금이 아니라 구독 한도 내.
  · 아델(scripts/assistant_listen.py)이 `claude -p` 를 부르는 방식을 그대로 얇게 따온다.
  · 요약·표해석 같은 '텍스트 한 번'만 쓴다 — 도구는 다 끈다(안전·속도).

밖에서 쓰는 건 두 개:
    brain_claude.available()  -> bool          # 이 PC 에 claude 가 깔리고 로그인돼 있나
    brain_claude.ask(prompt, images=[…]) -> str | None
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile

import config

log = config.get_logger()

# 텍스트 요약엔 도구가 필요 없다 — 다 꺼서 빠르고 안전하게(파일·명령 접근 원천 차단).
_NO_TOOLS = ["Bash", "Edit", "Write", "WebFetch", "WebSearch", "Task",
             "Glob", "Grep", "NotebookEdit"]
_BIN_CACHE = None


def _bin() -> str | None:
    """claude 실행 파일 경로. 없으면 None(=이 PC 엔 클로드 코드 없음)."""
    global _BIN_CACHE
    if _BIN_CACHE is not None:
        return _BIN_CACHE or None
    found = shutil.which("claude") or shutil.which("claude.cmd") or ""
    if not found:                                            # PATH 에 없을 때 흔한 설치 위치 몇 곳
        for cand in (os.path.expanduser(r"~\.local\bin\claude"),
                     os.path.expanduser(r"~\AppData\Local\Programs\claude\claude.exe")):
            if os.path.exists(cand):
                found = cand
                break
    _BIN_CACHE = found
    return found or None


def available() -> bool:
    return _bin() is not None


def status() -> str:
    return "클로드 코드 연결됨(구독)" if available() else "클로드 코드 미설치"


def ask(prompt: str, images: list[bytes] | None = None, timeout: int = 120) -> str | None:
    """claude -p 로 텍스트 한 번. 실패·미설치면 None → 호출자가 다른 머리/규칙으로 내려간다.

    사진은 임시파일로 떨궈 경로를 프롬프트에 실어 Read 로만 읽게 한다(그때만 Read 허용).
    """
    exe = _bin()
    if not exe:
        return None
    allow_read = bool(images)
    tmp_files: list[str] = []
    body = prompt
    try:
        if images:
            paths = []
            for i, img in enumerate(images[:4]):
                fd, p = tempfile.mkstemp(prefix="litebot_img_", suffix=f"_{i}.jpg")
                with os.fdopen(fd, "wb") as f:
                    f.write(img)
                tmp_files.append(p)
                paths.append(p)
            body = ("아래 사진 파일을 Read 로 읽고 답하라.\n"
                    + "\n".join(f"사진: {p}" for p in paths) + "\n\n" + prompt)

        cmd = [exe, "-p", body, "--output-format", "text"]
        disallow = [t for t in _NO_TOOLS if not (allow_read and t == "Read")]
        cmd += ["--disallowed-tools", ",".join(disallow)]
        if not allow_read:
            cmd += ["--disallowed-tools", "Read"]           # 텍스트만이면 Read 도 차단
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                               errors="replace", timeout=timeout)
        except subprocess.TimeoutExpired:
            log.info("claude -p 타임아웃(%ds)", timeout)
            return None
        out = (r.stdout or "").strip()
        if r.returncode != 0 and not out:
            log.info("claude -p 실패(code %s): %s", r.returncode, (r.stderr or "")[:150])
            return None
        return out or None
    except Exception as e:                                   # noqa: BLE001
        log.info("claude 호출 오류: %s", type(e).__name__)
        return None
    finally:
        for p in tmp_files:
            try:
                os.remove(p)
            except Exception:                               # noqa: BLE001
                pass
