# -*- coding: utf-8 -*-
"""분 단위 스케줄러 — 반복업무·예약발송·아침브리핑을 봇 이벤트루프 안에서 돌린다.

schedule 라이브러리 대신 표준 asyncio 로 구현(의존성 최소화, exe 패키징 안정).
매 분이 바뀔 때만 due 검사 → 같은 분에 중복 발송 안 됨.
"""
from __future__ import annotations

import bot
import asyncio
import time
from datetime import datetime

import briefing
import config
import report
import sender
import tasks
import watch

WATCH_EVERY = 180                                            # 능동 감시 주기(초) — 3분마다 새 것 확인


async def run(app):
    """post_init 에서 create_task 로 띄운다. app.bot 으로 발송."""
    log = config.get_logger()
    last_minute = None
    last_briefing_date = None
    last_watch = 0.0
    log.info("스케줄러 시작 — 반복업무·예약발송·브리핑·능동감시")
    while True:
        try:
            now = datetime.now()
            minute = now.strftime("%Y-%m-%d %H:%M")
            if minute != last_minute:
                last_minute = minute
                cfg = config.load_config() or {}
                owner = cfg.get("chat_id")

                # ① 반복업무(매일/매시간) → 주인에게
                if owner:
                    for msg in tasks.due(now):
                        await _safe_send(app, owner, msg, log)

                # ② 예약발송 → 지정 대상에게, 결과 주인 보고
                for it in sender.due(now):
                    # 남에게 나가는 건 예약발송뿐이다. 나머지(브리핑·감시알림·발송결과)는
                    # 부장님 본인에게 가는 것이라 꼬리표를 안 붙인다 — 붙이면 잔소리가 된다.
                    ok = await _safe_send(app, it["chat_id"],
                                          bot.with_ai_mark(it["message"]), log)
                    if owner:
                        res = "성공" if ok else "실패"
                        await _safe_send(app, owner, f"📤 예약발송 {res}: {it['chat_id']}\n{it['message']}", log)

                # ③ 아침 브리핑(하루 1회)
                btime = cfg.get("briefing_time", "07:30")
                if owner and now.strftime("%H:%M") == btime and last_briefing_date != now.date():
                    last_briefing_date = now.date()
                    await _safe_send(app, owner, briefing.build(cfg), log)

                # ⑤ 정기 자동 보고(차트·요약) → 주인에게
                if owner:
                    for rep in report.due(now):
                        try:
                            await report.run(app, owner, cfg, rep, log)
                        except Exception as e:                # noqa: BLE001
                            log.error("자동보고 오류 — %s", e)

            # ④ 능동 감시(분 tick 과 별개로 3분마다) — 새 언급·방 글·마감을 먼저 알림
            cfg2 = config.load_config() or {}
            owner2 = cfg2.get("chat_id")
            if owner2 and watch.enabled(cfg2) and (time.monotonic() - last_watch) >= WATCH_EVERY:
                last_watch = time.monotonic()
                try:
                    for alert in await watch.scan(cfg2):
                        await _safe_send(app, owner2, alert, log)
                except Exception as e:                       # noqa: BLE001
                    log.error("능동 감시 오류 — %s", e)
        except Exception as e:                               # noqa: BLE001
            log.error("스케줄러 tick 오류 — %s", e, exc_info=True)
        await asyncio.sleep(15)


async def _safe_send(app, chat_id, text, log) -> bool:
    try:
        await app.bot.send_message(chat_id=int(chat_id), text=text)
        return True
    except Exception as e:                                   # noqa: BLE001
        log.error("발송 실패 chat=%s — %s", chat_id, e)
        return False
