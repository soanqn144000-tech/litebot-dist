# -*- coding: utf-8 -*-
"""① 날씨 브리핑 — Open-Meteo (무료·키 불필요).

현재 기온 / 오전·오후 대표기온 / 강수확률 / 미세먼지(PM10·PM2.5) / 자외선.
멘트는 짧고 실용적인 한국어 한두 줄(아델 B형).
"""
from __future__ import annotations

import requests

FORECAST = "https://api.open-meteo.com/v1/forecast"
AIR = "https://air-quality-api.open-meteo.com/v1/air-quality"
TIMEOUT = 12


def _pm_grade(pm10, pm25) -> str:
    """환경부 등급(대략): PM10/PM2.5 중 나쁜 쪽 기준."""
    def g10(v): return 0 if v <= 30 else 1 if v <= 80 else 2 if v <= 150 else 3
    def g25(v): return 0 if v <= 15 else 1 if v <= 35 else 2 if v <= 75 else 3
    grade = max(g10(pm10), g25(pm25))
    return ["좋음", "보통", "나쁨", "매우나쁨"][grade]


def brief(cfg: dict) -> str:
    lat, lon = cfg.get("lat", 37.539), cfg.get("lon", 127.214)
    town = cfg.get("town", "우리 동네")
    try:
        r = requests.get(FORECAST, params={
            "latitude": lat, "longitude": lon, "timezone": "Asia/Seoul",
            "current": "temperature_2m,precipitation,relative_humidity_2m",
            "hourly": "temperature_2m,precipitation_probability",
            "daily": "uv_index_max,temperature_2m_max,temperature_2m_min",
        }, timeout=TIMEOUT).json()
    except Exception as e:                                   # noqa: BLE001
        return f"날씨를 못 불러왔어요 (네트워크 확인). [{type(e).__name__}]"

    cur = r.get("current", {})
    hourly = r.get("hourly", {})
    daily = r.get("daily", {})
    temp = cur.get("temperature_2m")
    hum = cur.get("relative_humidity_2m")

    # 오전(09시)·오후(15시) 대표 기온·강수확률
    times = hourly.get("time", [])
    t_arr = hourly.get("temperature_2m", [])
    p_arr = hourly.get("precipitation_probability", [])
    def at(hh):
        for i, t in enumerate(times):
            if t.endswith(f"T{hh:02d}:00"):
                return (t_arr[i] if i < len(t_arr) else None,
                        p_arr[i] if i < len(p_arr) else None)
        return (None, None)
    am_t, am_p = at(9)
    pm_t, pm_p = at(15)

    tmax = (daily.get("temperature_2m_max") or [None])[0]
    tmin = (daily.get("temperature_2m_min") or [None])[0]
    uv = (daily.get("uv_index_max") or [None])[0]

    # 미세먼지
    dust = ""
    try:
        a = requests.get(AIR, params={
            "latitude": lat, "longitude": lon, "timezone": "Asia/Seoul",
            "current": "pm10,pm2_5",
        }, timeout=TIMEOUT).json()
        ac = a.get("current", {})
        pm10, pm25 = ac.get("pm10"), ac.get("pm2_5")
        if pm10 is not None and pm25 is not None:
            dust = f"미세먼지 {_pm_grade(pm10, pm25)}(PM10 {pm10:.0f}·PM2.5 {pm25:.0f})"
    except Exception:                                        # noqa: BLE001
        dust = ""

    lines = [f"🌤 {town} 날씨"]
    if temp is not None:
        head = f"지금 {temp:.0f}℃"
        if hum is not None:
            head += f"·습도 {hum:.0f}%"
        lines.append(head)
    if tmin is not None and tmax is not None:
        lines.append(f"오늘 {tmin:.0f}~{tmax:.0f}℃")
    seg = []
    if am_t is not None:
        seg.append(f"오전 {am_t:.0f}℃(비 {am_p or 0:.0f}%)")
    if pm_t is not None:
        seg.append(f"오후 {pm_t:.0f}℃(비 {pm_p or 0:.0f}%)")
    if seg:
        lines.append(" · ".join(seg))
    if dust:
        lines.append(dust)
    if uv is not None:
        uv_txt = "낮음" if uv < 3 else "보통" if uv < 6 else "높음" if uv < 8 else "매우높음"
        lines.append(f"자외선 {uv_txt}")

    # 실용 한 줄
    tip = []
    maxp = max([p for p in (am_p, pm_p) if p is not None], default=0)
    if maxp >= 60:
        tip.append("우산 챙기세요")
    elif maxp >= 30:
        tip.append("우산 있으면 좋아요")
    if uv is not None and uv >= 8:
        tip.append("자외선 강해요")
    if tmin is not None and tmin <= 3:
        tip.append("따뜻하게 입으세요")
    if tip:
        lines.append("→ " + ", ".join(tip))
    return "\n".join(lines)
