# -*- coding: utf-8 -*-
"""⑩ 자연어 → 명령. 슬래시 없이 그냥 말해도 알아듣게.

2단으로 본다:
  1) 규칙 라우터 — 머리(AI) 없어도 늘 동작. 자주 쓰는 말만 확실하게.
  2) 머리 라우터 — 키가 있고 규칙이 못 잡았을 때만. JSON 하나로 명령·인자를 받는다.

돌려주는 값: (명령, 인자목록) 또는 (None, [])  — 명령은 bot.py 의 cmd_* 이름과 같다.
"""
from __future__ import annotations

import json
import re

import config
import llm

CMDS = ("weather", "cal", "find", "collect", "chart", "task", "send", "remind", "status", "today")
LEARNED = "learned_routes.json"                              # 사용자가 가르친 말 → 명령

# 규칙: (정규식, 명령, 인자 만드는 법). 위에서부터 먼저 맞는 것.
RULES: list[tuple[str, str]] = [
    (r"(오늘\s*뭐|뭐\s*하지|뭐\s*해야|오늘\s*어때|브리핑|하루\s*정리|오늘\s*정리)", "today"),
    (r"(날씨|기온|비\s*와|우산|미세먼지)", "weather"),
    (r"(일정|스케줄|캘린더|약속)", "cal"),
    (r"(반복업무|루틴|매일\s*[^\s]*\s*(알림|알려|보내)|매시간|시간마다|날마다)", "task"),
    (r"(차트|그래프|추이|추세|시각화)", "chart"),           # 차트가 취합보다 먼저 — "취합창의 파일로 차트"
    # '취합'은 방 이름에도 들어간다("내무부) 취합 및 보고창"). 뒤에 창·방·및 이 오면 명령이 아니다.
    (r"(취합(?!\s*(및|창|방|주제))|집계|몇\s*건|건수)", "collect"),
    (r"(알림|리마인드|분\s*뒤|시간\s*뒤|이따가)", "remind"),
    (r"(상태|버전|머리\s*켜|한도)", "status"),
    (r"(찾아|검색|정리해|요약|뭐라고|무슨\s*말|올라온|공지\s*있|내용\s*좀)", "find"),
]
REPEAT_RE = re.compile(r"매일|날마다|매시간|시간마다|매주|정각마다")
SEND_RE = re.compile(r"(보내|전송|발송|전달)\s*(줘|주세요|해줘|해라)?")
# 검색어에서 걷어낼 말 — 명령 동사·군더더기. 문장 어디에 있든 뺀다.
NOISE = re.compile(r"(찾아줘|찾아봐|찾아|검색해줘|검색해|검색|취합해줘|집계해줘|집계|"
                   r"정리해줘|정리해|요약해줘|요약|알려줘|보여줘|만들어줘|만들고싶어|만들래|"
                   r"그려줘|뽑아줘|올려준|올린|보내준|받은|"
                   r"차트로|차트|그래프|시각화|관련해서|관련|해줘|해라|좀|줘|"
                   r"내\s*텔레그램에서|텔레그램에서|에서|파일|자료|첨부)")


def teach(word: str, cmd: str) -> bool:
    """'이 말은 이 명령이다'를 배워 둔다(로컬 파일). 다음부터 규칙처럼 즉시 잡힌다."""
    word = (word or "").strip()
    if len(word) < 2 or cmd not in CMDS:
        return False
    items = config.read_json(LEARNED, [])
    if not any(i.get("word") == word for i in items):
        items.append({"word": word, "cmd": cmd})
        config.write_json(LEARNED, items)
    return True


def _learned_route(t: str) -> tuple[str | None, list[str]]:
    for i in config.read_json(LEARNED, []):
        w = i.get("word") or ""
        if w and w in t and i.get("cmd") in CMDS:
            cmd = i["cmd"]
            if cmd in ("find", "collect"):
                return cmd, _strip_cmd_words(t).split()
            return cmd, []
    return None, []


def rule_route(text: str) -> tuple[str | None, list[str]]:
    t = text.strip()
    if not t or t.startswith("/"):
        return None, []
    if SEND_RE.search(t):
        return "send_confirm", t.split()                     # 발송은 반드시 확인 절차를 거친다
    cmd, args = _learned_route(t)                            # 가르친 말이 먼저
    if cmd:
        return cmd, args
    # 되풀이 표현이 있으면 그게 우선이다. 메시지 안의 낱말('출결 취합') 때문에
    # 검색으로 새던 것 — "매일 아침 9시에 출결 취합 알려줘" 는 반복업무지 검색이 아니다.
    if REPEAT_RE.search(t) and re.search(r"추가|등록|잡아|넣어|알려\s*줘|보내\s*줘", t):
        return "task", ["추가", t.strip()]
    for pat, cmd in RULES:
        if re.search(pat, t):
            if cmd in ("find", "collect"):
                return cmd, _strip_cmd_words(t).split()
            if cmd == "chart":
                return cmd, _chart_args(t)
            if cmd == "cal":
                return cmd, _cal_args(t)
            if cmd == "remind":
                return cmd, _remind_args(t)
            if cmd == "task" and re.search(r"추가|등록|잡아|넣어|알려\s*줘", t):
                return cmd, ["추가", t.strip()]              # 날짜·시각·내용 가려내기는 tasks 가 한다
            return cmd, []
    return None, []


def _strip_cmd_words(t: str) -> str:
    """'내무부 피티 관련해서 찾아줘' → '내무부 피티'. 명령 동사·군더더기를 걷어낸다."""
    return re.sub(r"\s+", " ", NOISE.sub(" ", t)).strip()


def _chart_args(t: str) -> list[str]:
    """숫자가 있으면 그 숫자로, 없으면 텔레그램을 뒤져서(검색) 만든다."""
    nums = re.findall(r"-?\d+(?:\.\d+)?", t)
    if len(nums) >= 3:                                       # '12 15 9 20 차트' 같은 직접 입력
        return nums
    kw = _strip_cmd_words(t)
    return ["검색"] + kw.split() if kw else ["검색"]


def _remind_args(t: str) -> list[str]:
    """'30분 뒤에 회의 알림 해줘' → ['30','회의'] / '14시 회의 알림' → ['14:00','회의']."""
    when = ""
    m = re.search(r"(\d{1,3})\s*분", t)
    if m:
        when = m.group(1)
    else:
        m = re.search(r"(\d{1,2})\s*[:시]\s*(\d{2})?", t)
        if m:
            when = f"{int(m.group(1))}:{m.group(2) or '00'}"
    if not when:
        return []
    msg = _strip_cmd_words(re.sub(r"(\d{1,3}\s*분\s*(뒤|후)?에?|\d{1,2}\s*[:시]\s*\d{0,2}|알림|리마인드)",
                                  " ", t))
    return [when, msg.strip() or "알림"]


def _cal_args(t: str) -> list[str]:
    if re.search(r"(주간|이번\s*주|한\s*주)", t):
        return ["주간"]
    if re.search(r"추가|잡아|등록|넣어", t):
        # 문장을 통째로 넘긴다. 예전엔 첫 낱말을 잘라내 제목이 사라졌다
        # ("3040모임 금주 목요일…" → 3040모임 실종, 2026-08-17). 날짜·시간·제목 가려내기는 cal 이 한다.
        return ["추가", t.strip()]
    return []


ROUTE_RULE = """너는 비서 앱의 '길잡이'다. 사용자의 한국어 말을 아래 명령 중 하나로 바꿔 JSON 하나만 뱉어라.
설명·코드펜스 금지.

명령:
- weather : 날씨
- cal     : 일정 보기/추가.  args 예) [], ["주간"], ["추가","7/25","14:00","회의"]
- find    : 텔레그램에서 내용 찾기·요약.  args = 핵심 낱말들 (+맨 뒤에 일수 숫자)
- collect : 같은 검색을 건수로 취합
- chart   : 차트. 텔레그램을 뒤져 만들 거면 args=["검색", 낱말…, 일수]
- task    : 반복 업무 등록/조회
- remind  : 한 번 알림.  args 예) ["30","약 먹기"] 또는 ["14:00","회의"]
- status  : 앱 상태
- none    : 위 어느 것도 아님(그냥 대화·질문)

형식: {"cmd":"find","args":["내무부","피티","14"]}"""


def llm_route(cfg: dict, text: str) -> tuple[str | None, list[str]]:
    if not llm.available(cfg):
        return None, []
    reply = llm.ask(cfg, f"{ROUTE_RULE}\n\n사용자: {text}")
    if not reply:
        return None, []
    m = re.search(r"\{.*\}", reply, re.S)
    if not m:
        return None, []
    try:
        obj = json.loads(m.group(0))
    except Exception:                                        # noqa: BLE001
        return None, []
    cmd = str(obj.get("cmd") or "")
    if cmd not in CMDS:
        return None, []
    args = obj.get("args") or []
    if isinstance(args, str):
        args = args.split()
    return cmd, [str(a) for a in args]


def route(cfg: dict, text: str) -> tuple[str | None, list[str], str]:
    """(명령, 인자, 어떻게 잡았는지). 규칙 먼저, 못 잡으면 머리."""
    cmd, args = rule_route(text)
    if cmd:
        return cmd, args, "규칙"
    cmd, args = llm_route(cfg, text)
    if cmd:
        return cmd, args, "AI"
    return None, [], "없음"
