# -*- coding: utf-8 -*-
"""트레이 아이콘 — pystray + Pillow. 콘솔창 없음.

우클릭: [상태 보기] [설정 열기] [로그 폴더 열기] [종료]
설정 열기는 별도 프로세스로 마법사를 띄운다(트레이 이벤트루프와 tkinter 충돌 회피).
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
from pathlib import Path

import pystray
from PIL import Image

import config

log = config.get_logger()


def _icon_image() -> Image.Image:
    ico = config.APP_DIR / "litebot.ico"
    if ico.exists():
        try:
            return Image.open(ico)
        except Exception:                                    # noqa: BLE001
            pass
    # 폴백: 코드로 다크그린+골드 원 생성
    from PIL import ImageDraw
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((4, 4, 60, 60), fill="#0e2a20", outline="#d8b15e", width=4)
    d.ellipse((24, 24, 40, 40), fill="#d8b15e")
    return img


def _spawn_settings():
    if getattr(sys, "frozen", False):
        subprocess.Popen([sys.executable, "--settings"])
    else:
        subprocess.Popen([sys.executable, str(Path(__file__).with_name("litebot.py")), "--settings"])


def run_tray(on_quit):
    """메인 스레드에서 블로킹 실행. on_quit=종료 콜백."""
    icon_ref = {}

    def status(icon, item):
        cfg = config.load_config() or {}
        icon.notify(
            f"LiteBot 실행 중\n동네: {cfg.get('town','?')} · 브리핑 {cfg.get('briefing_time','?')}",
            "LiteBot 상태")

    def settings(icon, item):
        _spawn_settings()

    def open_logs(icon, item):
        try:
            os.startfile(str(config.LOG_DIR))               # noqa: S606
        except Exception as e:                               # noqa: BLE001
            log.error("로그 폴더 열기 실패 — %s", e)

    def quit_app(icon, item):
        log.info("트레이에서 종료 요청")
        try:
            on_quit()
        finally:
            icon.stop()

    menu = pystray.Menu(
        pystray.MenuItem("상태 보기", status),
        pystray.MenuItem("설정 열기", settings),
        pystray.MenuItem("로그 폴더 열기", open_logs),
        pystray.MenuItem("종료", quit_app),
    )
    icon = pystray.Icon("LiteBot", _icon_image(), "LiteBot", menu)
    icon_ref["i"] = icon
    icon.run()
