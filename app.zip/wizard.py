# -*- coding: utf-8 -*-
"""최초 실행 설정 마법사 — config.json 없을 때 뜨는 tkinter 창.

봇 토큰·chat_id·동네(좌표 자동검색)·브리핑 시각·(선택)Telethon/iCloud·자동시작.
저장 시 형식 검증 후 config.json 저장. 반환 True=저장됨, False=취소.
"""
from __future__ import annotations

import re
import tkinter as tk
from tkinter import messagebox, ttk

import requests

import autostart
import config

GEOCODE = "https://geocoding-api.open-meteo.com/v1/search"


def run_wizard() -> bool:
    cfg = dict(config.DEFAULTS)
    saved = {"ok": False}

    root = tk.Tk()
    root.title("LiteBot 설정")
    root.geometry("560x640")
    root.resizable(False, False)

    pad = {"padx": 12, "pady": 4}
    row = 0

    def label(text, bold=False):
        nonlocal row
        f = ("맑은 고딕", 11, "bold" if bold else "normal")
        tk.Label(root, text=text, font=f, anchor="w").grid(row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1

    def entry(default="", show=None, width=52):
        nonlocal row
        e = tk.Entry(root, width=width, show=show)
        e.insert(0, default)
        e.grid(row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1
        return e

    label("① 봇 토큰 (필수)", bold=True)
    label("텔레그램에서 @BotFather 검색 → /newbot → 받은 토큰 붙여넣기")
    e_token = entry()

    label("② 내 chat_id (필수)", bold=True)
    label("텔레그램에서 @userinfobot 검색 → 뜨는 숫자")
    e_chat = entry()

    label("③ 동네 이름", bold=True)
    nonlocal_frame = tk.Frame(root)
    nonlocal_frame.grid(row=row, column=0, columnspan=3, sticky="w", **pad); row += 1
    e_town = tk.Entry(nonlocal_frame, width=28)
    e_town.insert(0, "하남")
    e_town.pack(side="left")
    lat_var = tk.StringVar(value=str(cfg["lat"]))
    lon_var = tk.StringVar(value=str(cfg["lon"]))
    coord_lbl = tk.Label(nonlocal_frame, text=f"({lat_var.get()}, {lon_var.get()})", fg="#0a7")

    def geocode():
        name = e_town.get().strip()
        if not name:
            return
        try:
            r = requests.get(GEOCODE, params={"name": name, "count": 1, "language": "ko"}, timeout=10).json()
            res = (r.get("results") or [])
            if not res:
                messagebox.showwarning("좌표", f"'{name}' 좌표를 못 찾았어요.")
                return
            lat_var.set(f"{res[0]['latitude']:.3f}")
            lon_var.set(f"{res[0]['longitude']:.3f}")
            coord_lbl.config(text=f"({lat_var.get()}, {lon_var.get()})")
        except Exception as e:                               # noqa: BLE001
            messagebox.showerror("좌표", f"검색 실패: {e}")

    tk.Button(nonlocal_frame, text="좌표 자동검색", command=geocode).pack(side="left", padx=6)
    coord_lbl.pack(side="left")

    label("④ 아침 브리핑 시각 (HH:MM)", bold=True)
    e_brief = entry("07:30", width=12)

    # ⑤ 선택 항목(접기)
    adv_open = {"v": False}
    adv = tk.Frame(root)

    def toggle_adv():
        adv_open["v"] = not adv_open["v"]
        if adv_open["v"]:
            adv.grid(row=999, column=0, columnspan=3, sticky="w", padx=12)
            btn_adv.config(text="▲ 선택 기능 접기")
        else:
            adv.grid_forget()
            btn_adv.config(text="▼ 선택 기능 (텔레그램검색·iCloud)")

    btn_adv = tk.Button(root, text="▼ 선택 기능 (텔레그램검색·iCloud)", command=toggle_adv)
    btn_adv.grid(row=row, column=0, columnspan=3, sticky="w", **pad); row += 1

    tk.Label(adv, text="Telethon api_id / api_hash (my.telegram.org)").grid(row=0, column=0, sticky="w")
    e_apiid = tk.Entry(adv, width=20); e_apiid.grid(row=1, column=0, sticky="w", pady=2)
    e_apihash = tk.Entry(adv, width=40); e_apihash.grid(row=1, column=1, sticky="w", pady=2)
    tk.Label(adv, text="iCloud 이메일 / 앱암호").grid(row=2, column=0, sticky="w")
    e_icid = tk.Entry(adv, width=20); e_icid.grid(row=3, column=0, sticky="w", pady=2)
    e_icpw = tk.Entry(adv, width=40, show="*"); e_icpw.grid(row=3, column=1, sticky="w", pady=2)

    # ⑥ 자동시작
    auto_var = tk.BooleanVar(value=False)
    tk.Checkbutton(root, text="컴퓨터 켤 때 자동 시작", variable=auto_var,
                   font=("맑은 고딕", 11)).grid(row=row, column=0, columnspan=3, sticky="w", **pad)
    row += 1

    def save():
        token = e_token.get().strip()
        chat = e_chat.get().strip()
        if not re.fullmatch(r"\d{6,}:[\w-]{20,}", token):
            messagebox.showerror("확인", "봇 토큰 형식이 올바르지 않아요.\n(예: 1234567890:AA...)")
            return
        if not chat.lstrip("-").isdigit():
            messagebox.showerror("확인", "chat_id 는 숫자여야 해요.")
            return
        if not re.fullmatch(r"\d{1,2}:\d{2}", e_brief.get().strip()):
            messagebox.showerror("확인", "브리핑 시각은 HH:MM 형식이어야 해요.")
            return
        cfg.update({
            "bot_token": token, "chat_id": chat,
            "town": e_town.get().strip() or "우리 동네",
            "lat": float(lat_var.get()), "lon": float(lon_var.get()),
            "briefing_time": e_brief.get().strip(),
            "autostart": bool(auto_var.get()),
            "tg_api_id": e_apiid.get().strip(), "tg_api_hash": e_apihash.get().strip(),
            "icloud_id": e_icid.get().strip(), "icloud_pw": e_icpw.get().strip(),
        })
        config.save_config(cfg)
        autostart.apply(cfg["autostart"])
        saved["ok"] = True
        root.destroy()

    tk.Button(root, text="저장하고 시작", command=save, bg="#0e7a4b", fg="white",
              font=("맑은 고딕", 12, "bold"), width=20, height=1).grid(
        row=row, column=0, columnspan=3, pady=16)

    root.mainloop()
    return saved["ok"]


def open_settings():
    """설정 열기(트레이 메뉴) — 기존 값 불러와 편집. 간단히 마법사 재사용."""
    existing = config.load_config()
    if existing:
        # 기존값을 DEFAULTS 자리에 반영해 마법사가 채워 보이게
        config.DEFAULTS.update(existing)
    return run_wizard()
