# -*- coding: utf-8 -*-
"""최초 실행 설정 마법사 — config.json 없을 때 뜨는 tkinter 창.

봇 토큰·chat_id·동네(좌표 자동검색)·브리핑 시각·(선택)Telethon/iCloud·자동시작.
저장 시 형식 검증 후 config.json 저장. 반환 True=저장됨, False=취소.
"""
from __future__ import annotations

import re
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

import requests

import autostart
import config

GEOCODE = "https://geocoding-api.open-meteo.com/v1/search"


def run_wizard() -> bool:
    cfg = dict(config.DEFAULTS)
    saved = {"ok": False}

    root = tk.Tk()
    root.title("LiteBot 설정")
    root.geometry("640x840")
    root.resizable(True, True)
    root.minsize(560, 640)

    pad = {"padx": 12, "pady": 4}
    row = 0

    def label(text, bold=False):
        nonlocal row
        f = ("맑은 고딕", 11, "bold" if bold else "normal")
        tk.Label(root, text=text, font=f, anchor="w").grid(row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1

    def entry(default="", show=None, width=52):
        nonlocal row
        e = tk.Entry(root, width=width, show=show)
        e.insert(0, default)
        e.grid(row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1
        return e

    label("① 봇 토큰 (필수)", bold=True)
    label("텔레그램에서 @BotFather 검색 → /newbot → 받은 토큰 붙여넣기")
    e_token = entry(cfg.get("bot_token", ""))

    label("② 내 chat_id (필수)", bold=True)
    label("텔레그램에서 @userinfobot 검색 → 뜨는 숫자")
    e_chat = entry(cfg.get("chat_id", ""))

    label("③ 동네 이름", bold=True)
    nonlocal_frame = tk.Frame(root)
    nonlocal_frame.grid(row=row, column=0, columnspan=3, sticky="w", **pad); row += 1
    e_town = tk.Entry(nonlocal_frame, width=28)
    e_town.insert(0, cfg.get("town", "하남"))
    e_town.pack(side="left")
    lat_var = tk.StringVar(value=str(cfg["lat"]))
    lon_var = tk.StringVar(value=str(cfg["lon"]))
    coord_lbl = tk.Label(nonlocal_frame, text=f"({lat_var.get()}, {lon_var.get()})", fg="#0a7")

    def geocode():
        name = e_town.get().strip()
        if not name:
            return
        try:
            r = requests.get(GEOCODE, params={"name": name, "count": 1, "language": "ko"}, timeout=10).json()
            res = (r.get("results") or [])
            if not res:
                messagebox.showwarning("좌표", f"'{name}' 좌표를 못 찾았어요.")
                return
            lat_var.set(f"{res[0]['latitude']:.3f}")
            lon_var.set(f"{res[0]['longitude']:.3f}")
            coord_lbl.config(text=f"({lat_var.get()}, {lon_var.get()})")
        except Exception as e:                               # noqa: BLE001
            messagebox.showerror("좌표", f"검색 실패: {e}")

    tk.Button(nonlocal_frame, text="좌표 자동검색", command=geocode).pack(side="left", padx=6)
    coord_lbl.pack(side="left")

    label("④ 아침 브리핑 시각 (HH:MM)", bold=True)
    e_brief = entry(cfg.get("briefing_time", "07:30"), width=12)

    # ⑤ 선택 항목(접기)
    adv_open = {"v": False}
    adv = tk.Frame(root)

    def toggle_adv():
        adv_open["v"] = not adv_open["v"]
        if adv_open["v"]:
            adv.grid(row=999, column=0, columnspan=3, sticky="w", padx=12)
            btn_adv.config(text="▲ 선택 기능 접기")
        else:
            adv.grid_forget()
            btn_adv.config(text="▼ 선택 기능 (텔레그램검색·iCloud)")

    btn_adv = tk.Button(root, text="▼ 선택 기능 (텔레그램검색·iCloud)", command=toggle_adv)
    btn_adv.grid(row=row, column=0, columnspan=3, sticky="w", **pad); row += 1

    tk.Label(adv, text="[텔레그램 검색]  — /find·/collect(대화 검색·취합) 쓸 때만. 안 쓰면 비워두세요.",
             font=("맑은 고딕", 9, "bold")).grid(row=0, column=0, columnspan=3, sticky="w")

    def _show_api_help():
        import webbrowser
        msg = ("텔레그램 api 발급 (무료, 약 2분)\n\n"
               "1. 브라우저에서  my.telegram.org  접속\n"
               "2. 본인 전화번호로 로그인 (문자로 온 코드 입력)\n"
               "3. 'API development tools' 클릭\n"
               "4. App title·Short name 에 아무거나 입력 → Create application\n"
               "5. 화면에 두 값이 나와요:\n"
               "   · App api_id (숫자)      → 왼쪽 'api_id' 칸\n"
               "   · App api_hash (긴 문자열) → 오른쪽 'api_hash' 칸\n\n"
               "지금 my.telegram.org 를 열까요?")
        if messagebox.askyesno("api 발급 방법", msg):
            try:
                webbrowser.open("https://my.telegram.org")
            except Exception:                               # noqa: BLE001
                pass

    api_fr = tk.Frame(adv)
    api_fr.grid(row=1, column=0, columnspan=3, sticky="w", pady=2)
    tk.Label(api_fr, text="api_id(숫자):").pack(side="left")
    e_apiid = tk.Entry(api_fr, width=16); e_apiid.pack(side="left", padx=(2, 10))
    e_apiid.insert(0, cfg.get("tg_api_id", ""))
    tk.Label(api_fr, text="api_hash:").pack(side="left")
    e_apihash = tk.Entry(api_fr, width=32); e_apihash.pack(side="left", padx=2)
    e_apihash.insert(0, cfg.get("tg_api_hash", ""))
    tk.Button(api_fr, text="❓발급방법", command=_show_api_help,
              fg="#06c").pack(side="left", padx=8)
    tk.Label(adv, text="[iCloud 캘린더 연동] 애플ID / 앱전용암호  — 아이폰 캘린더 쓸 때만. 안 쓰면 비워두세요.",
             font=("맑은 고딕", 9, "bold")).grid(row=5, column=0, columnspan=3, sticky="w", pady=(10, 0))
    e_icid = tk.Entry(adv, width=20); e_icid.grid(row=6, column=0, sticky="w", pady=2)
    e_icid.insert(0, cfg.get("icloud_id", ""))
    e_icpw = tk.Entry(adv, width=40, show="*"); e_icpw.grid(row=6, column=1, sticky="w", pady=2)
    e_icpw.insert(0, cfg.get("icloud_pw", ""))

    # ── 머리(AI) — 선택. 요약·사진 속 숫자 읽기·표 해석에만 씀. 없어도 나머지는 다 됨 ──
    tk.Label(adv, text="[머리(AI) 연결]  요약·사진읽기·표해석에만 씁니다. 없어도 검색·차트·발송은 다 됩니다.",
             font=("맑은 고딕", 9, "bold")).grid(row=7, column=0, columnspan=3, sticky="w", pady=(10, 0))

    # 어떤 머리를 쓸지: 자동 / 제미나이 무료 / 클로드 코드(구독) / 끔
    brain_fr = tk.Frame(adv)
    brain_fr.grid(row=8, column=0, columnspan=3, sticky="w", pady=2)
    tk.Label(brain_fr, text="머리 선택:").pack(side="left")
    brain_var = tk.StringVar(value=cfg.get("brain", "auto"))
    try:
        import brain_claude
        _has_claude = brain_claude.available()
    except Exception:                                       # noqa: BLE001
        _has_claude = False
    claude_label = "클로드 코드(구독)" + ("" if _has_claude else " — 미설치")
    for val, lab in [("auto", "자동"), ("gemini", "제미나이 무료"),
                     ("claude", claude_label), ("off", "끔")]:
        tk.Radiobutton(brain_fr, text=lab, variable=brain_var, value=val,
                       state=("normal" if (val != "claude" or _has_claude) else "disabled")
                       ).pack(side="left", padx=2)

    ai_fr = tk.Frame(adv)
    ai_fr.grid(row=9, column=0, columnspan=3, sticky="w", pady=2)
    tk.Label(ai_fr, text="Gemini 키:").pack(side="left")
    e_gem = tk.Entry(ai_fr, width=40, show="*"); e_gem.pack(side="left", padx=(2, 8))
    e_gem.insert(0, cfg.get("gemini_key", ""))
    _ai_status = tk.Label(adv, text="", fg="#0a7", font=("맑은 고딕", 9))
    if _has_claude:
        tk.Label(adv, text="↑ 클로드 프로/맥스가 있으면 '클로드 코드'를 고르세요 — 아델급 품질, 추가 비용 없음(구독).",
                 fg="#888", font=("맑은 고딕", 9)).grid(row=13, column=0, columnspan=3, sticky="w")

    def _gem_help():
        import webbrowser
        msg = ("Gemini 무료 키 발급 (구글 계정만 있으면 무료, 약 1분)\n\n"
               "1. aistudio.google.com/apikey 접속 → 구글 로그인\n"
               "2. 'Create API key' 클릭\n"
               "3. 나온 키(AIza… 로 시작)를 복사해 왼쪽 칸에 붙여넣기\n\n"
               "· 무료 한도 안에서만 씁니다. 한도를 다 쓰면 그날은 자동으로\n"
               "  규칙 기반(요약 없이 목록·집계)으로 내려가고 다음날 되살아납니다.\n"
               "· 키는 이 PC에만 저장되고 어디로도 전송되지 않습니다.\n\n"
               "지금 발급 페이지를 열까요?")
        if messagebox.askyesno("Gemini 키 발급 방법", msg):
            try:
                webbrowser.open("https://aistudio.google.com/apikey")
            except Exception:                               # noqa: BLE001
                pass

    def _gem_test():
        k = e_gem.get().strip()
        if not k:
            messagebox.showerror("머리 연결", "먼저 Gemini 키를 붙여넣으세요.")
            return
        _ai_status.config(text="확인 중…", fg="#666"); root.update_idletasks()
        try:
            import llm
            m = llm.pick_model(k)
        except Exception as e:                              # noqa: BLE001
            _ai_status.config(text=f"❌ 확인 실패: {type(e).__name__}", fg="#c00")
            return
        if m:
            _ai_status.config(text=f"✅ 연결됨 — {m.split('/')[-1]}", fg="#0a7")
        else:
            _ai_status.config(text="❌ 키가 틀렸거나 인터넷이 막혔어요", fg="#c00")

    tk.Button(ai_fr, text="❓발급방법", command=_gem_help, fg="#06c").pack(side="left")
    tk.Label(adv, text="[엑셀 암호]  암호 걸린 엑셀을 자동으로 열 때 씁니다. 여러 개면 쉼표로. (이 PC 에만 저장)",
             font=("맑은 고딕", 9, "bold")).grid(row=10, column=0, columnspan=3, sticky="w", pady=(10, 0))
    xl_fr = tk.Frame(adv)
    xl_fr.grid(row=11, column=0, columnspan=3, sticky="w", pady=2)
    tk.Label(xl_fr, text="엑셀 암호:").pack(side="left")
    e_xlpw = tk.Entry(xl_fr, width=30, show="*"); e_xlpw.pack(side="left", padx=(2, 8))
    e_xlpw.insert(0, cfg.get("xlsx_passwords", ""))
    photo_var = tk.IntVar(value=1 if cfg.get("ai_send_photos") else 0)
    tk.Checkbutton(adv, variable=photo_var,
                   text="사진도 AI 에 보내 표를 읽게 하기 (사진은 이름을 가릴 수 없습니다)").grid(
        row=12, column=0, columnspan=3, sticky="w", pady=(6, 0))
    tk.Button(ai_fr, text="연결 확인", command=_gem_test, bg="#2a7", fg="white",
              font=("맑은 고딕", 9, "bold")).pack(side="left", padx=6)
    _ai_status.grid(row=14, column=0, columnspan=3, sticky="w")

    # ── 텔레그램 개인계정 로그인(선택) — /find·/collect(대화 검색·취합) 쓰려면 최초 1회 ──
    _login_status = tk.Label(adv, text="", fg="#0a7", font=("맑은 고딕", 9))

    def _tg_login():
        aid, ah = e_apiid.get().strip(), e_apihash.get().strip()
        if not (aid.isdigit() and len(ah) >= 8):
            messagebox.showerror("텔레그램 로그인",
                "먼저 api_id(숫자)·api_hash 를 입력하세요.\n"
                "my.telegram.org → 로그인 → 'API development tools' 에서 무료 발급.")
            return
        phone = simpledialog.askstring("텔레그램 로그인",
                                       "전화번호 (국가코드 포함, 예: +821012345678)", parent=root)
        if not phone:
            return
        try:
            from telethon.sync import TelegramClient
            from telethon.errors import SessionPasswordNeededError
        except Exception as e:                              # noqa: BLE001
            messagebox.showerror("텔레그램 로그인", f"telethon 로드 실패: {e}")
            return
        sess = str(config.data_file("litebot_user"))
        client = None
        try:
            client = TelegramClient(sess, int(aid), ah)
            client.connect()
            if client.is_user_authorized():
                _login_status.config(text="✅ 이미 로그인돼 있어요")
                return
            client.send_code_request(phone)
            code = simpledialog.askstring("인증 코드",
                                          "텔레그램 앱/문자로 온 숫자 코드를 입력하세요.", parent=root)
            if not code:
                return
            try:
                client.sign_in(phone, code.strip())
            except SessionPasswordNeededError:
                pw = simpledialog.askstring("2단계 암호", "2단계 인증 암호를 입력하세요.",
                                            show="*", parent=root)
                client.sign_in(password=(pw or ""))
            if client.is_user_authorized():
                _login_status.config(text="✅ 로그인 성공 — /find·/collect 사용 가능")
                messagebox.showinfo("텔레그램 로그인",
                                    "로그인 성공! 저장하고 시작하면 /find·/collect 를 쓸 수 있어요.")
            else:
                _login_status.config(text="❌ 로그인 실패(코드 확인)")
        except Exception as e:                              # noqa: BLE001
            messagebox.showerror("텔레그램 로그인", f"실패: {type(e).__name__}: {e}")
            _login_status.config(text="❌ 로그인 실패")
        finally:
            try:
                if client:
                    client.disconnect()
            except Exception:                               # noqa: BLE001
                pass

    tk.Button(adv, text="📱 텔레그램 로그인", command=_tg_login, bg="#2a7", fg="white",
              font=("맑은 고딕", 10, "bold")).grid(row=2, column=0, columnspan=2, sticky="w", pady=(6, 2))
    _login_status.grid(row=3, column=0, columnspan=3, sticky="w")
    tk.Label(adv, text="↑ /find·/collect(대화 검색·취합) 쓰려면 로그인. 안 쓰면 비워도 됨.",
             fg="#888", font=("맑은 고딕", 9)).grid(row=4, column=0, columnspan=3, sticky="w", pady=(2, 0))

    # ⑥ 자동시작
    auto_var = tk.BooleanVar(value=bool(cfg.get("autostart", False)))
    tk.Checkbutton(root, text="컴퓨터 켤 때 자동 시작", variable=auto_var,
                   font=("맑은 고딕", 11)).grid(row=row, column=0, columnspan=3, sticky="w", **pad)
    row += 1

    def save():
        token = e_token.get().strip()
        chat = e_chat.get().strip()
        if not re.fullmatch(r"\d{6,}:[\w-]{20,}", token):
            messagebox.showerror("확인", "봇 토큰 형식이 올바르지 않아요.\n(예: 1234567890:AA...)")
            return
        if not chat.lstrip("-").isdigit():
            messagebox.showerror("확인", "chat_id 는 숫자여야 해요.")
            return
        if not re.fullmatch(r"\d{1,2}:\d{2}", e_brief.get().strip()):
            messagebox.showerror("확인", "브리핑 시각은 HH:MM 형식이어야 해요.")
            return
        cfg.update({
            "bot_token": token, "chat_id": chat,
            "town": e_town.get().strip() or "우리 동네",
            "lat": float(lat_var.get()), "lon": float(lon_var.get()),
            "briefing_time": e_brief.get().strip(),
            "autostart": bool(auto_var.get()),
            "tg_api_id": e_apiid.get().strip(), "tg_api_hash": e_apihash.get().strip(),
            "icloud_id": e_icid.get().strip(), "icloud_pw": e_icpw.get().strip(),
            "brain": brain_var.get(),
            "gemini_key": e_gem.get().strip(),
            "xlsx_passwords": e_xlpw.get().strip(),
            "ai_send_photos": bool(photo_var.get()),
        })
        config.save_config(cfg)
        autostart.apply(cfg["autostart"])
        saved["ok"] = True
        root.destroy()

    tk.Button(root, text="저장하고 시작", command=save, bg="#0e7a4b", fg="white",
              font=("맑은 고딕", 12, "bold"), width=20, height=1).grid(
        row=row, column=0, columnspan=3, pady=16)

    root.mainloop()
    return saved["ok"]


def open_settings():
    """설정 열기(트레이 메뉴) — 기존 값 불러와 편집. 간단히 마법사 재사용."""
    existing = config.load_config()
    if existing:
        # 기존값을 DEFAULTS 자리에 반영해 마법사가 채워 보이게
        config.DEFAULTS.update(existing)
    return run_wizard()
