# -*- coding: utf-8 -*-
"""'컴퓨터 켤 때 자동 시작' — 시작프로그램 폴더에 바로가기 생성/삭제.

pywin32 없이 PowerShell(WScript.Shell)로 .lnk 를 만든다(추가 의존성 없음).
exe(얼린 경우)는 exe 를, 스크립트면 pythonw + litebot.py 를 가리킨다.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

_MAC = sys.platform == "darwin"
STARTUP = Path(os.environ.get("APPDATA", "")) / "Microsoft/Windows/Start Menu/Programs/Startup"
LNK = STARTUP / "LiteBot.lnk"
PLIST = Path.home() / "Library" / "LaunchAgents" / "com.gangdong.litebot.plist"  # macOS


def _target() -> tuple[str, str]:
    """(target_path, arguments)"""
    if getattr(sys, "frozen", False):
        return sys.executable, ""
    pyw = Path(sys.executable).with_name("pythonw.exe")
    exe = str(pyw) if pyw.exists() else sys.executable
    return exe, f'"{Path(__file__).with_name("litebot.py")}"'


def is_enabled() -> bool:
    return PLIST.exists() if _MAC else LNK.exists()


def _mac_enable() -> bool:
    """맥: 로그인 시 자동 실행을 launchd(LaunchAgent plist)로 등록."""
    if getattr(sys, "frozen", False):
        prog = f"<string>{sys.executable}</string>"
    else:                                                    # 스크립트 실행
        prog = f"<string>{sys.executable}</string><string>{Path(__file__).with_name('litebot.py')}</string>"
    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
        '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
        '<plist version="1.0"><dict>\n'
        '  <key>Label</key><string>com.gangdong.litebot</string>\n'
        f'  <key>ProgramArguments</key><array>{prog}</array>\n'
        '  <key>RunAtLoad</key><true/>\n'
        '  <key>KeepAlive</key><false/>\n'
        '</dict></plist>\n')
    try:
        PLIST.parent.mkdir(parents=True, exist_ok=True)
        PLIST.write_text(xml, encoding="utf-8")
        subprocess.run(["launchctl", "load", str(PLIST)], capture_output=True, timeout=15)
        return PLIST.exists()
    except Exception:                                        # noqa: BLE001
        return False


def _mac_disable() -> bool:
    try:
        if PLIST.exists():
            subprocess.run(["launchctl", "unload", str(PLIST)], capture_output=True, timeout=15)
            PLIST.unlink()
        return not PLIST.exists()
    except Exception:                                        # noqa: BLE001
        return False


def enable() -> bool:
    if _MAC:
        return _mac_enable()
    tgt, args = _target()
    workdir = str(Path(tgt).parent if getattr(sys, "frozen", False) else Path(__file__).parent)
    ps = (
        f"$s=(New-Object -COM WScript.Shell).CreateShortcut('{LNK}');"
        f"$s.TargetPath='{tgt}';"
        + (f"$s.Arguments='{args}';" if args else "")
        + f"$s.WorkingDirectory='{workdir}';"
        f"$s.Save()"
    )
    try:
        STARTUP.mkdir(parents=True, exist_ok=True)
        subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                       capture_output=True, timeout=20, check=True)
        return LNK.exists()
    except Exception:                                        # noqa: BLE001
        return False


def disable() -> bool:
    if _MAC:
        return _mac_disable()
    try:
        if LNK.exists():
            LNK.unlink()
        return not LNK.exists()
    except Exception:                                        # noqa: BLE001
        return False


def apply(want: bool) -> bool:
    return enable() if want else disable()
