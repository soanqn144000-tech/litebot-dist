# -*- coding: utf-8 -*-
"""'컴퓨터 켤 때 자동 시작' — 시작프로그램 폴더에 바로가기 생성/삭제.

pywin32 없이 PowerShell(WScript.Shell)로 .lnk 를 만든다(추가 의존성 없음).
exe(얼린 경우)는 exe 를, 스크립트면 pythonw + litebot.py 를 가리킨다.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

STARTUP = Path(os.environ.get("APPDATA", "")) / "Microsoft/Windows/Start Menu/Programs/Startup"
LNK = STARTUP / "LiteBot.lnk"


def _target() -> tuple[str, str]:
    """(target_path, arguments)"""
    if getattr(sys, "frozen", False):
        return sys.executable, ""
    pyw = Path(sys.executable).with_name("pythonw.exe")
    exe = str(pyw) if pyw.exists() else sys.executable
    return exe, f'"{Path(__file__).with_name("litebot.py")}"'


def is_enabled() -> bool:
    return LNK.exists()


def enable() -> bool:
    tgt, args = _target()
    workdir = str(Path(tgt).parent if getattr(sys, "frozen", False) else Path(__file__).parent)
    ps = (
        f"$s=(New-Object -COM WScript.Shell).CreateShortcut('{LNK}');"
        f"$s.TargetPath='{tgt}';"
        + (f"$s.Arguments='{args}';" if args else "")
        + f"$s.WorkingDirectory='{workdir}';"
        f"$s.Save()"
    )
    try:
        STARTUP.mkdir(parents=True, exist_ok=True)
        subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                       capture_output=True, timeout=20, check=True)
        return LNK.exists()
    except Exception:                                        # noqa: BLE001
        return False


def disable() -> bool:
    try:
        if LNK.exists():
            LNK.unlink()
        return not LNK.exists()
    except Exception:                                        # noqa: BLE001
        return False


def apply(want: bool) -> bool:
    return enable() if want else disable()
