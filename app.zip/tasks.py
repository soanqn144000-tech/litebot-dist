# -*- coding: utf-8 -*-
"""④ 반복 예약업무 — data/tasks.json.

  /task 추가 매일 09:00 출결 마감 리마인더 보내기
  /task 추가 매시간 정각 <메시지>
  /task            → 목록
  /task 삭제 <번호>

실제 발송은 scheduler.py 가 tick 마다 due() 로 검사해서 처리.
"""
from __future__ import annotations

import re

import config

TASKS = "tasks.json"


def _load() -> list[dict]:
    return config.read_json(TASKS, [])


def _save(items: list[dict]) -> None:
    config.write_json(TASKS, items)


def _fmt(it: dict, idx: int) -> str:
    if it["kind"] == "daily":
        when = f"매일 {it['time']}"
    else:
        when = "매시간 정각"
    return f"{idx}. [{when}] {it['message']}"


def handle(args: list[str]) -> str:
    if not args:
        items = _load()
        if not items:
            return "등록된 반복업무가 없어요.\n예: /task 추가 매일 09:00 출결 마감 알림"
        return "⏰ 반복업무\n" + "\n".join(_fmt(it, i + 1) for i, it in enumerate(items))

    sub = args[0]
    if sub == "추가":
        rest = args[1:]
        if not rest:
            return "형식: /task 추가 매일 09:00 <메시지>  또는  /task 추가 매시간 정각 <메시지>"
        if rest[0] in ("매일", "daily"):
            if len(rest) < 3 or not re.fullmatch(r"\d{1,2}:\d{2}", rest[1]):
                return "형식: /task 추가 매일 09:00 <메시지>"
            h, m = map(int, rest[1].split(":"))
            if not (0 <= h < 24 and 0 <= m < 60):
                return "시각이 이상해요 (00:00~23:59)."
            msg = " ".join(rest[2:]).strip()
            if not msg:
                return "보낼 메시지가 없어요."
            items = _load()
            items.append({"id": _next_id(items), "kind": "daily",
                          "time": f"{h:02d}:{m:02d}", "message": msg})
            _save(items)
            return f"✅ 등록: 매일 {h:02d}:{m:02d} — {msg}"
        if rest[0] in ("매시간", "hourly"):
            # '정각' 토큰은 선택
            body = rest[1:]
            if body and body[0] == "정각":
                body = body[1:]
            msg = " ".join(body).strip()
            if not msg:
                return "보낼 메시지가 없어요. 예: /task 추가 매시간 정각 물 마시기"
            items = _load()
            items.append({"id": _next_id(items), "kind": "hourly", "message": msg})
            _save(items)
            return f"✅ 등록: 매시간 정각 — {msg}"
        return "매일 또는 매시간만 지원해요. 예: /task 추가 매일 09:00 <메시지>"

    if sub in ("삭제", "del"):
        if len(args) < 2 or not args[1].isdigit():
            return "형식: /task 삭제 <번호>"
        n = int(args[1])
        items = _load()
        if not (1 <= n <= len(items)):
            return f"{n}번 업무가 없어요."
        gone = items.pop(n - 1)
        _save(items)
        return f"🗑 삭제: {gone['message']}"

    return "사용법: /task · /task 추가 매일 09:00 <메시지> · /task 삭제 <번호>"


def _next_id(items) -> int:
    return max([i.get("id", 0) for i in items], default=0) + 1


def due(now) -> list[str]:
    """지금(now=datetime) 발송해야 할 반복업무 메시지 목록.
    분 단위로 한 번만 매칭되도록 scheduler 가 분이 바뀔 때만 호출한다."""
    out = []
    hhmm = now.strftime("%H:%M")
    for it in _load():
        if it["kind"] == "daily" and it["time"] == hhmm:
            out.append(f"⏰ {it['message']}")
        elif it["kind"] == "hourly" and now.minute == 0:
            out.append(f"⏰ {it['message']}")
    return out
