# -*- coding: utf-8 -*-
"""④ 반복 예약업무 — data/tasks.json.

  /task 추가 매일 09:00 출결 마감 리마인더 보내기
  /task 추가 매시간 정각 <메시지>
  /task            → 목록
  /task 삭제 <번호>

실제 발송은 scheduler.py 가 tick 마다 due() 로 검사해서 처리.
"""
from __future__ import annotations

import re

import config

TASKS = "tasks.json"


def _load() -> list[dict]:
    return config.read_json(TASKS, [])


def _save(items: list[dict]) -> None:
    config.write_json(TASKS, items)


def _fmt(it: dict, idx: int) -> str:
    if it["kind"] == "daily":
        when = f"매일 {it['time']}"
    elif it["kind"] == "weekly":
        when = f"매주 {WD[it.get('weekday', 0)]}요일 {it['time']}"
    else:
        when = "매시간 정각"
    return f"{idx}. [{when}] {it['message']}"


# ── 말로 쓴 반복업무 읽기 ────────────────────────────────────────────────────
_KIND = {"매일": "daily", "날마다": "daily", "매일매일": "daily",
         "매시간": "hourly", "한시간마다": "hourly", "시간마다": "hourly",
         "매주": "weekly", "주마다": "weekly"}
WD = "월화수목금토일"
_RE_WD = re.compile(r"([월화수목금토일])\s*요일")
_RE_HM = re.compile(r"(?<!\d)([0-2]?\d)\s*:\s*([0-5]\d)(?!\d)\s*(?:까지|부터|에|경)?")
_RE_H_KO = re.compile(r"(오전|오후|아침|저녁|밤)?\s*([0-2]?\d)\s*시\s*(?:([0-5]?\d)\s*분|(반))?\s*(?:까지|부터|에|경)?")
_NOISE = re.compile(r"(반복(업무)?|예약|알림|리마인드|등록해?\s*줘?|추가해?\s*줘?|"
                    r"알려\s*줘?|챙겨\s*줘?|보내\s*줘?|해\s*줘?|"
                    r"매일|날마다|매주|주마다|매시간|시간마다|아침마다|저녁마다|정각)")
# 걷어낸 자리에 조사만 남는다 — "매시간 정각에 물" → "에 물". 앞뒤 조사를 털어낸다.
_STRAY = re.compile(r"^(에서|에|은|는|이|가|을|를|로|으로|도|만)\s+|\s+(에서|에|은|는|이|가|을|를|로|으로)$")


def parse_task(text: str) -> tuple[str, str, str, str, int]:
    """말로 쓴 한 줄 → (kind, 시각, 메시지, 못 읽은 이유, 요일). kind 는 daily|hourly|weekly.

    요일은 weekly 일 때만 의미 있다(월=0 … 주일=6). 아니면 -1."""
    t = " " + (text or "").strip() + " "
    kind = ""
    for word, k in _KIND.items():
        if word in t:
            kind = k
            break
    if not kind:
        return "", "", "", "", -1                            # 규칙이 못 읽음 — 머리가 볼 차례

    wd = -1
    if kind == "weekly":
        m = _RE_WD.search(t)
        if not m:
            return "", "", "", "무슨 요일인지 알려주세요 (예: 매주 화요일 22:00 …)", -1
        wd = WD.index(m.group(1))
        t = t[:m.start()] + " " + t[m.end():]

    tm = ""
    if kind in ("daily", "weekly"):
        m = _RE_HM.search(t)
        if m:
            h, mi = int(m.group(1)), int(m.group(2))
            if h < 24:
                tm = f"{h:02d}:{mi:02d}"
                t = t[:m.start()] + " " + t[m.end():]
        if not tm:
            m = _RE_H_KO.search(t)
            if m:
                ampm, h = m.group(1), int(m.group(2))
                mi = int(m.group(3)) if m.group(3) else (30 if m.group(4) else 0)
                if ampm in ("오후", "저녁", "밤") and h < 12:
                    h += 12
                if h < 24:
                    tm = f"{h:02d}:{mi:02d}"
                    t = t[:m.start()] + " " + t[m.end():]
        if not tm:
            return "", "", "", "몇 시에 보낼지 알려주세요 (예: 매일 09:00 출결 마감 알림)", -1

    msg = re.sub(r"\s+", " ", _NOISE.sub(" ", t)).strip(" .,·~!?")
    for _ in range(2):                                       # "에 물" 처럼 조사만 남은 것 털기
        msg = _STRAY.sub("", msg).strip(" .,·~!?")
    if not msg:
        return kind, tm, "", "보낼 내용이 없어요. 무슨 알림인가요?", wd
    return kind, tm, msg, "", wd


_LLM_PROMPT = """아래 한 줄에서 '되풀이되는 알림' 정보를 뽑아 JSON 하나만 출력해라. 설명·``` 금지.

{{"kind": "daily" 또는 "weekly" 또는 "hourly" 또는 null,
  "time": "HH:MM" (daily·weekly 일 때만, 아니면 ""),
  "weekday": 0~6 (weekly 일 때만. 월=0 화=1 수=2 목=3 금=4 토=5 주일=6). 아니면 null,
  "message": "보낼 내용 (명령어·주기 표현 빼고)"}}

- 매일이면 daily, 매주면 weekly, 매시간이면 hourly. 다 아니면 kind 를 null 로.
- 문장에 없는 것을 지어내지 마라. 시각이 없으면 time 을 "" 로 둬라.

문장: {text}
"""


def parse_task_smart(cfg: dict, text: str) -> tuple[str, str, str, str, int]:
    """규칙이 먼저, 놓친 것만 머리가 채운다."""
    kind, tm, msg, why, wd = parse_task(text)
    done = kind and msg and (kind == "hourly" or tm) and (kind != "weekly" or wd >= 0)
    if done:
        return kind, tm, msg, "", wd

    import nlu
    fallback = why or "매일 몇 시인지, 매주 무슨 요일인지, 또는 매시간인지 알려주세요."
    if not nlu.available(cfg):
        return kind, tm, msg, fallback, wd
    obj = nlu.ask_json(cfg, _LLM_PROMPT.format(text=text))
    if not obj:
        return kind, tm, msg, fallback, wd

    k = str(obj.get("kind") or "").strip()
    if not kind and k in ("daily", "weekly", "hourly"):
        kind = k
    if not tm:
        tm = nlu.time_or_empty(obj.get("time"))
    if wd < 0:
        try:
            w = int(obj.get("weekday"))
            wd = w if 0 <= w <= 6 else -1
        except (TypeError, ValueError):
            wd = -1
    if not msg:
        msg = nlu.text_or_empty(obj.get("message"))

    if kind not in ("daily", "weekly", "hourly"):
        return "", "", "", "되풀이 주기를 못 읽었어요 (예: 매일 09:00 / 매주 화요일 22:00 / 매시간)", -1
    if kind in ("daily", "weekly") and not tm:
        return "", "", "", "몇 시에 보낼지 알려주세요 (예: 매주 화요일 22:00 …)", -1
    if kind == "weekly" and wd < 0:
        return "", "", "", "무슨 요일인지 알려주세요 (예: 매주 화요일 22:00 …)", -1
    if not msg:
        return kind, tm, "", "보낼 내용이 없어요. 무슨 알림인가요?", wd
    return kind, tm, msg, "", wd


def handle(args: list[str], cfg: dict | None = None) -> str:
    if not args:
        items = _load()
        if not items:
            return "등록된 반복업무가 없어요.\n예: /task 추가 매일 09:00 출결 마감 알림"
        return "⏰ 반복업무\n" + "\n".join(_fmt(it, i + 1) for i, it in enumerate(items))

    sub = args[0]
    if sub == "추가":
        rest = args[1:]
        if not rest:
            return "형식: /task 추가 매일 09:00 <메시지>  또는  /task 추가 매시간 정각 <메시지>"
        if rest[0] not in ("매일", "daily", "매시간", "hourly"):
            # 또박또박 안 쓰셨으면 문장으로 읽는다 — "매일 아침 9시에 출결 취합 알려줘"
            kind, tm, msg, why, wd = parse_task_smart(cfg or {}, " ".join(rest))
            if why:
                return why
            items = _load()
            it = {"id": _next_id(items), "kind": kind, "message": msg}
            if kind in ("daily", "weekly"):
                it["time"] = tm
            if kind == "weekly":
                it["weekday"] = wd
            items.append(it)
            _save(items)
            when = ("매일 " + tm if kind == "daily" else
                    f"매주 {WD[wd]}요일 {tm}" if kind == "weekly" else "매시간 정각")
            return f"✅ 등록: {when} — {msg}"
        if rest[0] in ("매일", "daily"):
            if len(rest) < 3 or not re.fullmatch(r"\d{1,2}:\d{2}", rest[1]):
                return "형식: /task 추가 매일 09:00 <메시지>"
            h, m = map(int, rest[1].split(":"))
            if not (0 <= h < 24 and 0 <= m < 60):
                return "시각이 이상해요 (00:00~23:59)."
            msg = " ".join(rest[2:]).strip()
            if not msg:
                return "보낼 메시지가 없어요."
            items = _load()
            items.append({"id": _next_id(items), "kind": "daily",
                          "time": f"{h:02d}:{m:02d}", "message": msg})
            _save(items)
            return f"✅ 등록: 매일 {h:02d}:{m:02d} — {msg}"
        if rest[0] in ("매시간", "hourly"):
            # '정각' 토큰은 선택
            body = rest[1:]
            if body and body[0] == "정각":
                body = body[1:]
            msg = " ".join(body).strip()
            if not msg:
                return "보낼 메시지가 없어요. 예: /task 추가 매시간 정각 물 마시기"
            items = _load()
            items.append({"id": _next_id(items), "kind": "hourly", "message": msg})
            _save(items)
            return f"✅ 등록: 매시간 정각 — {msg}"
        return "매일 또는 매시간만 지원해요. 예: /task 추가 매일 09:00 <메시지>"

    if sub in ("삭제", "del"):
        if len(args) < 2 or not args[1].isdigit():
            return "형식: /task 삭제 <번호>"
        n = int(args[1])
        items = _load()
        if not (1 <= n <= len(items)):
            return f"{n}번 업무가 없어요."
        gone = items.pop(n - 1)
        _save(items)
        return f"🗑 삭제: {gone['message']}"

    return "사용법: /task · /task 추가 매일 09:00 <메시지> · /task 삭제 <번호>"


def _next_id(items) -> int:
    return max([i.get("id", 0) for i in items], default=0) + 1


def due(now) -> list[str]:
    """지금(now=datetime) 발송해야 할 반복업무 메시지 목록.
    분 단위로 한 번만 매칭되도록 scheduler 가 분이 바뀔 때만 호출한다."""
    out = []
    hhmm = now.strftime("%H:%M")
    for it in _load():
        if it["kind"] == "daily" and it["time"] == hhmm:
            out.append(f"⏰ {it['message']}")
        elif it["kind"] == "weekly" and it.get("time") == hhmm \
                and now.weekday() == it.get("weekday"):
            out.append(f"⏰ {it['message']}")
        elif it["kind"] == "hourly" and now.minute == 0:
            out.append(f"⏰ {it['message']}")
    return out
