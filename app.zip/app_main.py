# -*- coding: utf-8 -*-
"""LiteBot 실행 본체(app 번들) — 런처(launcher.py)가 업데이트 확인 후 이걸 불러 실행한다.

  - 인자 --settings : 설정 창만 띄우고 종료
  - config.json 없으면 → 설정 마법사 → 저장 후 시작
  - 있으면 → 봇(백그라운드 스레드) + 트레이(메인 스레드)

이 폴더(app/)의 .py 들이 '중앙에서 자동 업데이트'되는 부분이다.
"""
from __future__ import annotations

import socket
import sys
import threading
import time

import config

log = config.get_logger()

_SINGLE_LOCK = None                                        # 프로세스 생존 동안 소켓을 잡아둔다(GC 방지)


LOCK_PORT = 47615


def _acquire_single_instance(wait_sec: float = 15.0, port: int = LOCK_PORT) -> bool:
    """이미 LiteBot 이 떠 있으면 False. 로컬 포트 bind 로 판정 — 죽으면 자동 해제.

    방금 종료한 프로세스가 포트를 놓는 데 몇 초 걸린다. 그래서 곧바로 포기하지 않고
    잠깐 기다렸다 다시 잡아본다(종료 직후 더블클릭이 '아무 반응 없이' 죽던 원인).
    """
    global _SINGLE_LOCK
    deadline = time.time() + wait_sec
    waited = False
    while True:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(("127.0.0.1", port))
            s.listen(1)
            _SINGLE_LOCK = s
            if waited:
                log.info("앞 프로세스 종료를 기다린 뒤 시작")
            return True
        except OSError:
            s.close()
            if time.time() >= deadline:
                return False
            waited = True
            time.sleep(0.5)


def _already_running_notice() -> None:
    """조용히 죽지 않는다 — 왜 안 뜨는지 사용자에게 알려준다."""
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk(); root.withdraw()
        messagebox.showinfo("LiteBot", "LiteBot 은 이미 실행 중입니다.\n\n"
                                       "화면 오른쪽 아래 트레이(^) 에서 아이콘을 확인하세요.\n"
                                       "완전히 끄려면 트레이 아이콘 우클릭 → 종료.")
        root.destroy()
    except Exception:                                        # noqa: BLE001
        pass


def _release_lock() -> None:
    global _SINGLE_LOCK
    try:
        if _SINGLE_LOCK is not None:
            _SINGLE_LOCK.close()
    except Exception:                                        # noqa: BLE001
        pass
    _SINGLE_LOCK = None


def _run_settings_only() -> int:
    import wizard
    wizard.open_settings()
    return 0


def main() -> int:
    if "--settings" in sys.argv:
        return _run_settings_only()

    if not _acquire_single_instance():                    # 진짜로 떠 있으면(15초 기다려도) 알리고 종료
        log.info("이미 실행 중 — 두 번째 인스턴스 종료")
        _already_running_notice()
        return 0

    config.ensure_dirs()
    cfg = config.load_config()

    if not cfg or not cfg.get("bot_token") or not cfg.get("chat_id"):
        import wizard
        if not wizard.run_wizard():
            log.info("설정 취소 — 종료")
            return 0
        cfg = config.load_config()
        if not cfg or not cfg.get("bot_token"):
            return 0

    import bot
    import tray

    token = cfg["bot_token"]
    bot_thread = threading.Thread(target=bot.run_bot, args=(token,), daemon=True)
    bot_thread.start()
    log.info("봇 스레드 시작 (버전 %s)", config.app_version())

    def on_quit():
        log.info("종료 절차 시작")
        _release_lock()                                      # 포트를 즉시 놓아준다(바로 재실행 가능하게)

    try:
        tray.run_tray(on_quit)
    except Exception as e:                                   # noqa: BLE001
        log.error("트레이 실행 오류 — %s", e, exc_info=True)
        bot_thread.join()

    log.info("LiteBot 종료")
    import os
    os._exit(0)
    return 0


if __name__ == "__main__":
    sys.exit(main())
