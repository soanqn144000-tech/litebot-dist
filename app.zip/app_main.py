# -*- coding: utf-8 -*-
"""LiteBot 실행 본체(app 번들) — 런처(launcher.py)가 업데이트 확인 후 이걸 불러 실행한다.

  - 인자 --settings : 설정 창만 띄우고 종료
  - config.json 없으면 → 설정 마법사 → 저장 후 시작
  - 있으면 → 봇(백그라운드 스레드) + 트레이(메인 스레드)

이 폴더(app/)의 .py 들이 '중앙에서 자동 업데이트'되는 부분이다.
"""
from __future__ import annotations

import sys
import threading

import config

log = config.get_logger()


def _run_settings_only() -> int:
    import wizard
    wizard.open_settings()
    return 0


def main() -> int:
    if "--settings" in sys.argv:
        return _run_settings_only()

    config.ensure_dirs()
    cfg = config.load_config()

    if not cfg or not cfg.get("bot_token") or not cfg.get("chat_id"):
        import wizard
        if not wizard.run_wizard():
            log.info("설정 취소 — 종료")
            return 0
        cfg = config.load_config()
        if not cfg or not cfg.get("bot_token"):
            return 0

    import bot
    import tray

    token = cfg["bot_token"]
    bot_thread = threading.Thread(target=bot.run_bot, args=(token,), daemon=True)
    bot_thread.start()
    log.info("봇 스레드 시작 (버전 %s)", config.app_version())

    def on_quit():
        log.info("종료 절차 시작")

    try:
        tray.run_tray(on_quit)
    except Exception as e:                                   # noqa: BLE001
        log.error("트레이 실행 오류 — %s", e, exc_info=True)
        bot_thread.join()

    log.info("LiteBot 종료")
    import os
    os._exit(0)
    return 0


if __name__ == "__main__":
    sys.exit(main())
