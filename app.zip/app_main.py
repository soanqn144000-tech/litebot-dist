# -*- coding: utf-8 -*-
"""LiteBot 실행 본체(app 번들) — 런처(launcher.py)가 업데이트 확인 후 이걸 불러 실행한다.

  - 인자 --settings : 설정 창만 띄우고 종료
  - config.json 없으면 → 설정 마법사 → 저장 후 시작
  - 있으면 → 봇(백그라운드 스레드) + 트레이(메인 스레드)

이 폴더(app/)의 .py 들이 '중앙에서 자동 업데이트'되는 부분이다.
"""
from __future__ import annotations

import socket
import sys
import threading
import time

import config

log = config.get_logger()

_SINGLE_LOCK = None                                        # 프로세스 생존 동안 소켓을 잡아둔다(GC 방지)


LOCK_PORT = 47615


def _acquire_single_instance(wait_sec: float = 15.0, port: int = LOCK_PORT) -> bool:
    """이미 LiteBot 이 떠 있으면 False. 로컬 포트 bind 로 판정 — 죽으면 자동 해제.

    방금 종료한 프로세스가 포트를 놓는 데 몇 초 걸린다. 그래서 곧바로 포기하지 않고
    잠깐 기다렸다 다시 잡아본다(종료 직후 더블클릭이 '아무 반응 없이' 죽던 원인).
    """
    global _SINGLE_LOCK
    deadline = time.time() + wait_sec
    waited = False
    while True:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(("127.0.0.1", port))
            s.listen(1)
            _SINGLE_LOCK = s
            if waited:
                log.info("앞 프로세스 종료를 기다린 뒤 시작")
            return True
        except OSError:
            s.close()
            if time.time() >= deadline:
                return False
            waited = True
            time.sleep(0.5)


def _already_running_notice() -> None:
    """조용히 죽지 않는다 — 왜 안 뜨는지 사용자에게 알려준다."""
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk(); root.withdraw()
        messagebox.showinfo("LiteBot", "LiteBot 은 이미 실행 중입니다.\n\n"
                                       "화면 오른쪽 아래 트레이(^) 에서 아이콘을 확인하세요.\n"
                                       "완전히 끄려면 트레이 아이콘 우클릭 → 종료.")
        root.destroy()
    except Exception:                                        # noqa: BLE001
        pass


def _release_lock() -> None:
    global _SINGLE_LOCK
    try:
        if _SINGLE_LOCK is not None:
            _SINGLE_LOCK.close()
    except Exception:                                        # noqa: BLE001
        pass
    _SINGLE_LOCK = None


def _gui_ok() -> bool:
    """설정 '창'을 띄울 수 있는 컴퓨터인가.

    맥에 기본으로 깔린 파이썬(3.9)의 Tk 8.5 는 요즘 macOS 에서 라벨·입력칸을 아예 안 그린다
    (2026-08-09 확인: 빨간 배경 라벨조차 안 보였다). 창은 떴는데 안이 비어 있으니
    봇 토큰조차 못 넣는다 = 맥 쓰는 사람은 LiteBot 을 아예 못 쓴다.
    그래서 '창이 뜨나'가 아니라 '제대로 그려지나'까지 본다. 아니면 터미널 설정으로 간다.
    """
    try:
        import tkinter as tk
    except Exception:                                      # noqa: BLE001 — tkinter 없는 배포판
        return False
    try:
        r = tk.Tk()
        ver = float(r.tk.call("info", "patchlevel").rsplit(".", 1)[0])
        r.destroy()
    except Exception:                                      # noqa: BLE001 — 화면 없는 환경(SSH 등)
        return False
    return ver >= 8.6                                      # 8.5 는 위 이유로 못 씀


def _setup(initial: bool) -> bool:
    """설정 받기 — 창이 되면 창, 안 되면 터미널 질문식. 묻는 것도 결과도 같다."""
    if _gui_ok():
        import wizard
        if initial:
            return wizard.run_wizard()
        wizard.open_settings()
        return True
    import setup_cli
    log.info("설정 창을 못 쓰는 환경(Tk 8.5 등) — 터미널 설정으로 진행")
    return setup_cli.run_setup()


def _run_settings_only() -> int:
    _setup(initial=False)
    return 0


def _selfcheck() -> int:
    """설치본이 실제로 멀쩡한지 화면 없이 점검하고 logs/selfcheck.txt 에 적는다.

      LiteBot.exe --selfcheck [암호걸린엑셀경로]

    빌드해서 배포하기 전에 이걸 돌려본다. v1.5.1 처럼 '켜자마자 죽는' exe 를 보내는 사고 방지용.
    """
    lines = []
    for m in ("config", "bot", "wizard", "tray", "chart", "extract", "llm", "privacy",
              "route", "compose", "search", "sender", "tasks", "weather", "cal",
              "telegram", "telethon", "matplotlib", "pystray", "caldav", "requests",
              "msoffcrypto", "pkg_resources"):
        try:
            __import__(m)
            lines.append(f"{m}: OK")
        except Exception as e:                               # noqa: BLE001
            lines.append(f"{m}: FAIL {type(e).__name__}: {e}")

    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if args:                                                 # 암호 걸린 엑셀로 실제 해제까지 시험
        import extract
        try:
            data = open(args[0], "rb").read()
            dec, pw = extract.decrypt_xlsx(data, ["0114", "198403!", "198403"])
            if dec:
                txt = extract.xlsx_to_text(dec)
                lines.append(f"복호화: OK (암호 {pw}) → 표 {len(txt or '')}자")
            else:
                lines.append("복호화: FAIL (아는 암호로 안 열림 / 암호 안 걸린 파일)")
        except Exception as e:                               # noqa: BLE001
            lines.append(f"복호화: FAIL {type(e).__name__}: {e}")

    out = config.LOG_DIR / "selfcheck.txt"
    config.ensure_dirs()
    out.write_text("\n".join(lines), encoding="utf-8")
    log.info("selfcheck 완료 → %s", out)
    return 0


def main() -> int:
    if "--selfcheck" in sys.argv:
        return _selfcheck()
    if "--settings" in sys.argv:
        return _run_settings_only()

    if not _acquire_single_instance():                    # 진짜로 떠 있으면(15초 기다려도) 알리고 종료
        log.info("이미 실행 중 — 두 번째 인스턴스 종료")
        _already_running_notice()
        return 0

    config.ensure_dirs()
    cfg = config.load_config()

    if not cfg or not cfg.get("bot_token") or not cfg.get("chat_id"):
        if not _setup(initial=True):
            log.info("설정 취소 — 종료")
            return 0
        cfg = config.load_config()
        if not cfg or not cfg.get("bot_token"):
            return 0

    import bot

    token = cfg["bot_token"]
    bot_thread = threading.Thread(target=bot.run_bot, args=(token,), daemon=True)
    bot_thread.start()
    log.info("봇 스레드 시작 (버전 %s)", config.app_version())

    def on_quit():
        log.info("종료 절차 시작")
        _release_lock()                                      # 포트를 즉시 놓아준다(바로 재실행 가능하게)

    headless = "--headless" in sys.argv                      # 트레이 없이 백그라운드로(맥/서버)
    tray = None
    if not headless:
        try:
            import tray as _tray
            tray = _tray
        except Exception as e:                               # noqa: BLE001
            log.error("트레이 로드 실패 — 백그라운드로 계속 — %s", e)
    if tray is not None:
        try:
            tray.run_tray(on_quit)                           # 여기서 블로킹(트레이 종료까지)
        except Exception as e:                               # noqa: BLE001
            log.error("트레이 실행 오류 — 백그라운드로 계속 — %s", e, exc_info=True)
            bot_thread.join()
    else:
        log.info("헤드리스 모드 — 봇만 돈다(종료는 프로세스 종료로)")
        bot_thread.join()                                    # 봇 폴링이 끝날 때까지(사실상 영구)

    log.info("LiteBot 종료")
    import os
    os._exit(0)
    return 0


if __name__ == "__main__":
    sys.exit(main())
