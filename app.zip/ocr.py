# -*- coding: utf-8 -*-
"""사진 속 글자 읽기 — 맥에 원래 들어있는 판독기(Apple Vision)를 쓴다.

왜 이걸 쓰나:
  · 공짜다. 구독이 끊겨도 계속 된다.
  · 인터넷이 필요 없다. 사진이 밖으로 안 나간다.
  · 한국어를 읽는다(ko-KR 지원 확인).

머리(AI)한테 사진을 보내 읽히는 길도 있지만 그건 유료다. 여기는 그 대안이다.
맥이 아니면 조용히 못 쓴다고 답한다(윈도우 교인용은 아직 없음).
"""
from __future__ import annotations

import sys


def available() -> bool:
    """이 기기에서 사진 판독이 되나."""
    if sys.platform != "darwin":
        return False
    try:
        import Vision  # noqa: F401
        import Quartz  # noqa: F401
    except Exception:                                          # noqa: BLE001
        return False
    return True


def read_image(data: bytes, langs: tuple[str, ...] = ("ko-KR", "en-US")) -> tuple[str | None, str]:
    """사진 → 글자. 돌려주는 것: (글자, 안 되면 사유).

    글자는 사진에 찍힌 순서가 아니라 **위에서 아래, 왼쪽에서 오른쪽** 으로 정렬해서 준다.
    표 사진은 그래야 줄이 안 섞인다.
    """
    if not available():
        return None, "이 기기에서는 사진 판독을 못 해요(맥에서만 됩니다)."
    try:
        import Quartz
        import Vision
        from Foundation import NSData

        nsdata = NSData.dataWithBytes_length_(data, len(data))
        src = Quartz.CGImageSourceCreateWithData(nsdata, None)
        if src is None or Quartz.CGImageSourceGetCount(src) < 1:
            return None, "사진을 못 열었어요."
        img = Quartz.CGImageSourceCreateImageAtIndex(src, 0, None)

        req = Vision.VNRecognizeTextRequest.alloc().init()
        req.setRecognitionLevel_(0)                            # 0=정확 우선, 1=속도 우선
        req.setUsesLanguageCorrection_(True)
        req.setRecognitionLanguages_(list(langs))

        handler = Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(img, None)
        ok, err = handler.performRequests_error_([req], None)
        if not ok:
            return None, f"판독 실패: {err}"

        lines = []
        for obs in (req.results() or []):
            cand = obs.topCandidates_(1)
            if not cand:
                continue
            box = obs.boundingBox()                            # 왼쪽아래 기준(0~1)
            y = 1.0 - box.origin.y                             # 위에서부터의 거리로 뒤집는다
            lines.append((y, box.origin.x, cand[0].string()))
        if not lines:
            return None, "사진에서 글자를 못 찾았어요."

        # 같은 줄로 볼 만큼 y 가 가까우면 한 줄로 묶는다(표는 칸이 옆으로 늘어선다)
        lines.sort(key=lambda t: (t[0], t[1]))
        out, cur, cur_y = [], [], lines[0][0]
        for y, x, s in lines:
            if abs(y - cur_y) > 0.012:                         # 줄바뀜 기준
                out.append(" ".join(cur))
                cur, cur_y = [], y
            cur.append(s)
        out.append(" ".join(cur))
        return "\n".join(out), ""
    except Exception as e:                                      # noqa: BLE001
        return None, f"판독 중 오류: {type(e).__name__}: {e}"


if __name__ == "__main__":
    import pathlib
    txt, err = read_image(pathlib.Path(sys.argv[1]).read_bytes())
    print(txt or f"[안 됨] {err}")
