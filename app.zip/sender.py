# -*- coding: utf-8 -*-
"""⑤ 공지·메시지 발송/예약 + 별칭 — data/scheduled.json, data/aliases.json.

  /send 지금 <chat_id 또는 별칭> <메시지>
  /send 예약 7/25 09:00 <별칭> <메시지>
  /alias 추가 부과장 123456789
  /alias            → 목록
  /alias 삭제 부과장

즉시 발송은 bot 이 직접(async), 예약은 scheduler 가 due 검사.
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

import config

SCHED = "scheduled.json"
ALIAS = "aliases.json"


def _aliases() -> dict:
    return config.read_json(ALIAS, {})


def resolve(target: str) -> str | None:
    """별칭 또는 숫자 chat_id → chat_id 문자열."""
    if target.lstrip("-").isdigit():
        return target
    a = _aliases()
    return a.get(target)


def alias_handle(args: list[str]) -> str:
    if not args:
        a = _aliases()
        if not a:
            return "등록된 별칭이 없어요.\n예: /alias 추가 부과장 123456789"
        return "👤 별칭\n" + "\n".join(f"· {k} → {v}" for k, v in a.items())
    sub = args[0]
    if sub == "추가":
        if len(args) < 3 or not args[2].lstrip("-").isdigit():
            return "형식: /alias 추가 <이름> <chat_id(숫자)>"
        a = _aliases(); a[args[1]] = args[2]; config.write_json(ALIAS, a)
        return f"✅ 별칭 등록: {args[1]} → {args[2]}"
    if sub in ("삭제", "del"):
        if len(args) < 2:
            return "형식: /alias 삭제 <이름>"
        a = _aliases()
        if args[1] not in a:
            return f"'{args[1]}' 별칭이 없어요."
        a.pop(args[1]); config.write_json(ALIAS, a)
        return f"🗑 별칭 삭제: {args[1]}"
    return "사용법: /alias · /alias 추가 <이름> <id> · /alias 삭제 <이름>"


def _parse_dt(dtok: str, ttok: str) -> str | None:
    m = re.fullmatch(r"(\d{1,2})[/.](\d{1,2})", dtok)
    tm = re.fullmatch(r"(\d{1,2}):(\d{2})", ttok)
    if not (m and tm):
        return None
    mo, d = map(int, m.groups()); h, mi = map(int, tm.groups())
    y = date.today().year
    try:
        dd = date(y, mo, d)
        if dd < date.today() - timedelta(days=180):
            dd = date(y + 1, mo, d)
        return f"{dd.isoformat()} {h:02d}:{mi:02d}"
    except ValueError:
        return None


def send_handle(args: list[str]) -> dict:
    """반환 dict: {'reply': str, 'now': (chat_id, msg) | None}
    now 가 있으면 bot 이 즉시 발송하고 결과를 주인에게 보고."""
    if len(args) < 2:
        return {"reply": "형식: /send 지금 <대상> <메시지>  또는  /send 예약 7/25 09:00 <대상> <메시지>", "now": None}
    mode = args[0]

    if mode in ("지금", "now"):
        target = args[1]
        cid = resolve(target)
        msg = " ".join(args[2:]).strip()
        if not cid:
            return {"reply": f"대상 '{target}'를 못 찾았어요(별칭 등록 또는 숫자 id).", "now": None}
        if not msg:
            return {"reply": "보낼 내용이 없어요.", "now": None}
        return {"reply": "", "now": (cid, msg)}

    if mode in ("예약", "later"):
        if len(args) < 4:
            return {"reply": "형식: /send 예약 7/25 09:00 <대상> <메시지>", "now": None}
        when = _parse_dt(args[1], args[2])
        if not when:
            return {"reply": "날짜/시각을 못 읽었어요 (예: 7/25 09:00).", "now": None}
        target = args[3]
        cid = resolve(target)
        msg = " ".join(args[4:]).strip()
        if not cid:
            return {"reply": f"대상 '{target}'를 못 찾았어요.", "now": None}
        if not msg:
            return {"reply": "보낼 내용이 없어요.", "now": None}
        items = config.read_json(SCHED, [])
        items.append({"id": max([i.get("id", 0) for i in items], default=0) + 1,
                      "when": when, "chat_id": cid, "message": msg})
        config.write_json(SCHED, items)
        return {"reply": f"✅ 예약: {when} → {target}\n{msg}", "now": None}

    return {"reply": "사용법: /send 지금 <대상> <메시지> · /send 예약 7/25 09:00 <대상> <메시지>", "now": None}


def due(now) -> list[dict]:
    """발송 시각이 된 예약 목록을 꺼내고(파일에서 제거) 반환."""
    items = config.read_json(SCHED, [])
    if not items:
        return []
    key = now.strftime("%Y-%m-%d %H:%M")
    fire = [it for it in items if it["when"] <= key]
    if fire:
        rest = [it for it in items if it["when"] > key]
        config.write_json(SCHED, rest)
    return fire
