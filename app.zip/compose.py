# -*- coding: utf-8 -*-
"""⑫ 기능 묶어서 답하기 — "오늘 뭐 하지" 한 마디에 일정·날씨·알림·반복업무를 엮어 답한다.

여기엔 AI 를 쓰지 않는다. 규칙과 템플릿만으로 '비서처럼' 답하는 층이다.
(AI 로 문장을 다듬으면 매일 아침 성도 일정이 밖으로 나간다 — 그럴 이유가 없다.)

  day_plan(cfg)  : 오늘 종합 — 지금 시각 기준으로 남은 일정·빈 시간·준비물까지
"""
from __future__ import annotations

import re
from datetime import date, datetime

import cal
import config
import weather

TIME_RE = re.compile(r"(\d{1,2}):(\d{2})")


def _minutes(line: str) -> int | None:
    """'14:00 회의' · '07/22 14:00 회의' → 840(분). 시각이 없으면 None(종일)."""
    m = TIME_RE.search(line)
    if not m:
        return None
    return int(m.group(1)) * 60 + int(m.group(2))


def _gap_text(a: int, b: int) -> str:
    d = b - a
    h, m = divmod(d, 60)
    if h and m:
        return f"{h}시간 {m}분"
    return f"{h}시간" if h else f"{m}분"


def day_plan(cfg: dict) -> str:
    now = datetime.now()
    cur = now.hour * 60 + now.minute
    lines = [f"🗒 오늘({date.today():%m/%d}) 정리 — {now:%H:%M} 기준", ""]

    events = cal.today_lines()
    timed = sorted([(t, e) for e in events if (t := _minutes(e)) is not None])
    allday = [e for e in events if _minutes(e) is None]
    upcoming = [(t, e) for t, e in timed if t >= cur]
    passed = [(t, e) for t, e in timed if t < cur]

    if not events:
        lines.append("📅 오늘 잡힌 일정은 없습니다.")
    else:
        lines.append(f"📅 일정 {len(events)}건 — 남은 건 {len(upcoming)}건")
        for t, e in timed:
            mark = "▸" if t >= cur else "·"
            done = "" if t >= cur else "  (지남)"
            lines.append(f"  {mark} {e}{done}")
        for e in allday:
            lines.append(f"  · {e} (종일)")

    if upcoming:                                             # 다음 일정까지 남은 시간 · 사이 여유
        nt, ne = upcoming[0]
        lines.append("")
        lines.append(f"⏳ 다음: {ne} — {_gap_text(cur, nt)} 뒤")
        if len(upcoming) >= 2:
            gap = upcoming[1][0] - upcoming[0][0]
            if gap >= 90:
                lines.append(f"   그 다음 일정까지 {_gap_text(upcoming[0][0], upcoming[1][0])} 여유가 있습니다.")
    elif passed:
        lines.append("")
        lines.append("⏳ 남은 일정은 없습니다.")

    wx = weather.brief(cfg)                                  # 날씨는 그대로 붙이되 '준비물'만 강조
    lines.append("")
    lines.append(wx)
    if "우산" in wx and upcoming:                            # 날씨 문구와 겹치지 않게 '언제'를 붙인다
        lines.append(f"→ {upcoming[0][1]} 전에 우산 챙기세요.")

    daily = [t for t in config.read_json("tasks.json", []) if t.get("kind") == "daily"]
    later = [t for t in daily if _minutes(t.get("time", "")) is not None
             and _minutes(t["time"]) >= cur]
    if later:
        lines.append("")
        lines.append("⏰ 오늘 남은 예약업무")
        for t in sorted(later, key=lambda x: x["time"]):
            lines.append(f"  · {t['time']} {t['message']}")

    today = date.today().strftime("%Y-%m-%d")
    remind = [s for s in config.read_json("scheduled.json", [])
              if str(s.get("when", "")).startswith(today)]
    if remind:
        lines.append("")
        lines.append("🔔 오늘 알림")
        for s in sorted(remind, key=lambda x: x["when"]):
            lines.append(f"  · {s['when'][11:16]} {s.get('message', '')}")

    return "\n".join(lines)
