# -*- coding: utf-8 -*-
"""⑱ 집계 가드 — 없는 숫자를 있는 것처럼 만들지 않게 막는다.

왜 있나: 2026-07-16 부녀회 심방 4,445건 조작 사건. 실제 0건인데 그럴듯한 숫자가 나왔고,
교회 전체 심방률이 55%로 표시됐다(실제 0.8%). 사람이 눈으로 잡을 때까지 아무도 몰랐다.
그 뒤로 아델은 심방 숫자를 가드 모듈로만 집계한다(adele/visitation.py). 이건 그 라이트봇판이다.

원칙 — 하나라도 걸리면 그리지 않거나 경고를 붙인다:
  1. 원본에 있는 칸만 쓴다. 다른 칸에서 만들어내지 않는다.
     (특히 **결석을 잔차로 계산하지 마라** — 재적−대면−줌 은 결석이 아니다)
  2. 안 집계한 주는 '공백'이다. 0 으로 채우지 않는다. 0명과 칸 없음은 다른 말이다.
  3. 요청 구간에 실측이 하나도 없으면 **거절**한다. 대신 실제로 가진 주차를 알려준다.
  4. 부분 합이 총계와 다르면 집계를 멈춘다.
  5. 어떤 지표가 다른 지표와 거의 같게 나오면 '혼입 의심'으로 경고한다(4,445 사건 유형).

출처 라벨(CLAUDE.md 규칙): measured / empty / n/a
  · measured = 원본에서 실제로 읽은 값
  · empty    = 조회했으나 0건
  · n/a      = 그 주에 칸 자체가 없음(미집계)

밖에서 쓰는 것:
    guard.label(v)                         -> "measured" | "empty" | "n/a"
    guard.audit(name, values, ref=None)    -> {"ok","refuse","warnings","measured","na","note"}
    guard.cross_check(parts, total)        -> str | None       # 어긋나면 사유
    guard.coverage_note(name, labels, values) -> str | None    # "심방예배: 21주 중 7주만 있음"
"""
from __future__ import annotations

MIX_TOLERANCE = 0.01           # 다른 지표와 1% 안쪽으로 같으면 혼입 의심
SUM_TOLERANCE = 2              # 부분 합 vs 총계 허용 오차(명)


def label(v) -> str:
    """한 값의 출처 라벨. None 은 '칸이 없다'는 뜻이지 0 이 아니다."""
    if v is None:
        return "n/a"
    try:
        return "empty" if float(v) == 0 else "measured"
    except (TypeError, ValueError):
        return "n/a"


def audit(name: str, values, ref=None) -> dict:
    """한 지표를 훑어 그려도 되는지 판정.

    values: 주차 순서대로의 값(미집계 주는 None). ref: 비교용 다른 지표(혼입 의심 검사용).
    """
    vals = list(values or [])
    measured = [v for v in vals if label(v) == "measured"]
    na = sum(1 for v in vals if v is None)
    warnings: list[str] = []

    # (3) 실측이 아예 없으면 거절 — 빈 차트를 그리느니 왜 없는지 말한다
    if not measured:
        return {"ok": True, "refuse": f"{name}: 이 구간에 집계된 값이 없습니다 (칸 없음 {na}주).",
                "warnings": [], "measured": 0, "na": na, "note": None}

    # (2) 미집계가 섞여 있으면 그 사실을 밝힌다 — 0 으로 채우지 않았음을 알려야 한다
    note = None
    if na:
        note = f"{name}: {len(vals)}주 중 {len(measured)}주만 집계됨 (나머지 {na}주는 칸 자체가 없음)"

    # (5) 다른 지표와 거의 같으면 혼입 의심 — 4,445 사건이 이 모양이었다
    if ref is not None:
        r = [x for x in ref if label(x) == "measured"]
        if r and len(r) == len(measured):
            same = sum(1 for a, b in zip(measured, r)
                       if b and abs(a - b) / max(abs(b), 1) <= MIX_TOLERANCE)
            if same == len(measured) and len(measured) >= 2:
                warnings.append(f"⚠️ {name} 값이 비교 지표와 거의 같습니다 — 다른 칸이 섞여 들어왔을 수 있습니다. "
                                "원본을 확인하기 전에는 쓰지 마세요.")
    return {"ok": True, "refuse": None, "warnings": warnings,
            "measured": len(measured), "na": na, "note": note}


def cross_check(parts, total, what: str = "부분 합") -> str | None:
    """부분들의 합이 총계와 맞는지. 어긋나면 사유 문자열, 맞으면 None.

    맞을 때까지 차트를 그리지 않는다 — 안 맞는 채로 그리면 틀린 그림이 남는다.
    """
    try:
        s = sum(float(p) for p in parts if p is not None)
        t = float(total)
    except (TypeError, ValueError):
        return f"{what}을 확인할 수 없습니다(숫자가 아님)."
    if abs(s - t) > SUM_TOLERANCE:
        return f"{what} {s:,.0f} ≠ 총계 {t:,.0f} (차이 {abs(s - t):,.0f}) — 집계를 멈춥니다."
    return None


def coverage_note(name: str, labels, values) -> str | None:
    """실제로 값이 있는 구간을 사람 말로. 거절 사유에 붙여 쓰면 '왜 없는지'가 보인다."""
    have = [lb for lb, v in zip(labels or [], values or []) if label(v) == "measured"]
    if not have:
        return f"{name}: 가진 주차 없음"
    if len(have) == len(list(values)):
        return None
    return f"{name}: 실제 보유 주차 {have[0]}~{have[-1]} ({len(have)}주)"


def summarize(reports: dict) -> str:
    """여러 지표 판정을 사람이 읽을 한 덩이로. 아무 문제 없으면 빈 문자열."""
    lines = []
    for name, r in reports.items():
        if r.get("refuse"):
            lines.append(f"⛔ {r['refuse']}")
        for w in r.get("warnings", []):
            lines.append(w)
        if r.get("note"):
            lines.append(f"· {r['note']}")
    return "\n".join(lines)
