# -*- coding: utf-8 -*-
"""⑲ 문장에서 값 뽑기 — 규칙이 놓친 것만 머리에게 묻는다.

일정(cal)에서 한 번 만든 방식을 반복업무·알림도 같이 쓰게 떼어냈다.

순서가 중요하다:
  ① 규칙이 먼저 — 공짜고, 오프라인이고, 늘 같은 답이 나온다.
  ② 규칙이 못 채운 칸만 머리에게 — 무료 한도가 하루 20회밖에 안 되는 계정도 있다
     (2026-08-17 구글 429 응답으로 확인). 규칙으로 되는 걸 머리에 맡기면 금방 동난다.
  ③ 머리 답은 형식을 검사하고 쓴다 — '내일' 같은 말을 날짜라고 우기면 안 쓴다.

머리가 없어도(제미나이 키·클로드 둘 다 없음) 규칙만으로 돌아가야 한다. 그게 이 봇의 전제다.
"""
from __future__ import annotations

import json
import re

import config

log = config.get_logger()

RE_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")
RE_TIME = re.compile(r"[0-2]\d:[0-5]\d")


def available(cfg: dict) -> bool:
    try:
        import llm
        return llm.available(cfg)
    except Exception:                                        # noqa: BLE001
        return False


def ask_json(cfg: dict, prompt: str) -> dict | None:
    """머리에게 묻고 JSON 만 건진다. 못 건지면 None — 지어내지 않는다."""
    try:
        import llm
        got = llm.ask(cfg, prompt)
    except Exception as e:                                   # noqa: BLE001 — 머리 때문에 본 기능이 죽으면 안 된다
        log.info("머리 호출 실패(규칙 결과 사용): %s: %s", type(e).__name__, e, exc_info=True)
        return None
    if not got:
        return None
    t = got.strip()
    if t.startswith("```"):
        t = re.sub(r"^```[a-zA-Z]*\n?", "", t)
        t = re.sub(r"\n?```\s*$", "", t)
    i, j = t.find("{"), t.rfind("}")
    if i < 0 or j <= i:
        log.info("머리가 JSON 이 아닌 걸 줬습니다 — 앞 120자: %s", t[:120])
        return None
    try:
        obj = json.loads(t[i:j + 1])
    except json.JSONDecodeError:
        log.info("머리 JSON 파싱 실패 — 앞 120자: %s", t[:120])
        return None
    return obj if isinstance(obj, dict) else None


def date_or_none(v) -> str | None:
    """'2026-10-01' 만 받는다. '내일'·'다음주' 같은 말은 날짜가 아니다."""
    s = str(v or "").strip()
    if not RE_DATE.fullmatch(s):
        return None
    from datetime import date
    try:
        date.fromisoformat(s)
    except ValueError:
        return None
    return s


def time_or_empty(v) -> str:
    """'14:00' 만 받는다. '오후'·'저녁' 은 시각이 아니다."""
    s = str(v or "").strip()
    return s if RE_TIME.fullmatch(s) else ""


def text_or_empty(v, limit: int = 120) -> str:
    s = re.sub(r"\s+", " ", str(v or "")).strip()
    return s[:limit]
