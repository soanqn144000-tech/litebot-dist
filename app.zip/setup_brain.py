# -*- coding: utf-8 -*-
"""머리(AI)만 따로 설정 — 제미나이 키 · 어느 머리를 쓸지.

전체 설정 마법사는 토큰부터 다 다시 묻는다. 키 하나 넣으려고 그걸 다 지나갈 이유가 없다.
키는 화면에 안 찍히게 받는다(getpass) — 어깨너머로도, 기록에도 안 남는다.

실행:  venv/bin/python -c "import setup_brain; setup_brain.run()"
"""
from __future__ import annotations

import sys
import time

import config


def _clip() -> str:
    """클립보드에 키처럼 생긴 게 있으면 돌려준다.

    **접두어로 거르지 않는다.** 예전 키는 'AIza…' 로 시작했지만 요즘 구글이 주는 키는
    'AQ.…' 로 시작한다 — 접두어로 걸렀더니 진짜 키를 무시했다(2026-08-17).
    모양만 보고(공백 없는 한 덩이, 30~120자) 넘긴 뒤, 진짜인지는 구글에게 물어 판정한다.
    """
    try:
        import subprocess
        out = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception:                                        # noqa: BLE001 — 맥이 아니거나 실패하면 없는 셈
        return ""
    if not out or len(out.split()) != 1 or not (30 <= len(out) <= 120):
        return ""
    return out


def _check(key: str) -> tuple[bool, str]:
    """키가 실제로 되는지 구글에 한 번 물어본다 — 오타로 몇 시간 헤매지 않게."""
    try:
        import requests
        r = requests.get("https://generativelanguage.googleapis.com/v1beta/models",
                         params={"key": key}, timeout=20)
    except Exception as e:                                   # noqa: BLE001
        return False, f"인터넷이 막혔거나 오류 ({type(e).__name__})"
    if r.status_code != 200:
        return False, f"키가 거부됐어요 (HTTP {r.status_code})"
    names = [m.get("name", "") for m in (r.json().get("models") or [])]
    flash = [n for n in names if "flash" in n and "gemini" in n]
    return True, (flash[0].split("/")[-1] if flash else f"모델 {len(names)}개 보임")


def run(wait_sec: int = 180) -> bool:
    """키를 복사하기만 하면 알아서 집어간다 — 아무것도 안 쳐도 된다.

    비밀번호 칸은 붙여넣어도 화면에 안 떠서 됐는지를 알 수 없고, 그것 때문에 못 넘어간다.
    그래서 묻지 않고 클립보드를 지켜본다. 복사되는 순간 구글에 한 번 확인하고 저장한다.
    """
    cfg = config.load_config()
    if not cfg:
        print("설정 파일이 없습니다. 먼저 라이트봇을 한 번 실행해 기본 설정을 마쳐주세요.")
        return False

    print("\n" + "─" * 56)
    print(" 제미나이 무료 키 넣기 — 아무것도 안 치셔도 됩니다")
    print("─" * 56)
    print(" 지금: 머리 =", cfg.get("brain") or "auto",
          "· 제미나이 키 =", "있음" if cfg.get("gemini_key") else "없음")
    print("\n 브라우저에서 키를 **복사(⌘C)** 만 하세요.")
    print(" https://aistudio.google.com/apikey")
    print(" 복사하는 순간 알아서 집어갑니다. (그만두려면 이 창을 닫으세요)\n")

    seen = None                                              # 이미 복사해두셨으면 그것부터 본다
    for i in range(wait_sec):
        now = _clip()
        if now and now != seen:
            print(f" 키를 찾았습니다 — {now[:6]}…{now[-4:]} ({len(now)}자). 확인 중…")
            ok, why = _check(now)
            if not ok:
                print(f" ❌ {why} — 다시 복사해 주세요.")
                seen = now
                continue
            cfg["gemini_key"] = now
            cfg["brain"] = "gemini"                          # 교인이 쓰는 그대로 — 클로드가 안 잡히게
            config.save_config(cfg)
            print(f" ✅ 저장했습니다 — {why} · 머리 = gemini")
            print(" 라이트봇을 껐다 켜면 적용됩니다.")
            return True
        time.sleep(1)
        if i and i % 30 == 0:
            print(f" …{wait_sec - i}초 남음. 키를 복사해 주세요.")

    print(" 시간이 다 됐습니다. 창을 닫고 다시 실행해 주세요.")
    return False


if __name__ == "__main__":
    sys.exit(0 if run() else 1)
