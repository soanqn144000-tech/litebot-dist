# -*- coding: utf-8 -*-
"""⑧ 머리(선택) — 제공자를 골라 쓴다. 몸은 하나, 머리만 갈아끼움.

  · brain=gemini : Google Gemini 무료 키(각 PC config.json). 한도 소진 시 규칙 기반 강등, 다음날 복귀.
  · brain=claude : 클로드 코드(그 PC 의 claude 로그인=Pro/Max 구독). API 키·추가과금 없음, 아델과 같은 구조.
  · brain=auto(기본): 클로드 코드가 깔려 있으면 그걸, 아니면 제미나이 키를, 둘 다 없으면 규칙 기반.

밖에서 쓰는 건 두 개뿐:
    llm.available(cfg) -> bool
    llm.ask(cfg, prompt, images=[…]) -> str | None   # None 이면 호출자가 규칙 기반으로 처리

밖으로 나가는 문은 여기 하나 — 그래서 가명 처리(privacy)도, 배운 것 주입(learn)도 여기서 한다.
"""
from __future__ import annotations

import base64
import json
import time
from datetime import datetime, timedelta, timezone

import requests

import brain_claude
import config
import learn
import privacy

KST = timezone(timedelta(hours=9))
API = "https://generativelanguage.googleapis.com/v1beta"
STATE = "llm_state.json"                                     # {"model":…, "cooldown_until":…, "used":{"YYYY-MM-DD":n}}
TIMEOUT = 60
log = config.get_logger()


def _key(cfg: dict) -> str:
    return (cfg.get("gemini_key") or "").strip()


def _state() -> dict:
    try:
        return json.loads((config.DATA_DIR / STATE).read_text(encoding="utf-8"))
    except Exception:                                        # noqa: BLE001
        return {}


def _save(st: dict) -> None:
    try:
        (config.DATA_DIR / STATE).write_text(json.dumps(st, ensure_ascii=False, indent=2),
                                             encoding="utf-8")
    except Exception:                                        # noqa: BLE001
        pass


def _cooling(st: dict) -> bool:
    until = st.get("cooldown_until")
    if not until:
        return False
    try:
        return datetime.now(KST) < datetime.fromisoformat(until)
    except Exception:                                        # noqa: BLE001
        return False


def _start_cooldown(st: dict, seconds: int = 0) -> None:
    """한도 초과. 서버가 알려준 시간만큼, 없으면 다음날 새벽까지 쉰다."""
    now = datetime.now(KST)
    if seconds:
        until = now + timedelta(seconds=seconds)
        why = "분당 제한" if seconds <= 90 else "한도"
    else:
        until = (now + timedelta(days=1)).replace(hour=0, minute=5, second=0, microsecond=0)
        why = "오늘 무료 한도 소진"
    st["cooldown_until"] = until.isoformat()
    _save(st)
    log.info("Gemini %s — %s 까지 규칙 기반으로 동작", why, until.strftime("%m/%d %H:%M"))


def pick_model(key: str) -> str | None:
    """키로 쓸 수 있는 모델 목록을 받아 flash(무료 한도가 넉넉한 계열) 중 최신을 고른다."""
    try:
        r = requests.get(f"{API}/models", params={"key": key}, timeout=20)
        if r.status_code != 200:
            return None
        names = [m.get("name", "") for m in r.json().get("models", [])
                 if "generateContent" in (m.get("supportedGenerationMethods") or [])]
    except Exception:                                        # noqa: BLE001
        return None
    cands = [n for n in names if "flash" in n and "thinking" not in n and "-8b" not in n]
    if not cands:
        cands = [n for n in names if "gemini" in n]
    if not cands:
        return None
    cands.sort(key=lambda n: ("lite" in n, n), reverse=False)   # lite 는 뒤로
    cands.sort(key=lambda n: n.split("/")[-1], reverse=True)     # 버전 높은 것 먼저
    return cands[0]                                          # 예: 'models/gemini-2.5-flash'


def model_of(cfg: dict) -> str | None:
    st = _state()
    if st.get("model"):
        return st["model"]
    m = pick_model(_key(cfg))
    if m:
        st["model"] = m
        _save(st)
    return m


def _provider(cfg: dict) -> str:
    """지금 쓸 머리. 'gemini' | 'claude' | ''(없음). 설정 brain 존중, auto 는 자동 선택."""
    want = (cfg.get("brain") or "auto").strip().lower()
    if want == "off":
        return ""
    if want == "claude":
        return "claude" if brain_claude.available() else ""
    if want == "gemini":
        return "gemini" if (_key(cfg) and not _cooling(_state())) else ""
    # auto: 클로드 코드가 있으면 그걸(구독=한도 넉넉), 아니면 제미나이 키
    if brain_claude.available():
        return "claude"
    if _key(cfg) and not _cooling(_state()):
        return "gemini"
    return ""


def available(cfg: dict) -> bool:
    return _provider(cfg) != ""


def status(cfg: dict) -> str:
    """/help·설정에서 보여줄 한 줄 상태."""
    p = _provider(cfg)
    if p == "claude":
        return "머리: 클로드 코드(구독) — 요약·표읽기 최고 품질"
    if p == "gemini":
        st = _state()
        used = (st.get("used") or {}).get(datetime.now(KST).strftime("%Y-%m-%d"), 0)
        return f"머리: 제미나이({(st.get('model') or '?').split('/')[-1]}) · 오늘 {used}회"
    # 왜 못 쓰는지 구분해서 알려준다
    if _key(cfg) and _cooling(_state()):
        return f"제미나이 무료 한도 소진 — {_state()['cooldown_until'][5:16].replace('T', ' ')} 까지 규칙 기반"
    if brain_claude.available():
        return "클로드 코드는 있는데 설정에서 꺼져 있음(설정 → 머리)"
    return "머리 미설정 — 규칙 기반. (제미나이 무료 키 또는 클로드 코드 설치 시 요약·표읽기 가능)"


def used_today() -> int:
    """오늘 제미나이를 몇 번 불렀나 — 실측값. 지어내지 않는다."""
    return int((_state().get("used") or {}).get(datetime.now(KST).strftime("%Y-%m-%d"), 0))


def used_days(n: int = 7) -> list[tuple[str, int]]:
    """최근 며칠 사용량 — 기록이 있는 날만."""
    used = _state().get("used") or {}
    return sorted(used.items(), reverse=True)[:n]


def daily_limit(cfg: dict) -> int:
    """하루 한도. 0 이면 '모름' — **임의로 숫자를 지어내지 않는다.**

    구글이 모델·시기마다 무료 한도를 바꾼다. 틀린 숫자를 남은 양이라고 보여주면
    믿고 쓰다가 갑자기 끊긴다. 그래서 사용자가 적어준 값만 쓴다(설정 gemini_daily_limit).
    """
    try:
        return max(0, int(cfg.get("gemini_daily_limit") or 0))
    except (TypeError, ValueError):
        return 0


def quota_text(cfg: dict) -> str:
    """한도·사용량을 사람이 읽게. 모르는 건 모른다고 쓴다.

    클로드를 쓰는 중이어도 **키가 있으면 제미나이 사용량을 보여준다** — 클로드가 끊기면
    바로 이쪽으로 내려앉기 때문에, 그때 얼마나 남았는지를 미리 알고 있어야 한다.
    """
    if not _key(cfg):
        if _provider(cfg) == "claude":
            return "머리: 클로드 코드(구독) — 제미나이 키는 없습니다."
        return "제미나이 키가 없습니다. 설정에서 무료 키를 넣으면 요약·표읽기가 됩니다."

    st = _state()
    head = ""
    if _provider(cfg) == "claude":                            # 지금은 클로드를 쓰지만 제미나이가 예비다
        head = "머리: 클로드 코드(구독) · 아래는 예비(제미나이)입니다\n"
    used = used_today()
    lim = daily_limit(cfg)
    model = (st.get("model") or "?").split("/")[-1]
    lines = [head + f"🧠 제미나이 ({model})"]

    if lim:
        left = max(0, lim - used)
        bar_n = 0 if lim <= 0 else min(10, round(used / lim * 10))
        lines.append(f"오늘 {used} / {lim}회 · 남은 {left}회")
        lines.append("▓" * bar_n + "░" * (10 - bar_n))
        if left == 0:
            lines.append("한도를 다 썼습니다 — 오늘은 규칙 기반으로 답합니다.")
        elif left <= max(3, lim // 10):
            lines.append("⚠️ 얼마 안 남았습니다.")
    else:
        lines.append(f"오늘 {used}회 사용")
        lines.append("하루 한도는 모릅니다 — 구글이 모델·시기마다 바꿉니다.")
        lines.append("아신다면 «/status 한도 250» 처럼 넣어주시면 남은 양을 계산합니다.")

    if _cooling(st):
        until = str(st.get("cooldown_until", ""))[5:16].replace("T", " ")
        lines.append(f"⏸ 지금은 규칙 기반 — {until} 까지 쉬는 중입니다.")

    prev = [f"{d[5:]} {n}회" for d, n in used_days(4)[1:]]
    if prev:
        lines.append("지난 날: " + " · ".join(prev))
    return "\n".join(lines)


def ask(cfg: dict, prompt: str, images: list[bytes] | None = None,
        max_chars: int = 60_000) -> str | None:
    """물어보고 답 문자열. 못 쓰면 None → 호출자가 규칙 기반으로 처리한다.

    **여기가 밖으로 나가는 유일한 문이다.** 그래서 가명 처리도 여기서 한다(제공자 무관) —
    나갈 때 이름을 지우고(privacy.mask), 답이 오면 원래 이름으로 되돌린다(unmask).
    사진은 가릴 방법이 없으므로 설정에서 켜야만 나간다(ai_send_photos).
    """
    provider = _provider(cfg)
    if not provider:
        return None
    if images and not cfg.get("ai_send_photos"):
        log.info("사진 전송 꺼짐(ai_send_photos) — 사진은 안 보냄")
        return None

    # 배운 것을 앞에 붙인다 — 여기가 유일한 문이라, 이 한 줄로 차트든 요약이든 표읽기든
    # 같은 기억이 따라간다(learn.py). 배운 게 없으면 빈 문자열이라 토큰을 안 쓴다.
    try:
        prompt = learn.inject_text() + prompt
    except Exception as e:                                   # noqa: BLE001 — 기억 때문에 본 기능이 죽으면 안 된다
        log.info("배운 것 주입 실패(무시하고 진행): %s", type(e).__name__)

    safe, mapping = privacy.mask(prompt)                     # ← 이름 지우고 나간다(모든 제공자 공통)

    if provider == "claude":                                 # 클로드 코드(구독)
        out = brain_claude.ask(safe, images=images)
        return privacy.unmask(out, mapping) if out else None

    # 아래는 제미나이 경로
    key = _key(cfg)
    model = model_of(cfg)
    if not (key and model):
        return None
    parts: list[dict] = []
    for img in (images or [])[:4]:
        parts.append({"inline_data": {"mime_type": "image/jpeg",
                                      "data": base64.b64encode(img).decode()}})
    parts.append({"text": safe[:max_chars]})
    body = {"contents": [{"parts": parts}],
            "generationConfig": {"temperature": 0.2, "maxOutputTokens": 2048}}

    for attempt in range(2):                                 # 분당 제한이면 잠깐 쉬고 한 번 더
        try:
            r = requests.post(f"{API}/{model}:generateContent", params={"key": key},
                              json=body, timeout=TIMEOUT)
        except Exception as e:                               # noqa: BLE001
            log.info("Gemini 호출 실패: %s", type(e).__name__)
            return None
        if r.status_code != 429:
            break
        delay = 0
        try:                                                 # 서버가 준 재시도 대기시간
            for d in r.json().get("error", {}).get("details", []):
                rd = str(d.get("retryDelay", ""))
                if rd.endswith("s"):
                    delay = int(float(rd[:-1]))
        except Exception:                                    # noqa: BLE001
            pass
        # 대기가 짧으면(분당 제한) 그 자리서 한 번 더, 길거나 두 번째면 오늘은 접는다(일일 한도).
        if delay and delay <= 40 and attempt == 0:
            log.info("Gemini 분당 제한 — %d초 쉬고 재시도", delay + 1)
            time.sleep(delay + 1)
            continue
        _start_cooldown(st, delay)
        return None
    else:
        return None
    if r.status_code in (400, 403):                          # 키가 틀렸거나 권한 없음
        log.info("Gemini 거부(HTTP %s) — 키 확인 필요", r.status_code)
        return None
    if r.status_code != 200:
        log.info("Gemini 오류 HTTP %s", r.status_code)
        return None

    try:
        cands = r.json().get("candidates") or []
        text = "".join(p.get("text", "") for p in cands[0]["content"]["parts"]).strip()
    except Exception:                                        # noqa: BLE001
        return None
    if not text:
        return None
    text = privacy.unmask(text, mapping)                     # ← 화면엔 실명으로 되돌려 보여준다

    today = datetime.now(KST).strftime("%Y-%m-%d")
    used = st.get("used") or {}
    used[today] = used.get(today, 0) + 1
    st["used"] = {k: v for k, v in used.items() if k >= today}   # 지난 날짜는 버림
    _save(st)
    return text
