# -*- coding: utf-8 -*-
"""⑧ 머리(선택) — Google Gemini 무료 키. 있으면 요약·사진읽기·표해석, 없거나 한도 끝나면 규칙 기반으로.

  · 키는 각 PC config.json 에만 (서버 경유 없음).
  · 무료 한도를 다 쓰면(429) 스스로 '오늘은 쉼' 표시하고 규칙 기반으로 강등, 다음날 자동 복귀.
  · 모델 이름은 고정하지 않는다 — 키로 목록을 받아 flash 계열을 골라 캐시(모델명이 바뀌어도 안 깨지게).

밖에서 쓰는 건 두 개뿐:
    llm.available(cfg) -> bool          # 지금 머리를 쓸 수 있나
    llm.ask(cfg, prompt, images=[…]) -> str | None   # None 이면 호출자가 규칙 기반으로 처리
"""
from __future__ import annotations

import base64
import json
from datetime import datetime, timedelta, timezone

import requests

import config

KST = timezone(timedelta(hours=9))
API = "https://generativelanguage.googleapis.com/v1beta"
STATE = "llm_state.json"                                     # {"model":…, "cooldown_until":…, "used":{"YYYY-MM-DD":n}}
TIMEOUT = 60
log = config.get_logger()


def _key(cfg: dict) -> str:
    return (cfg.get("gemini_key") or "").strip()


def _state() -> dict:
    try:
        return json.loads((config.DATA_DIR / STATE).read_text(encoding="utf-8"))
    except Exception:                                        # noqa: BLE001
        return {}


def _save(st: dict) -> None:
    try:
        (config.DATA_DIR / STATE).write_text(json.dumps(st, ensure_ascii=False, indent=2),
                                             encoding="utf-8")
    except Exception:                                        # noqa: BLE001
        pass


def _cooling(st: dict) -> bool:
    until = st.get("cooldown_until")
    if not until:
        return False
    try:
        return datetime.now(KST) < datetime.fromisoformat(until)
    except Exception:                                        # noqa: BLE001
        return False


def _start_cooldown(st: dict, seconds: int = 0) -> None:
    """한도 초과. 서버가 알려준 시간만큼, 없으면 다음날 새벽까지 쉰다."""
    now = datetime.now(KST)
    if seconds:
        until = now + timedelta(seconds=seconds)
    else:
        until = (now + timedelta(days=1)).replace(hour=0, minute=5, second=0, microsecond=0)
    st["cooldown_until"] = until.isoformat()
    _save(st)
    log.info("Gemini 무료 한도 소진 — %s 까지 규칙 기반으로 동작", until.strftime("%m/%d %H:%M"))


def pick_model(key: str) -> str | None:
    """키로 쓸 수 있는 모델 목록을 받아 flash(무료 한도가 넉넉한 계열) 중 최신을 고른다."""
    try:
        r = requests.get(f"{API}/models", params={"key": key}, timeout=20)
        if r.status_code != 200:
            return None
        names = [m.get("name", "") for m in r.json().get("models", [])
                 if "generateContent" in (m.get("supportedGenerationMethods") or [])]
    except Exception:                                        # noqa: BLE001
        return None
    cands = [n for n in names if "flash" in n and "thinking" not in n and "-8b" not in n]
    if not cands:
        cands = [n for n in names if "gemini" in n]
    if not cands:
        return None
    cands.sort(key=lambda n: ("lite" in n, n), reverse=False)   # lite 는 뒤로
    cands.sort(key=lambda n: n.split("/")[-1], reverse=True)     # 버전 높은 것 먼저
    return cands[0]                                          # 예: 'models/gemini-2.5-flash'


def model_of(cfg: dict) -> str | None:
    st = _state()
    if st.get("model"):
        return st["model"]
    m = pick_model(_key(cfg))
    if m:
        st["model"] = m
        _save(st)
    return m


def available(cfg: dict) -> bool:
    return bool(_key(cfg)) and not _cooling(_state())


def status(cfg: dict) -> str:
    """/help·설정에서 보여줄 한 줄 상태."""
    if not _key(cfg):
        return "머리(Gemini) 미설정 — 규칙 기반으로만 동작"
    st = _state()
    if _cooling(st):
        return f"무료 한도 소진 — {st['cooldown_until'][5:16].replace('T', ' ')} 까지 규칙 기반"
    used = (st.get("used") or {}).get(datetime.now(KST).strftime("%Y-%m-%d"), 0)
    return f"머리 켜짐({(st.get('model') or '?').split('/')[-1]}) · 오늘 {used}회"


def ask(cfg: dict, prompt: str, images: list[bytes] | None = None,
        max_chars: int = 60_000) -> str | None:
    """물어보고 답 문자열. 키 없음·한도 소진·오류면 None → 호출자가 규칙 기반으로 처리한다."""
    key = _key(cfg)
    if not key:
        return None
    st = _state()
    if _cooling(st):
        return None
    model = model_of(cfg)
    if not model:
        return None

    parts: list[dict] = []
    for img in (images or [])[:4]:
        parts.append({"inline_data": {"mime_type": "image/jpeg",
                                      "data": base64.b64encode(img).decode()}})
    parts.append({"text": prompt[:max_chars]})
    body = {"contents": [{"parts": parts}],
            "generationConfig": {"temperature": 0.2, "maxOutputTokens": 2048}}
    try:
        r = requests.post(f"{API}/{model}:generateContent", params={"key": key},
                          json=body, timeout=TIMEOUT)
    except Exception as e:                                   # noqa: BLE001
        log.info("Gemini 호출 실패: %s", type(e).__name__)
        return None

    if r.status_code == 429:
        delay = 0
        try:                                                 # 서버가 재시도 시각을 주면 그만큼만 쉰다
            for d in r.json().get("error", {}).get("details", []):
                rd = str(d.get("retryDelay", ""))
                if rd.endswith("s"):
                    delay = int(float(rd[:-1]))
        except Exception:                                    # noqa: BLE001
            pass
        _start_cooldown(st, delay)
        return None
    if r.status_code in (400, 403):                          # 키가 틀렸거나 권한 없음
        log.info("Gemini 거부(HTTP %s) — 키 확인 필요", r.status_code)
        return None
    if r.status_code != 200:
        log.info("Gemini 오류 HTTP %s", r.status_code)
        return None

    try:
        cands = r.json().get("candidates") or []
        text = "".join(p.get("text", "") for p in cands[0]["content"]["parts"]).strip()
    except Exception:                                        # noqa: BLE001
        return None
    if not text:
        return None

    today = datetime.now(KST).strftime("%Y-%m-%d")
    used = st.get("used") or {}
    used[today] = used.get(today, 0) + 1
    st["used"] = {k: v for k, v in used.items() if k >= today}   # 지난 날짜는 버림
    _save(st)
    return text
