# -*- coding: utf-8 -*-
"""⑧ 머리(선택) — 제공자를 골라 쓴다. 몸은 하나, 머리만 갈아끼움.

  · brain=gemini : Google Gemini 무료 키(각 PC config.json). 한도 소진 시 규칙 기반 강등, 다음날 복귀.
  · brain=claude : 클로드 코드(그 PC 의 claude 로그인=Pro/Max 구독). API 키·추가과금 없음, 아델과 같은 구조.
  · brain=auto(기본): 클로드 코드가 깔려 있으면 그걸, 아니면 제미나이 키를, 둘 다 없으면 규칙 기반.

밖에서 쓰는 건 두 개뿐:
    llm.available(cfg) -> bool
    llm.ask(cfg, prompt, images=[…]) -> str | None   # None 이면 호출자가 규칙 기반으로 처리

밖으로 나가는 문은 여기 하나 — 그래서 가명 처리(privacy)도, 배운 것 주입(learn)도 여기서 한다.
"""
from __future__ import annotations

import base64
import json
import time
from datetime import datetime, timedelta, timezone

import requests

import brain_claude
import config
import learn
import privacy

KST = timezone(timedelta(hours=9))
API = "https://generativelanguage.googleapis.com/v1beta"
STATE = "llm_state.json"                                     # {"model":…, "cooldown_until":…, "used":{"YYYY-MM-DD":n}}
TIMEOUT = 60
MAX_WAIT = 5                                                 # 이보다 오래 기다려야 하면 안 기다린다(봇이 멈춘다)
log = config.get_logger()


def _key(cfg: dict) -> str:
    return (cfg.get("gemini_key") or "").strip()


def _state() -> dict:
    try:
        return json.loads((config.DATA_DIR / STATE).read_text(encoding="utf-8"))
    except Exception:                                        # noqa: BLE001
        return {}


def _save(st: dict) -> None:
    try:
        (config.DATA_DIR / STATE).write_text(json.dumps(st, ensure_ascii=False, indent=2),
                                             encoding="utf-8")
    except Exception:                                        # noqa: BLE001
        pass


def _cooling(st: dict) -> bool:
    until = st.get("cooldown_until")
    if not until:
        return False
    try:
        return datetime.now(KST) < datetime.fromisoformat(until)
    except Exception:                                        # noqa: BLE001
        return False


def _start_cooldown(st: dict, seconds: int = 0) -> None:
    """한도 초과. 서버가 알려준 시간만큼, 없으면 다음날 새벽까지 쉰다."""
    now = datetime.now(KST)
    if seconds:
        until = now + timedelta(seconds=seconds)
        why = "분당 제한" if seconds <= 90 else "한도"
    else:
        until = (now + timedelta(days=1)).replace(hour=0, minute=5, second=0, microsecond=0)
        why = "오늘 무료 한도 소진"
    st["cooldown_until"] = until.isoformat()
    _save(st)
    log.info("Gemini %s — %s 까지 규칙 기반으로 동작", why, until.strftime("%m/%d %H:%M"))


def pick_model(key: str) -> str | None:
    """키로 쓸 수 있는 모델 목록을 받아 flash(무료 한도가 넉넉한 계열) 중 최신을 고른다."""
    try:
        r = requests.get(f"{API}/models", params={"key": key}, timeout=20)
        if r.status_code != 200:
            return None
        names = [m.get("name", "") for m in r.json().get("models", [])
                 if "generateContent" in (m.get("supportedGenerationMethods") or [])]
    except Exception:                                        # noqa: BLE001
        return None
    # 글을 읽고 쓰는 정식 모델만 남긴다. 예전엔 이름만 보고 골라서
    # 'gemini-omni-flash-preview' 가 잡혔고, 프리뷰라 무료 한도가 거의 없어 첫 호출에 429 가 났다(2026-08-17).
    BAD = ("image", "tts", "audio", "live", "preview", "omni", "vision", "embedding", "thinking", "-8b")
    cands = [n for n in names if "flash" in n and not any(b in n for b in BAD)]
    if not cands:
        cands = [n for n in names if "gemini" in n and not any(b in n for b in BAD)]
    if not cands:
        return None

    return _order(cands)[0] if _order(cands) else None


def _order(cands: list) -> list:
    """무료로 쓸 때 **한도가 큰 순서**로. 최신 모델이 좋은 게 아니다.

    구글은 최신 모델일수록 무료 한도를 작게 준다 — gemini-3.7-flash 는 하루 20회다
    (2026-08-17 구글 429 응답으로 확인). 교인이 하루 종일 쓰려면 lite 계열이 맞다.
    이미 한도를 알아낸 모델이 있으면 그 숫자가 우선이다 — 추측보다 실측이다.
    """
    import re as _re
    known = _state().get("quota") or {}

    def key(n: str):
        short = n.split("/")[-1]
        lim = 0
        try:
            lim = int((known.get(short) or {}).get("limit") or 0)
        except (TypeError, ValueError):
            lim = 0
        m = _re.search(r"gemini-(\d+)(?:\.(\d+))?", n)
        major, minor = (int(m.group(1)), int(m.group(2) or 0)) if m else (0, 0)
        # ① 실측 한도가 큰 것 ② lite 계열 ③ 버전 낮은 것(무료 한도가 대체로 넉넉)
        # 아직 안 써본 모델은 '보통쯤'(500)으로 본다. 20회짜리가 확인됐다고 그게 1순위가 되면 안 된다.
        rank = -(lim if lim else 500)
        return (rank, 0 if "lite" in short else 1, major, minor)

    return sorted(cands, key=key)


def model_candidates(key: str) -> list:
    """쓸 만한 모델을 좋은 순서로. 하나가 막히면 다음으로 넘어가려고 목록으로 준다."""
    try:
        r = requests.get(f"{API}/models", params={"key": key}, timeout=20)
        if r.status_code != 200:
            return []
        names = [m.get("name", "") for m in r.json().get("models", [])
                 if "generateContent" in (m.get("supportedGenerationMethods") or [])]
    except Exception:                                        # noqa: BLE001
        return []
    BAD = ("image", "tts", "audio", "live", "preview", "omni", "vision", "embedding", "thinking", "-8b")
    c = [n for n in names if "flash" in n and not any(b in n for b in BAD)]
    if not c:
        c = [n for n in names if "gemini" in n and not any(b in n for b in BAD)]

    return _order(c)[:4]


def model_of(cfg: dict) -> str | None:
    st = _state()
    if st.get("model"):
        return st["model"]
    m = pick_model(_key(cfg))
    if m:
        st["model"] = m
        _save(st)
    return m


def _provider(cfg: dict) -> str:
    """지금 쓸 머리. 'gemini' | 'claude' | ''(없음). 설정 brain 존중, auto 는 자동 선택."""
    want = (cfg.get("brain") or "auto").strip().lower()
    if want == "off":
        return ""
    if want == "claude":
        return "claude" if brain_claude.available() else ""
    if want == "gemini":
        return "gemini" if (_key(cfg) and not _cooling(_state())) else ""
    # auto: 클로드 코드가 있으면 그걸(구독=한도 넉넉), 아니면 제미나이 키
    if brain_claude.available():
        return "claude"
    if _key(cfg) and not _cooling(_state()):
        return "gemini"
    return ""


def available(cfg: dict) -> bool:
    return _provider(cfg) != ""


def status(cfg: dict) -> str:
    """/help·설정에서 보여줄 한 줄 상태."""
    p = _provider(cfg)
    if p == "claude":
        return "머리: 클로드 코드(구독) — 요약·표읽기 최고 품질"
    if p == "gemini":
        st = _state()
        used = (st.get("used") or {}).get(datetime.now(KST).strftime("%Y-%m-%d"), 0)
        return f"머리: 제미나이({(st.get('model') or '?').split('/')[-1]}) · 오늘 {used}회"
    # 왜 못 쓰는지 구분해서 알려준다
    if _key(cfg) and _cooling(_state()):
        return f"제미나이 무료 한도 소진 — {_state()['cooldown_until'][5:16].replace('T', ' ')} 까지 규칙 기반"
    if brain_claude.available():
        return "클로드 코드는 있는데 설정에서 꺼져 있음(설정 → 머리)"
    return "머리 미설정 — 규칙 기반. (제미나이 무료 키 또는 클로드 코드 설치 시 요약·표읽기 가능)"


def _learn_quota(detail: dict, model: str) -> None:
    """429 안에 든 QuotaFailure 에서 **구글이 말한 실제 한도**를 받아 적는다.

    구글은 무료 한도 숫자를 문서에 안 싣는다(계정·모델·시기마다 다름, 2026-08-13 문서 기준
    'AI Studio 에서 보라'고만 한다). 그래서 임의로 박지 않고, 막히는 순간 서버가 보내주는
    quotaValue 를 기록해 그때부터 남은 양을 보여준다. 지어내지 않고 받아 적는 것이다.
    """
    if str(detail.get("@type", "")).endswith("QuotaFailure"):
        for v in detail.get("violations", []):
            qid = str(v.get("quotaId", ""))
            try:
                val = int(v.get("quotaValue"))
            except (TypeError, ValueError):
                continue
            if "PerDay" not in qid and "Daily" not in qid:    # 분당 한도는 여기 관심사가 아니다
                continue
            st = _state()
            q = st.get("quota") or {}
            q[model.split("/")[-1]] = {"limit": val, "id": qid,
                                       "learned": datetime.now(KST).strftime("%Y-%m-%d %H:%M")}
            st["quota"] = q
            _save(st)
            log.info("제미나이 하루 한도 확인 — %s = %d회 (%s)", model.split("/")[-1], val, qid)


def known_limit(cfg: dict, model: str = "") -> tuple[int, str]:
    """(하루 한도, 어디서 알았나). 0 이면 아직 모른다.

    사용자가 직접 적어준 값이 우선 — 본인이 AI Studio 에서 본 숫자가 제일 정확하다.
    """
    manual = daily_limit(cfg)
    if manual:
        return manual, "직접 입력"
    m = (model or model_of(cfg) or "").split("/")[-1]
    q = (_state().get("quota") or {}).get(m) or {}
    try:
        return int(q.get("limit") or 0), f"구글 응답({q.get('learned', '')})"
    except (TypeError, ValueError):
        return 0, ""


def reset_in() -> str:
    """하루 한도가 언제 풀리나 — 태평양 자정 기준(구글 문서). 남은 시간을 사람 말로."""
    now = datetime.now(timezone.utc)
    # 태평양시: 3~11월 UTC-7(서머타임), 그 밖 UTC-8. 경계 며칠은 최대 1시간 어긋날 수 있다.
    off = -7 if 3 <= now.month <= 11 else -8
    pt = now + timedelta(hours=off)
    nxt = (pt + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    left = nxt - pt
    h, m = left.seconds // 3600, (left.seconds % 3600) // 60
    return f"{h}시간 {m}분 후" if h else f"{m}분 후"


def used_today() -> int:
    """오늘 제미나이를 몇 번 불렀나 — 실측값. 지어내지 않는다."""
    return int((_state().get("used") or {}).get(datetime.now(KST).strftime("%Y-%m-%d"), 0))


def used_days(n: int = 7) -> list[tuple[str, int]]:
    """최근 며칠 사용량 — 기록이 있는 날만."""
    used = _state().get("used") or {}
    return sorted(used.items(), reverse=True)[:n]


def daily_limit(cfg: dict) -> int:
    """하루 한도. 0 이면 '모름' — **임의로 숫자를 지어내지 않는다.**

    구글이 모델·시기마다 무료 한도를 바꾼다. 틀린 숫자를 남은 양이라고 보여주면
    믿고 쓰다가 갑자기 끊긴다. 그래서 사용자가 적어준 값만 쓴다(설정 gemini_daily_limit).
    """
    try:
        return max(0, int(cfg.get("gemini_daily_limit") or 0))
    except (TypeError, ValueError):
        return 0


def quota_text(cfg: dict) -> str:
    """한도·사용량을 사람이 읽게. 모르는 건 모른다고 쓴다.

    클로드를 쓰는 중이어도 **키가 있으면 제미나이 사용량을 보여준다** — 클로드가 끊기면
    바로 이쪽으로 내려앉기 때문에, 그때 얼마나 남았는지를 미리 알고 있어야 한다.
    """
    if not _key(cfg):
        if _provider(cfg) == "claude":
            return "머리: 클로드 코드(구독) — 제미나이 키는 없습니다."
        return "제미나이 키가 없습니다. 설정에서 무료 키를 넣으면 요약·표읽기가 됩니다."

    st = _state()
    head = ""
    if _provider(cfg) == "claude":                            # 지금은 클로드를 쓰지만 제미나이가 예비다
        head = "머리: 클로드 코드(구독) · 아래는 예비(제미나이)입니다\n"
    used = used_today()
    model = (st.get("model") or "?").split("/")[-1]
    lines = [head + f"🧠 제미나이 ({model})"]

    lim, src = known_limit(cfg, model)
    if lim:
        pct = min(100, round(used / lim * 100))
        bar_n = min(10, round(pct / 10))
        lines.append(f"하루: {pct}% 사용 ({used}/{lim}회) · {reset_in()} 충전")
        lines.append("▓" * bar_n + "░" * (10 - bar_n) + f"  · 남은 {max(0, lim - used)}회")
        if used >= lim:
            lines.append("다 썼습니다 — 오늘은 규칙 기반으로 답합니다.")
        elif pct >= 90:
            lines.append("⚠️ 얼마 안 남았습니다.")
        lines.append(f"(한도 출처: {src})")
    else:
        lines.append(f"오늘 {used}회 사용 · {reset_in()} 충전")
        lines.append("하루 한도는 구글이 계정마다 다르게 줍니다 — 문서에 숫자가 없습니다.")
        lines.append("처음 막히는 순간 구글이 알려주는 숫자를 받아 적어, 그때부터 %로 보여드립니다.")
        lines.append("미리 아신다면 «/status 한도 250» 으로 넣어주셔도 됩니다.")

    if _cooling(st):
        until = str(st.get("cooldown_until", ""))[5:16].replace("T", " ")
        lines.append(f"⏸ 지금은 규칙 기반 — {until} 까지 쉬는 중입니다.")

    prev = [f"{d[5:]} {n}회" for d, n in used_days(4)[1:]]
    if prev:
        lines.append("지난 날: " + " · ".join(prev))
    return "\n".join(lines)


def ask(cfg: dict, prompt: str, images: list[bytes] | None = None,
        max_chars: int = 60_000) -> str | None:
    """물어보고 답 문자열. 못 쓰면 None → 호출자가 규칙 기반으로 처리한다.

    **여기가 밖으로 나가는 유일한 문이다.** 그래서 가명 처리도 여기서 한다(제공자 무관) —
    나갈 때 이름을 지우고(privacy.mask), 답이 오면 원래 이름으로 되돌린다(unmask).
    사진은 가릴 방법이 없으므로 설정에서 켜야만 나간다(ai_send_photos).
    """
    provider = _provider(cfg)
    if not provider:
        return None
    if images and not cfg.get("ai_send_photos"):
        log.info("사진 전송 꺼짐(ai_send_photos) — 사진은 안 보냄")
        return None

    # 배운 것을 앞에 붙인다 — 여기가 유일한 문이라, 이 한 줄로 차트든 요약이든 표읽기든
    # 같은 기억이 따라간다(learn.py). 배운 게 없으면 빈 문자열이라 토큰을 안 쓴다.
    try:
        prompt = learn.inject_text() + prompt
    except Exception as e:                                   # noqa: BLE001 — 기억 때문에 본 기능이 죽으면 안 된다
        log.info("배운 것 주입 실패(무시하고 진행): %s", type(e).__name__)

    safe, mapping = privacy.mask(prompt)                     # ← 이름 지우고 나간다(모든 제공자 공통)

    if provider == "claude":                                 # 클로드 코드(구독)
        out = brain_claude.ask(safe, images=images)
        return privacy.unmask(out, mapping) if out else None

    # 아래는 제미나이 경로
    key = _key(cfg)
    model = model_of(cfg)
    if not (key and model):
        return None
    parts: list[dict] = []
    for img in (images or [])[:4]:
        parts.append({"inline_data": {"mime_type": "image/jpeg",
                                      "data": base64.b64encode(img).decode()}})
    parts.append({"text": safe[:max_chars]})
    body = {"contents": [{"parts": parts}],
            "generationConfig": {"temperature": 0.2, "maxOutputTokens": 2048}}

    for attempt in range(3):                                 # 분당 제한·서버 혼잡이면 잠깐 쉬고 다시
        try:
            r = requests.post(f"{API}/{model}:generateContent", params={"key": key},
                              json=body, timeout=TIMEOUT)
        except Exception as e:                               # noqa: BLE001
            log.info("Gemini 호출 실패: %s", type(e).__name__)
            return None
        # 서버가 잠깐 몰린 것(5xx)은 곧 풀린다 — 한두 번 다시 해본다.
        # 안 그러면 멀쩡한 요청이 규칙 기반으로 떨어져 '머리가 안 붙었다'로 보인다(2026-08-17).
        if r.status_code in (500, 502, 503, 504) and attempt < 2:
            log.info("Gemini 서버 혼잡(HTTP %s) — 잠깐 쉬고 다시", r.status_code)
            time.sleep(1.5)
            continue
        if r.status_code != 429:
            break
        delay = 0
        try:                                                 # 서버가 준 재시도 대기시간 + 실제 한도
            for d in r.json().get("error", {}).get("details", []):
                rd = str(d.get("retryDelay", ""))
                if rd.endswith("s"):
                    delay = int(float(rd[:-1]))
                _learn_quota(d, model)                       # 구글이 알려준 한도를 받아 적는다
        except Exception:                                    # noqa: BLE001
            pass
        # 대기가 짧으면 그 자리서 한 번 더. 길면 기다리지 않는다 —
        # 여기서 자면 봇 전체가 그동안 멈춘다(비동기 루프 안에서 부르는 동기 함수라
        # 35초를 잤더니 다른 명령도 다 안 먹었다, 2026-08-17). 규칙 기반으로 넘기는 게 낫다.
        if delay and delay <= MAX_WAIT and attempt == 0:
            log.info("Gemini 분당 제한 — %d초 쉬고 재시도", delay + 1)
            time.sleep(delay + 1)
            continue
        if delay:
            log.info("Gemini 분당 제한 — %d초 대기라 안 기다리고 규칙으로 넘김", delay)
        _start_cooldown(_state(), delay)                  # st 가 정의된 적이 없었다(2026-08-17)
        return None
    else:
        return None
    if r.status_code in (400, 403):                          # 키가 틀렸거나 권한 없음
        log.info("Gemini 거부(HTTP %s) — 키 확인 필요", r.status_code)
        return None
    if r.status_code in (500, 502, 503, 504):
        # 이 모델이 계속 막히면 다른 모델로 옮겨 탄다. 구글은 모델마다 혼잡도가 다르다.
        others = [m for m in model_candidates(key) if m != model]
        for alt in others[:2]:
            log.info("Gemini %s 가 계속 막혀 %s 로 바꿔 시도", model.split("/")[-1], alt.split("/")[-1])
            try:
                r2 = requests.post(f"{API}/{alt}:generateContent", params={"key": key},
                                   json=body, timeout=TIMEOUT)
            except Exception:                                # noqa: BLE001
                continue
            if r2.status_code == 200:
                st = _state(); st["model"] = alt; _save(st)   # 되는 모델로 갈아탄 걸 기억한다
                r = r2
                break
        else:
            log.info("Gemini 서버가 계속 막힙니다(HTTP %s) — 규칙으로 넘김", r.status_code)
            return None
    if r.status_code != 200:
        log.info("Gemini 오류 HTTP %s", r.status_code)
        return None

    try:
        cands = r.json().get("candidates") or []
        text = "".join(p.get("text", "") for p in cands[0]["content"]["parts"]).strip()
    except Exception:                                        # noqa: BLE001
        return None
    if not text:
        return None
    text = privacy.unmask(text, mapping)                     # ← 화면엔 실명으로 되돌려 보여준다

    today = datetime.now(KST).strftime("%Y-%m-%d")
    st = _state()                                            # st 가 정의된 적이 없었다 — 성공할 때마다 죽었다(2026-08-17)
    used = st.get("used") or {}
    used[today] = used.get(today, 0) + 1
    st["used"] = {k: v for k, v in used.items() if k >= today}   # 지난 날짜는 버림
    _save(st)
    return text
